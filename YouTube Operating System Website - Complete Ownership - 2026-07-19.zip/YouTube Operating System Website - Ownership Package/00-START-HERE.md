# YouTube Operating System Website — Start Here

This is the complete technical handoff for the verified seven-page website. The recipient can review, edit, rebuild, test, and deploy the site without access to the original computer or Codex workspace.

## Package contents

- `website-build/` — the ready-to-upload static website.
- `website-source/` — the complete editable Astro source, content, tests, validation scripts, specifications, decision records, and verification evidence.
- `confidential-original-inputs/` — the original conversation transcript, Project Bible, and final build brief. Keep this folder private; it is not visitor-facing website content.
- `licenses/` — bundled font and direct dependency license notices.
- `tools/preview-built-site.mjs` — a zero-dependency local server for the included build.
- `01-TRANSFER-MANIFEST.md` — version, verification, scope, exclusions, and current limitations.
- `02-THIRD-PARTY-NOTICES.md` — direct dependency and font-license summary.
- `SHA256SUMS.txt` — integrity hashes for every transferred file.

## Review the included build locally

Requirements: Node.js 22.12 or newer.

From this package folder, run:

```bash
node tools/preview-built-site.mjs
```

Then open `http://127.0.0.1:4321/`.

On macOS, `OPEN-SITE.command` runs the same command. On Windows, use `OPEN-SITE.bat`.

Do not open `website-build/index.html` directly with a `file://` URL. The site uses normal web routes and should be reviewed through the included local server or a static hosting service.

## Edit and rebuild the website

```bash
cd website-source
npm ci
npm run verify
npm run dev -- --port 4321
```

After making approved changes:

```bash
npm run build
```

The new deployable output will be written to `website-source/dist/`. Replace the top-level `website-build/` folder with that output before creating a new transfer package.

## Deploy the website

Upload the contents of `website-build/` to a static host. The current build is intentionally a private-review prototype: it has no working inquiry form, analytics, tracking, production identity, production domain, or deployment configuration. Review `website-source/docs/launch-blockers.md` before treating it as a public production website.

## Ownership note

This package contains the complete technical deliverable and all project files needed to operate it. It contains no hidden hosted service, proprietary build account, API credential, analytics account, or dependency on the original development machine. Legal ownership and intellectual-property assignment remain governed by the agreement between the commissioning and delivering parties; third-party components remain subject to the licenses in `licenses/`.

