@echo off
cd /d "%~dp0"
node tools\preview-built-site.mjs

