# Confidential Original Inputs

These files were supplied during the project and are included so the recipient has the complete source context. They are unedited internal project records, not website assets, and must not be uploaded with `website-build/` or published to visitors. They may contain irrelevant side conversation and original machine-specific paths.

| File | Classification | SHA-256 |
|---|---|---|
| `S-001-conversation-transcript.txt` | Mixed conversation transcript with anecdotal and irrelevant side conversation | `c11cb344852df8a81df056472974b6e92d168d37dd93061adf93ef26ace9bdaf` |
| `S-002-project-bible.txt` | Internal Russian-language product and operations concept | `6d18d6d6b5473552c93596b0c0536e14f8c57df9323c6e7c92dd02bcd3425f5a` |
| `S-003-final-build-brief.txt` | Final private-prototype implementation brief | `2b3861a2bb3a74af4ae85993cefcef2f4c6f09358da16793b5bee29f9cdac9c6` |

Claims and public-use limitations derived from the first two sources are recorded in `../website-source/docs/source-register.md` and `../website-source/docs/claims-register.md`.
