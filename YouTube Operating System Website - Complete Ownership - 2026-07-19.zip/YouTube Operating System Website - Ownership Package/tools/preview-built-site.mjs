import { createReadStream, existsSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import { extname, join, resolve, sep } from 'node:path';

const root = resolve(import.meta.dirname, '..', 'website-build');
const host = process.env.HOST ?? '127.0.0.1';
const port = Number.parseInt(process.env.PORT ?? '4321', 10);

const contentTypes = new Map([
  ['.css', 'text/css; charset=utf-8'],
  ['.html', 'text/html; charset=utf-8'],
  ['.js', 'text/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.png', 'image/png'],
  ['.svg', 'image/svg+xml'],
  ['.txt', 'text/plain; charset=utf-8'],
  ['.webp', 'image/webp'],
  ['.woff2', 'font/woff2'],
]);

function resolveRequestPath(requestUrl) {
  const pathname = decodeURIComponent(new URL(requestUrl, 'http://localhost').pathname);
  let candidate = resolve(root, `.${pathname}`);

  if (candidate !== root && !candidate.startsWith(`${root}${sep}`)) return null;
  if (existsSync(candidate) && statSync(candidate).isDirectory()) candidate = join(candidate, 'index.html');

  return candidate;
}

const server = createServer((request, response) => {
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    response.writeHead(405, { Allow: 'GET, HEAD' });
    response.end('Method Not Allowed');
    return;
  }

  let filePath;
  try {
    filePath = resolveRequestPath(request.url ?? '/');
  } catch {
    filePath = null;
  }

  if (!filePath || !existsSync(filePath) || !statSync(filePath).isFile()) {
    response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end('Not Found');
    return;
  }

  const headers = {
    'Cache-Control': 'no-store',
    'Content-Length': statSync(filePath).size,
    'Content-Type': contentTypes.get(extname(filePath).toLowerCase()) ?? 'application/octet-stream',
    'X-Content-Type-Options': 'nosniff',
  };
  response.writeHead(200, headers);
  if (request.method === 'HEAD') response.end();
  else createReadStream(filePath).pipe(response);
});

if (process.argv.includes('--self-test')) {
  const routes = ['/', '/system/', '/services/', '/fit/', '/results/', '/about/', '/apply/'];
  const missing = routes.filter((route) => {
    const filePath = resolveRequestPath(route);
    return !filePath || !existsSync(filePath) || !statSync(filePath).isFile();
  });

  if (missing.length) {
    console.error(`Preview self-test failed for: ${missing.join(', ')}`);
    process.exitCode = 1;
  } else {
    console.log(`Preview self-test passed: ${routes.length}/${routes.length} routes.`);
  }
} else {
  server.listen(port, host, () => {
    console.log(`YouTube Operating System preview: http://${host}:${port}/`);
    console.log('Press Control-C to stop.');
  });

  server.on('error', (error) => {
    console.error(`Unable to start the preview server: ${error.message}`);
    process.exitCode = 1;
  });

  for (const signal of ['SIGINT', 'SIGTERM']) {
    process.on(signal, () => server.close(() => process.exit(0)));
  }
}
