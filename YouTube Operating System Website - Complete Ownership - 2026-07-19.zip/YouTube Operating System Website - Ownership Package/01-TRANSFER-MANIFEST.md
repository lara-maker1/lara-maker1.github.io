# Ownership Transfer Manifest

## Delivered version

- Project: YouTube Operating System private website prototype
- Package date: 2026-07-19
- Source commit: `067ae14f91dc250d5b0823e22dd0aa79091bd6ae`
- Source branch at packaging: `feat/yos-visual-scroll`
- Framework: Astro 7.1.1
- Runtime requirement for development: Node.js 22.12 or newer and npm 9.6.5 or newer
- Generated routes: `/`, `/system/`, `/services/`, `/fit/`, `/results/`, `/about/`, `/apply/`

## Verified acceptance state

The delivered commit passed the complete local private-prototype verifier:

- Astro check: 44 files and zero diagnostics
- Automated tests: 56 passed and zero failed
- Content validation: 106 stable IDs, 7 pages, 5 services, 7 stages, and 4 measurement layers
- Static build: 7 routes
- Browser matrix: 35 route/viewport checks
- Accessibility automation: 14 Axe scans with no serious or critical issue reported
- Browser requests: zero third-party requests
- Dependency audit at packaging source: zero known vulnerabilities reported by `npm audit --omit=dev`
- JavaScript: 6,301 bytes gzip
- CSS: 5,701 bytes gzip
- Largest initial transfer: 18,497 bytes gzip
- Clean-extraction proof: from a copy with no `node_modules/` and no `dist/`, `npm ci` succeeded and `npm run verify` rebuilt the site before running all 56 tests, then passed 35 browser checks and 14 Axe scans on isolated origin `http://127.0.0.1:50144`.

The detailed evidence and screenshot are in `website-source/docs/verification/2026-07-19-premium-compact-menu-verification.md`.

## Included

- Complete tracked source at the delivered commit
- All seven page templates and English content modules
- Shared components, styles, locally hosted IBM Plex fonts, and interaction scripts
- Package lock with exact dependency versions
- Automated unit, content, build, browser, accessibility, and production-gate checks
- Product specifications, implementation plans, decision log, claims register, source register, and launch blockers
- Verification reports and six review screenshots
- Ready-to-upload generated static build
- Three original supplied project inputs, isolated as confidential material
- Direct dependency and font license notices
- Per-file SHA-256 integrity manifest

## Intentionally excluded

- `.git/` history and developer identity metadata
- `node_modules/`, `.astro/`, caches, logs, and operating-system metadata
- The untracked `.superpowers/` brainstorming workspace
- Local worktree registrations and machine-specific paths in the transferable source documentation. The raw confidential inputs remain unedited and may mention their original local paths.
- Credentials, tokens, passwords, API keys, hosting accounts, domains, and analytics accounts

None of the excluded machine or account data is required to run, edit, verify, build, or deploy the website.

## Current product boundary

This is a verified private prototype, not an approved public launch. The visitor build intentionally contains no form submission, data collection, analytics, tracking, third-party payload, public company identity, or production deployment configuration. LB-01 through LB-08 in `website-source/docs/launch-blockers.md` remain the governing public-launch gates. Safari/WebKit and VoiceOver still require human production-candidate verification.

## Integrity

Use `SHA256SUMS.txt` to verify individual files after transfer. The final ZIP hash is supplied alongside the ZIP because a ZIP cannot contain a checksum of itself.
