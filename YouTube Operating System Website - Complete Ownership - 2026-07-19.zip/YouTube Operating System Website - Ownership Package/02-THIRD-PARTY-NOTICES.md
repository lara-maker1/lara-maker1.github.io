# Third-Party Notices

The website-specific source and content are delivered separately from the third-party components below. Those components retain their original licenses.

## Visitor-facing and build dependencies

| Component | Delivered version | License | Notice file |
|---|---:|---|---|
| Astro | 7.1.1 | MIT | `licenses/Astro-MIT.txt` |
| Lenis | 1.3.25 | MIT | `licenses/Lenis-MIT.txt` |
| IBM Plex font files | bundled WOFF2 files | SIL Open Font License 1.1 | `licenses/IBM-Plex-OFL-1.1.txt` |

## Development and verification dependencies

| Component | Delivered version | License | Notice file |
|---|---:|---|---|
| `@astrojs/check` | 0.9.9 | MIT | `licenses/Astro-Check-MIT.txt` |
| Axe Core | 4.12.1 | MPL-2.0 | `licenses/Axe-Core-MPL-2.0.txt` and `licenses/Axe-Core-Third-Party.txt` |
| Playwright Core | 1.61.1 | Apache-2.0 | `licenses/Playwright-Core-Apache-2.0.txt` and `licenses/Playwright-Core-NOTICE.txt` |
| TypeScript | 6.0.3 | Apache-2.0 | `licenses/TypeScript-Apache-2.0.txt` |

`website-source/package-lock.json` is the authoritative exact dependency graph. Transitive packages are installed by `npm ci` and retain their own package license metadata.

