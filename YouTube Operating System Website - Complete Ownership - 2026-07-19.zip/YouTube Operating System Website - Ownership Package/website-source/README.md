# YouTube Operating System Site

## Project purpose

This repository controls an English-first B2B authority website for a research-led YouTube production and strategy service. The public proposition is that the company builds and operates a coordinated YouTube function inside a client business. “YouTube Operating System” names the service methodology; it does not name an existing software product.

The website is intended to explain how business goals, audience research, positioning, content architecture, production, publishing, analytics, and business decisions connect. It does not sell isolated editing, publishing volume, guaranteed virality, or instant leads.

## Current gate

**Redesigned private-prototype review.** The approved seven-page English site is implemented as a local, static Astro prototype with the cool-paper IBM Plex visual system, a single homepage title card, route-specific editorial pacing, Lenis-enhanced wheel/trackpad scrolling with native accessibility fallbacks, and a refined compact navigation that opens on fine-pointer hover while preserving focus, touch, keyboard, reduced-motion, and no-JavaScript behavior. It has no live form, data collection, analytics, tracking, third-party payloads, deployment configuration, or external publishing. It is suitable for private review only; public launch, live forms, evidence publication, public identity, and deployment remain blocked while all eight actual public-launch blockers are open.

## Local review

Requirements: Node.js 22.12 or newer and npm 9.6.5 or newer.

```bash
cd website-source
npm ci
npm run dev -- --port 4321
```

Then open `http://127.0.0.1:4321/`. Run `npm run verify` for the private-prototype checks. Run `npm run validate:production` separately; it is expected to fail closed until the public-launch blockers are formally closed.

## Authoritative artifacts

The documents below control the next session, in this order:

1. [`docs/superpowers/specs/2026-07-17-youtube-operating-system-site-design.md`](docs/superpowers/specs/2026-07-17-youtube-operating-system-site-design.md) — governing product, content, truth, accessibility, privacy, and verification specification.
2. [`docs/superpowers/specs/2026-07-18-youtube-operating-system-visual-redesign-and-smooth-scroll-design.md`](docs/superpowers/specs/2026-07-18-youtube-operating-system-visual-redesign-and-smooth-scroll-design.md) — owner-approved visual and motion addendum; it supersedes the original specification only where it says so.
3. [`docs/superpowers/plans/2026-07-18-youtube-operating-system-visual-redesign-and-smooth-scroll.md`](docs/superpowers/plans/2026-07-18-youtube-operating-system-visual-redesign-and-smooth-scroll.md) — executed redesign, smooth-scroll, and acceptance plan.
4. [`docs/verification/2026-07-18-visual-redesign-and-smooth-scroll-verification.md`](docs/verification/2026-07-18-visual-redesign-and-smooth-scroll-verification.md) — prior redesign evidence, interaction coverage, screenshots, production boundary, and limitations.
5. [`docs/superpowers/specs/2026-07-19-compact-menu-hover-interaction-design.md`](docs/superpowers/specs/2026-07-19-compact-menu-hover-interaction-design.md) — owner-approved compact-menu interaction and visual addendum.
6. [`docs/superpowers/plans/2026-07-19-premium-compact-menu-interaction.md`](docs/superpowers/plans/2026-07-19-premium-compact-menu-interaction.md) — executed premium compact-menu implementation and acceptance plan.
7. [`docs/verification/2026-07-19-premium-compact-menu-verification.md`](docs/verification/2026-07-19-premium-compact-menu-verification.md) — current measured compact-menu evidence, screenshot, production boundary, and limitations.
8. [`docs/superpowers/plans/2026-07-17-youtube-operating-system-site-implementation.md`](docs/superpowers/plans/2026-07-17-youtube-operating-system-site-implementation.md) — older executed implementation record and test strategy.
9. [`docs/verification/2026-07-17-private-prototype-verification.md`](docs/verification/2026-07-17-private-prototype-verification.md) — older baseline evidence and screenshots, retained for chronology.
10. [`docs/decision-log.md`](docs/decision-log.md) — approved and provisional decisions, including their review triggers.
11. [`docs/claims-register.md`](docs/claims-register.md) — claim status, evidence requirements, and public-use decisions.
12. [`docs/launch-blockers.md`](docs/launch-blockers.md) — conditions that block public launch, separated from optional improvements.
13. [`docs/source-register.md`](docs/source-register.md) — supplied inputs, support boundaries, and limitations.
14. This README — gate, scope, and handoff control.

If artifacts conflict, the narrower claims or launch restriction wins. The Project Bible is an input, not a scope override.

## Provisional-default policy

Work may continue through a private prototype without further discovery when an unknown has one of these treatments:

- a conservative, reversible default recorded in the decision log;
- a structured marker in the form `[LB-##: description]`, linked to the launch-blockers register;
- claim-safe language that describes a method, intent, or measurement approach without promising a result;
- omission from public-facing output until evidence or approval exists.

Provisional choices are approved for prototype work, not silently converted into launch facts. The absence of a company name, biography, brand assets, case evidence, contact details, pricing, geography, or final software choice does not block a private prototype. It may block public launch as recorded in `docs/launch-blockers.md`.

## Exact anti-scope

The current website project does not include:

- internal YouTube operations software;
- client accounts, portals, dashboards, or approval workflows;
- YouTube API integrations;
- CRM, revenue-attribution, email, calendar, or sales integrations;
- AI research, scripting, analysis, or production modules;
- portfolio dashboards or capacity planning;
- SaaS functionality or claims that such software exists;
- a blog CMS;
- multilingual publishing;
- checkout, subscriptions, or pricing transactions;
- fabricated product screens, cases, logos, testimonials, metrics, or endorsements;
- a live form, scheduler, analytics, chat, maps, embeds, or third-party tracking in the private prototype;
- deployment, publishing, production form activation, production analytics, or vault writes at the current gate.

## Next approved action

The user or an independent evaluator reviews the redesigned local private prototype against the approved specification, visual addendum, and current verification record. The next gate is review feedback or explicit private-prototype acceptance. Public launch, deployment, form activation, evidence publication, public identity, and data collection remain blocked and require a separately authorized production-readiness gate.
