import assert from 'node:assert/strict';
import test from 'node:test';

import { getPage, navigation, pages, site } from '../src/content/en/shared.mjs';
import { evidenceItems } from '../src/content/en/home.mjs';
import { methodStages } from '../src/content/en/system.mjs';
import { services } from '../src/content/en/services.mjs';
import { measurementLayers } from '../src/content/en/results.mjs';

const expectedRoutes = ['/', '/system/', '/services/', '/fit/', '/results/', '/about/', '/apply/'];
const prohibited = [
  /11\s+channels?/i,
  /100,?000\s+subscribers?/i,
  /one\s+million\s+subscribers?/i,
  /10\s*[–-]\s*30\s*[×x]/i,
  /120\s+channels?/i,
  /guaranteed\s+(views|leads|revenue|results?)/i,
  /proprietary\s+(platform|dashboard|ai)/i,
  /client\s+portal/i,
  /automated\s+integration/i,
];

function assertUniqueIds(records, label) {
  const ids = records.map(({ id }) => id);
  assert.equal(new Set(ids).size, ids.length, `${label} IDs must be unique`);
  assert.ok(ids.every((id) => /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id)), `${label} IDs must be stable kebab-case`);
}

test('shared content exposes the exact proposition, CTA, navigation, and routes', () => {
  assert.equal(pages[0].heading, 'We build the YouTube function inside your business.');
  assert.equal(site.proposition, 'We build and operate the YouTube function inside your business.');
  assert.deepEqual(site.cta, {
    id: 'primary-cta',
    label: 'Request a strategy conversation',
    href: '/apply/',
  });
  assert.deepEqual(navigation.map(({ href }) => href), expectedRoutes);
  assert.deepEqual(pages.map(({ route }) => route), expectedRoutes);
  assertUniqueIds(navigation, 'navigation');
  assertUniqueIds(pages, 'page');
});

test('page lookup returns a required record and fails closed for an unknown route', () => {
  assert.equal(getPage('/system/').id, 'page-system');
  assert.throws(() => getPage('/unknown/'), /Missing page content for route: \/unknown\//);
});

test('every page has complete, unique review-safe metadata', () => {
  for (const page of pages) {
    for (const field of ['id', 'route', 'navLabel', 'title', 'description', 'eyebrow', 'heading', 'summary']) {
      assert.equal(typeof page[field], 'string', `${page.id}.${field} must be a string`);
      assert.ok(page[field].trim(), `${page.id}.${field} must not be empty`);
    }
    assert.doesNotMatch(`${page.title} ${page.description}`, /\[LB-/i);
  }
  assert.equal(new Set(pages.map(({ title }) => title)).size, pages.length);
  assert.equal(new Set(pages.map(({ description }) => description)).size, pages.length);
});

test('method stages and services expose every required field with stable IDs', () => {
  assert.equal(methodStages.length, 7);
  assertUniqueIds(methodStages, 'method stage');
  for (const stage of methodStages) {
    for (const field of ['label', 'input', 'question', 'output', 'dependency']) {
      assert.ok(stage[field]?.trim(), `${stage.id}.${field} is required`);
    }
  }

  assert.equal(services.length, 5);
  assertUniqueIds(services, 'service');
  for (const service of services) {
    for (const field of ['title', 'bestWhen', 'participation', 'intendedDecision', 'exclusion']) {
      assert.ok(service[field]?.trim(), `${service.id}.${field} is required`);
    }
    assert.ok(service.scopeCategories.length >= 3, `${service.id}.scopeCategories needs useful detail`);
  }
});

test('measurement and evidence content fails closed', () => {
  assert.equal(measurementLayers.length, 4);
  assertUniqueIds(measurementLayers, 'measurement layer');
  for (const layer of measurementLayers) {
    for (const field of ['title', 'signals', 'caution', 'decisionUse']) {
      assert.ok(layer[field], `${layer.id}.${field} is required`);
    }
  }

  assert.ok(evidenceItems.length > 0);
  for (const item of evidenceItems) {
    assert.equal(item.publicationState, 'non-public');
    assert.equal(item.blockerId, 'LB-03');
    assert.ok(item.claimIds.every((id) => /^C-\d{3}$/.test(id)));
  }
});

test('visitor content contains no prohibited quantitative or future-platform claim', () => {
  const visitorContent = JSON.stringify({ site, navigation, pages, methodStages, services, measurementLayers });
  for (const pattern of prohibited) {
    assert.doesNotMatch(visitorContent, pattern);
  }
});
