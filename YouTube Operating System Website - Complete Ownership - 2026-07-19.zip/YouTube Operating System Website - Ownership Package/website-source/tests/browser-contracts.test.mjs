import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import test from 'node:test';

const root = resolve(import.meta.dirname, '..');
const cssPath = resolve(root, 'src/styles/global.css');
const fontDirectory = resolve(root, 'src/assets/fonts');
const fontFiles = [
  'IBMPlexSansCondensed-Medium.woff2',
  'IBMPlexSansCondensed-SemiBold.woff2',
  'IBMPlexSans-Regular.woff2',
  'IBMPlexSans-Medium.woff2',
  'IBMPlexSans-SemiBold.woff2',
  'IBMPlexMono-Regular.woff2',
  'IBMPlexMono-Medium.woff2',
];

function source(path) {
  return readFileSync(resolve(root, path), 'utf8');
}

function visualCss() {
  return [source('src/styles/fonts.css'), source('src/styles/global.css')].join('\n');
}

test('the approved cool-paper visual foundation and local Plex files are explicit', () => {
  const css = visualCss();
  for (const token of ['#f7f7f5', '#ffffff', '#0b0b0b', '#525252', '#184ae8', '#a9a9a9', '#d5d5d5']) {
    assert.match(css, new RegExp(token, 'i'), `missing approved token ${token}`);
  }
  for (const rejected of ['#f6f2ea', '#fffdfc', '#122033', '#236b6a', '#ddebe7', '#a84f16', '#f4e1d2']) {
    assert.doesNotMatch(css, new RegExp(rejected, 'i'), `rejected token remains: ${rejected}`);
  }
  assert.match(css, /font-family:\s*"IBM Plex Sans Condensed"/);
  assert.match(css, /font-family:\s*"IBM Plex Sans"/);
  assert.match(css, /font-family:\s*"IBM Plex Mono"/);
  assert.match(css, /font-display:\s*swap/);
  assert.doesNotMatch(css, /fonts\.googleapis|https?:\/\//i);
  for (const file of fontFiles) assert.ok(existsSync(resolve(fontDirectory, file)), `missing local font ${file}`);
  assert.ok(existsSync(resolve(fontDirectory, 'OFL.txt')), 'missing IBM Plex license');
});

test('focus, target size, reduced motion, and responsive contracts are explicit', () => {
  const css = readFileSync(cssPath, 'utf8');
  assert.match(css, /:focus-visible/);
  assert.match(css, /outline:\s*3px\s+solid\s+var\(--focus/);
  assert.match(css, /min-(?:height|block-size):\s*44px/);
  assert.match(css, /scroll-margin-top/);
  assert.match(css, /@media\s*\(prefers-reduced-motion:\s*reduce\)/);
  assert.match(css, /@media\s*\(min-width:\s*37\.5rem\)/);
  assert.match(css, /@media\s*\(min-width:\s*64rem\)/);
  assert.match(css, /@media\s*\(min-width:\s*72rem\)/);
  assert.match(css, /overflow-x:\s*clip/);
});

test('the narrow-screen menu target cannot shrink or wrap its label', () => {
  const css = readFileSync(cssPath, 'utf8');
  assert.match(css, /\.nav-disclosure\s*\{[^}]*flex:\s*0\s+0\s+auto/s);
  assert.match(css, /\.nav-disclosure\s*>\s*summary\s*\{[^}]*white-space:\s*nowrap/s);
});

test('the compact menu uses the approved editorial reveal and restrained surface', () => {
  const header = source('src/components/SiteHeader.astro');
  const css = source('src/styles/global.css');

  assert.match(header, /class="nav-disclosure__mark"/);
  assert.match(header, /class="nav-disclosure__reveal"/);
  assert.match(header, /class="nav-disclosure__reveal-inner"/);
  assert.match(header, /data-menu-state="closed"/);

  for (const contract of [
    /width:\s*min\(12\.75rem,\s*calc\(100vw\s*-\s*2rem\)\)/,
    /border-radius:\s*7px/,
    /border-radius:\s*8px/,
    /border-radius:\s*5px/,
    /grid-template-rows:\s*0fr/,
    /grid-template-rows:\s*1fr/,
    /1050ms\s+cubic-bezier\(\.16,\s*1,\s*\.3,\s*1\)/,
    /620ms\s+cubic-bezier\(\.4,\s*0,\s*\.2,\s*1\)/,
    /box-shadow:\s*inset\s+2px\s+0\s+var\(--cobalt\)/,
    /\[open\]:not\(\[data-menu-enhanced\]\)/,
  ]) assert.match(css, contract);

  assert.match(
    css,
    /@media\s*\(prefers-reduced-motion:\s*reduce\)\s*\{[\s\S]*?\*::after\s*\{[^}]*transition-delay:\s*0ms\s*!important/s,
  );

  assert.doesNotMatch(header, />0[1-9]</);
  assert.doesNotMatch(css, /linear-gradient|radial-gradient|backdrop-filter|filter:\s*blur/i);
});

test('the compact menu state module preserves native fallbacks and cleans up timers', () => {
  const menu = source('src/scripts/navigation-menu.ts');
  const entry = source('src/scripts/smooth-scroll.ts');

  for (const contract of [
    /\(hover:\s*hover\)\s*and\s*\(pointer:\s*fine\)/,
    /LEAVE_GRACE_MS\s*=\s*180/,
    /CLOSE_DURATION_MS\s*=\s*620/,
    /pointerenter/,
    /pointerleave/,
    /event\.key\s*===\s*'Escape'/,
    /focus\(\{\s*preventScroll:\s*true\s*\}\)/,
    /menuEnhanced/,
    /cancelAnimationFrame/,
    /clearTimeout/,
  ]) assert.match(menu, contract);

  assert.match(
    menu,
    /openingFrame\s*=\s*window\.requestAnimationFrame\(\(\)\s*=>\s*\{[\s\S]*?openingFrame\s*=\s*window\.requestAnimationFrame\(\(\)\s*=>/,
  );
  assert.match(entry, /mountNavigationMenu/);
  assert.doesNotMatch(
    menu,
    /\b(?:gsap|animejs|framer-motion)\b|from\s+['"]motion(?:\/[^'"]*)?['"]|cursorX|cursorY|mousemove/i,
  );
});

test('navigation and diagrams preserve native semantic source order', () => {
  const header = source('src/components/SiteHeader.astro');
  const process = source('src/components/ProcessRail.astro');
  const decision = source('src/components/DecisionLoop.astro');
  const fit = source('src/components/FitMatrix.astro');
  const evidence = source('src/components/EvidenceReserved.astro');

  assert.match(header, /<details class="nav-disclosure"/);
  assert.match(header, /aria-current=/);
  assert.match(process, /<ol class="process-rail__list">/);
  assert.match(process, /Text equivalent:/);
  assert.match(decision, /<ol class="decision-loop__list">/);
  assert.match(fit, />Strong fit</);
  assert.match(fit, />Poor fit</);
  assert.match(evidence, /Review note — not public copy/);
  assert.match(evidence, /This area is not proof/);
});

test('presentational components use content-bearing rows rather than decorative card indices', () => {
  const failure = source('src/components/FailureModeCard.astro');
  const service = source('src/components/ServiceCard.astro');
  const decision = source('src/components/DecisionLoop.astro');
  const measurement = source('src/components/MeasurementLayer.astro');
  assert.doesNotMatch(failure, /item-index/);
  assert.doesNotMatch(service, /item-index/);
  assert.match(service, /service-row__action/);
  assert.match(decision, /<ol class="decision-loop__list">/);
  assert.doesNotMatch(decision, /item-index/);
  assert.match(measurement, /Layer \{index \+ 1\}/);
  assert.match(source('src/components/FitMatrix.astro'), />Strong fit<|>Poor fit</);
});

test('decision-loop rows expose native ordered-list markers with a stable gutter', () => {
  const decision = source('src/components/DecisionLoop.astro');
  const css = source('src/styles/global.css');
  const listRule = css.match(/\.decision-loop__list\s*\{[^}]*\}/s)?.[0] ?? '';
  const itemRule = css.match(/\.decision-loop__list li\s*\{[^}]*\}/s)?.[0] ?? '';
  const markerRule = css.match(/\.decision-loop__list li::marker\s*\{[^}]*\}/s)?.[0] ?? '';

  assert.match(decision, /<ol class="decision-loop__list">/);
  assert.doesNotMatch(decision, /item-index/);
  assert.match(listRule, /list-style-position:\s*outside/);
  assert.match(listRule, /list-style-type:\s*decimal/);
  assert.match(listRule, /padding-inline-start:\s*2\.5rem/);
  assert.match(itemRule, /display:\s*list-item/);
  assert.doesNotMatch(itemRule, /display:\s*grid/);
  assert.match(markerRule, /color:\s*currentColor/);
  assert.match(markerRule, /font-family:\s*var\(--utility\)/);
  assert.match(markerRule, /font-size:\s*0\.75rem/);
  assert.match(markerRule, /font-weight:\s*500/);
  assert.match(markerRule, /font-variant-numeric:\s*tabular-nums/);
  assert.doesNotMatch(markerRule, /content\s*:/);
});

test('the browser runner covers every route, viewport, and accessibility mode', () => {
  const runnerPath = resolve(root, 'scripts/verify-browser.mjs');
  assert.ok(existsSync(runnerPath), 'browser verification runner must exist');
  const runner = readFileSync(runnerPath, 'utf8');

  for (const route of ['/', '/system/', '/services/', '/fit/', '/results/', '/about/', '/apply/']) {
    assert.ok(runner.includes(`'${route}'`), `runner must include ${route}`);
  }
  for (const viewport of ['320, height: 568', '375, height: 812', '768, height: 1024', '1024, height: 768', '1440, height: 900']) {
    assert.ok(runner.includes(viewport), `runner must include ${viewport}`);
  }
  for (const tag of ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa']) {
    assert.ok(runner.includes(`'${tag}'`), `runner must include ${tag}`);
  }
  assert.match(runner, /javaScriptEnabled:\s*false/);
  assert.match(runner, /reducedMotion:\s*'reduce'/);
  assert.match(runner, /requestfailed/);
  assert.match(runner, /console/);
  assert.match(runner, /scrollWidth/);
  assert.match(runner, /aria-current/);
  assert.match(runner, /serious|critical/);
  for (const contract of [
    /document\.fonts\.ready/,
    /IBM Plex Sans Condensed/,
    /dataset\.scrollMode/,
    /mouse\.wheel/,
    /emulateMedia/,
    /#main-content/,
    /PageDown/,
    /goBack/,
    /nav-disclosure__reveal/,
    /data-menu-state/,
    /hoverSummary/,
    /Escape/,
    /menuEarlyHeight/,
    /menuMidHeight/,
    /menuFinalHeight/,
    /const hoverResponsiveLink = page\.locator\('\.nav-disclosure nav a\[href="\/system\/"\]'\)/,
    /keyboard\.press\('Space'\)/,
    /waitForFunction/,
    /hasTouch:\s*true/,
    /focusProtectedState/,
    /reducedMenuOpenState/,
    /reducedMenuClosedState/,
    /liveClosingState/,
  ]) assert.match(runner, contract);
});

test('the browser runner isolates its preview port and verifies the served build identity', () => {
  const runner = source('scripts/verify-browser.mjs');

  assert.match(runner, /import\s+\{\s*createServer\s*\}\s+from\s+'node:net'/);
  assert.match(runner, /createServer\(\)/);
  assert.match(runner, /\.listen\(0,\s*'127\.0\.0\.1'/);
  assert.match(runner, /const port = await allocateLoopbackPort\(\)/);
  assert.match(runner, /const baseUrl = `http:\/\/127\.0\.0\.1:\$\{port\}`/);
  assert.match(runner, /const baseOrigin = new URL\(baseUrl\)\.origin/);
  assert.match(runner, /'--port',\s*String\(port\)/);
  assert.match(runner, /waitForPreview\(server, output, baseUrl\)/);
  assert.match(runner, /response\.text\(\)/);
  assert.match(runner, /YouTube systems for business \| Private review/);
  assert.equal((runner.match(/const baseUrl/g) ?? []).length, 1, 'runner must define one dynamic base URL');
  assert.doesNotMatch(runner, /4321/, 'runner must not use the shared fixed preview port');
});

test('the complete verifier builds before tests that inspect generated output', () => {
  const packageJson = JSON.parse(source('package.json'));
  const verify = packageJson.scripts.verify;
  const buildPosition = verify.indexOf('npm run build');
  const testPosition = verify.indexOf('npm test');

  assert.notEqual(buildPosition, -1, 'verify must include the production build');
  assert.notEqual(testPosition, -1, 'verify must include the Node test suite');
  assert.ok(
    buildPosition < testPosition,
    'verify must build before running build-output tests in a clean checkout',
  );
});

test('the browser harness checks review notes structurally and samples a visible CTA', () => {
  const runner = source('scripts/verify-browser.mjs');
  assert.match(runner, /unlabeledBlockerCount/);
  assert.match(runner, /textContent/);
  assert.match(runner, /Review note — not public copy.*i/);
  assert.match(runner, /locator\('\.page-intro \.button'\)/);
});

test('the Apply prohibited-control guard is scoped to page content', () => {
  const runner = source('scripts/verify-browser.mjs');
  assert.ok(
    runner.includes(
      "page.locator('main#main-content').locator('form, input, select, textarea, button[type=\"submit\"], a[href^=\"mailto:\"]').count()",
    ),
    'Apply prohibited-control locator must be scoped to main#main-content',
  );
});

test('the smooth-scroll module is restrained and honors native fallbacks', () => {
  const script = source('src/scripts/smooth-scroll.ts');
  for (const contract of [
    /autoRaf:\s*true/,
    /anchors:\s*true/,
    /smoothWheel:\s*true/,
    /syncTouch:\s*false/,
    /lerp:\s*0\.12/,
    /wheelMultiplier:\s*0\.9/,
    /stopInertiaOnNavigate:\s*true/,
    /prefers-reduced-motion:\s*reduce/,
    /\.destroy\(\)/,
    /#main-content/,
    /focus\(\{\s*preventScroll:\s*true\s*\}\)/,
  ]) assert.match(script, contract);
  assert.doesNotMatch(script, /syncTouch:\s*true|ScrollTrigger|gsap|scroll-snap|infinite:\s*true/i);
});

test('smooth-scroll start preserves the active Lenis mode when already mounted', () => {
  const script = source('src/scripts/smooth-scroll.ts');
  const start = script.slice(script.indexOf('function start'), script.indexOf('function stop'));
  assert.doesNotMatch(start, /reducedMotion\.matches\s*\|\|\s*lenis/);
  assert.match(start, /if\s*\(reducedMotion\.matches\)\s*\{[^}]*scrollMode\s*=\s*'native';[^}]*return;/s);
  assert.match(start, /if\s*\(lenis\)\s*\{[^}]*scrollMode\s*=\s*'lenis';[^}]*return;/s);
});

test('home owns the sole title-card variant and inner pages use the standard intro', () => {
  const intro = source('src/components/PageIntro.astro');
  const home = source('src/pages/index.astro');
  assert.match(intro, /variant\?:\s*'home'\s*\|\s*'standard'/);
  assert.match(intro, /page-intro--home/);
  assert.match(intro, /Method, not software/);
  assert.match(intro, /Private review/);
  assert.match(home, /variant="home"/);
  for (const route of ['system', 'services', 'fit', 'results', 'about', 'apply']) {
    assert.doesNotMatch(source(`src/pages/${route}.astro`), /variant="home"/);
  }
});

test('the title-card eyebrow preserves readable contrast on ink', () => {
  const css = source('src/styles/global.css');
  assert.match(css, /\.title-card\s+\.eyebrow\s*\{[^}]*color:\s*var\(--focus-on-dark\)/s);
});

test('the title-card primary action has explicit contrasting rest and hover states', () => {
  const css = source('src/styles/global.css');
  assert.match(
    css,
    /\.title-card\s+\.button--primary\s*\{[^}]*border-color:\s*var\(--cobalt\);[^}]*background:\s*var\(--cobalt\);[^}]*color:\s*var\(--white\);/s,
  );
  assert.match(
    css,
    /\.title-card\s+\.button--primary:hover\s*\{[^}]*border-color:\s*var\(--white\);[^}]*background:\s*var\(--white\);[^}]*color:\s*var\(--ink\);/s,
  );
});

test('the active desktop header CTA has an explicit white current marker', () => {
  const css = source('src/styles/global.css');
  assert.match(
    css,
    /\.desktop-nav\s+\.button--header\[aria-current="page"\]\s*\{[^}]*box-shadow:\s*inset\s+0\s+-2px\s+var\(--white\);/s,
  );
});

test('route pacing reserves sequence and cobalt emphasis for meaningful content', () => {
  const home = source('src/pages/index.astro');
  assert.doesNotMatch(home, /<ProcessRail/);
  assert.match(home, /class="method-synopsis"/);
  assert.match(home, /section--signal/);
  assert.match(source('src/pages/system.astro'), /<ProcessRail stages=\{methodStages\} detailed/);
  assert.match(source('src/pages/results.astro'), /section--signal/);
  assert.doesNotMatch(source('src/pages/services.astro'), /service-grid[^\n]*service-grid--compact/);
});

test('signal secondary copy has an AA-safe cobalt contrast override', () => {
  const css = source('src/styles/global.css');
  const token = (name) => css.match(new RegExp(`--${name}:\\s*(#[0-9a-f]{6})`, 'i'))?.[1];
  const luminance = (hex) => {
    const channels = hex.slice(1).match(/.{2}/g).map((pair) => Number.parseInt(pair, 16) / 255);
    const [red, green, blue] = channels.map((channel) => (
      channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4
    ));
    return (0.2126 * red) + (0.7152 * green) + (0.0722 * blue);
  };

  const cobalt = token('cobalt');
  const signalSecondary = token('signal-secondary');
  assert.ok(cobalt && signalSecondary, 'signal contrast tokens must be explicit hex values');
  const ratio = (Math.max(luminance(cobalt), luminance(signalSecondary)) + 0.05)
    / (Math.min(luminance(cobalt), luminance(signalSecondary)) + 0.05);
  assert.ok(ratio >= 4.5, `signal secondary contrast is ${ratio.toFixed(2)}:1`);
  assert.match(
    css,
    /\.section--signal \.section-introduction,\s*\.section--signal \.diagram-equivalent,\s*\.section--signal \.decision-loop__list p\s*\{[^}]*color:\s*var\(--signal-secondary\);/s,
  );
});
