import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import test from 'node:test';

const root = resolve(import.meta.dirname, '..');
const routes = [
  { href: '/', file: 'dist/index.html' },
  { href: '/system/', file: 'dist/system/index.html' },
  { href: '/services/', file: 'dist/services/index.html' },
  { href: '/fit/', file: 'dist/fit/index.html' },
  { href: '/results/', file: 'dist/results/index.html' },
  { href: '/about/', file: 'dist/about/index.html' },
  { href: '/apply/', file: 'dist/apply/index.html' },
];

function htmlFor(route) {
  const path = resolve(root, route.file);
  assert.ok(existsSync(path), `${route.href} must generate ${route.file}`);
  return readFileSync(path, 'utf8');
}

function matches(html, pattern) {
  return [...html.matchAll(pattern)];
}

test('the build contains exactly the seven approved route outputs', () => {
  assert.equal(routes.filter((route) => existsSync(resolve(root, route.file))).length, 7);
});

test('every route has semantic landmarks, one H1, a skip link, and the active navigation state', () => {
  for (const route of routes) {
    const html = htmlFor(route);
    assert.equal(matches(html, /<h1\b/gi).length, 1, `${route.href} needs one H1`);
    for (const landmark of ['header', 'nav', 'main', 'footer']) {
      assert.match(html, new RegExp(`<${landmark}\\b`, 'i'), `${route.href} needs ${landmark}`);
    }
    assert.match(html, /<a[^>]+class="[^"]*skip-link[^"]*"[^>]+href="#main-content"/i);
    assert.match(html, /<main[^>]+id="main-content"/i);
    const escapedHref = route.href.replaceAll('/', '\\/');
    assert.match(
      html,
      new RegExp(`<a[^>]+href="${escapedHref}"[^>]+aria-current="page"|<a[^>]+aria-current="page"[^>]+href="${escapedHref}"`, 'i'),
      `${route.href} must expose aria-current`,
    );
  }
});

test('every route has unique private-review metadata', () => {
  const titles = [];
  const descriptions = [];
  for (const route of routes) {
    const html = htmlFor(route);
    const title = html.match(/<title>([^<]+)<\/title>/i)?.[1];
    const description = html.match(/<meta\s+name="description"\s+content="([^"]+)"/i)?.[1];
    assert.ok(title, `${route.href} needs a title`);
    assert.ok(description, `${route.href} needs a description`);
    assert.match(html, /<link\s+rel="canonical"\s+href="https:\/\/private-review\.invalid\//i);
    assert.match(html, /<meta\s+name="robots"\s+content="noindex, nofollow, noarchive"/i);
    assert.doesNotMatch(`${title} ${description}`, /\[LB-/i);
    titles.push(title);
    descriptions.push(description);
  }
  assert.equal(new Set(titles).size, 7);
  assert.equal(new Set(descriptions).size, 7);
});

test('all absolute internal route links resolve to approved output', () => {
  const approved = new Set(routes.map(({ href }) => href));
  for (const route of routes) {
    const html = htmlFor(route);
    const hrefs = matches(html, /<a\b[^>]+href="(\/[^"]*)"/gi).map((match) => match[1]);
    for (const href of hrefs) {
      if (href.startsWith('/#')) continue;
      const normalized = href.split('#')[0];
      assert.ok(approved.has(normalized), `${route.href} links to unresolved route ${href}`);
    }
  }
});

test('Apply renders explanatory content with no form or submission path', () => {
  const html = htmlFor(routes.at(-1));
  assert.doesNotMatch(html, /<(form|input|select|textarea)\b/i);
  assert.doesNotMatch(html, /<button[^>]+type="submit"/i);
  assert.doesNotMatch(html, /<a[^>]+href="(?:mailto:|https?:\/\/)|\baction=|\bmethod="post"/i);
  assert.match(html, /This private prototype does not submit or store information\./);
});

test('every route loads only the local processed smooth-scroll module', () => {
  for (const route of routes) {
    const html = htmlFor(route);
    const scripts = matches(html, /<script\b([^>]*)>([\s\S]*?)<\/script>/gi);
    assert.equal(scripts.length, 1, `${route.href} needs one processed module entry`);
    assert.match(scripts[0][1], /type="module"/i);
    assert.match(scripts[0][1], /src="\/_astro\/[^"]+\.js"/i);
    assert.doesNotMatch(scripts[0][1], /https?:\/\//i);
    assert.equal(scripts[0][2].trim(), '', `${route.href} must not contain inline visitor code`);
  }
});

test('the private review build suppresses implicit external browser asset requests', () => {
  for (const route of routes) {
    const html = htmlFor(route);
    assert.match(html, /<link\s+rel="icon"\s+href="data:,"/i, `${route.href} needs a no-request favicon declaration`);
  }
});
