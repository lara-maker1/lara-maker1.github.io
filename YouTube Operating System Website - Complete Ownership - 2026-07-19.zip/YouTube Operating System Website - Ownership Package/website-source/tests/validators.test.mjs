import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';

import { findProhibitedClaims } from '../scripts/validate-content.mjs';
import { inspectHtml, validateBuildDirectory } from '../scripts/validate-build.mjs';
import { findOpenLaunchBlockers } from '../scripts/validate-production.mjs';

test('claim guard rejects prohibited evidence and positive future-product language', () => {
  assert.ok(findProhibitedClaims('We operate 120 channels.').length > 0);
  assert.ok(findProhibitedClaims('Clients receive a portal for approvals.').length > 0);
  assert.ok(findProhibitedClaims('Our proprietary AI platform automates research.').length > 0);
});

test('claim guard permits explicit non-software boundaries', () => {
  assert.deepEqual(
    findProhibitedClaims('It is not a software product, account area, or product interface.'),
    [],
  );
});

test('rendered HTML guard rejects external payloads and unlabeled blocker markers', () => {
  const unsafe = `<!doctype html><html><head><title>Unsafe</title></head><body>
    <main><h1>Unsafe page</h1><img src="https://tracker.example/pixel.gif" alt=""></main>
    <p>[LB-03: evidence]</p></body></html>`;
  const errors = inspectHtml(unsafe, '/');
  assert.ok(errors.some((error) => error.includes('external request-bearing URL')));
  assert.ok(errors.some((error) => error.includes('structured blocker marker')));
});

test('rendered HTML guard permits an unmistakable internal review note', () => {
  const safe = `<!doctype html><html><head>
    <title>Safe private review</title>
    <meta name="description" content="Safe description">
    <meta name="robots" content="noindex, nofollow, noarchive">
    <link rel="canonical" href="https://private-review.invalid/results/">
    </head><body><header></header><nav></nav><main id="main-content"><h1>Results</h1>
    <aside>Review note — not public copy. Controlling blocker: LB-03.</aside>
    </main><footer></footer></body></html>`;
  assert.ok(!inspectHtml(safe, '/results/').some((error) => error.includes('unlabeled blocker')));
});

test('rendered HTML guard rejects inline and remote visitor scripts', () => {
  const inline = '<script type="module">alert(1)</script>';
  const remote = '<script type="module" src="https://tracker.example/app.js"></script>';
  assert.ok(inspectHtml(`<html><body>${inline}</body></html>`, '/').some((error) => error.includes('unsafe script')));
  assert.ok(inspectHtml(`<html><body>${remote}</body></html>`, '/').some((error) => error.includes('unsafe script')));
});

test('rendered HTML guard permits a local generated module entry', () => {
  const locals = [
    '<script type="module" src="/_astro/smooth-scroll.abc123.js"></script>',
    `<script
      src="/_astro/smooth-scroll.abc123.js"
      type="module"
    ></script >`,
  ];
  for (const local of locals) {
    assert.ok(!inspectHtml(`<html><body>${local}</body></html>`, '/').some((error) => error.includes('unsafe script')));
  }
});

test('rendered HTML guard permits every ASCII HTML whitespace character in script syntax', () => {
  for (const [name, whitespace] of [
    ['space', ' '],
    ['tab', '\t'],
    ['line feed', '\n'],
    ['form feed', '\f'],
    ['carriage return', '\r'],
  ]) {
    const local = `<script${whitespace}type="module"${whitespace}src="/_astro/x.js"></script${whitespace}>`;
    assert.ok(
      !inspectHtml(`<html><body>${local}</body></html>`, '/').some((error) => error.includes('unsafe script')),
      `${name} must remain approved HTML whitespace`,
    );
  }
});

for (const [description, local] of [
  ['NBSP before type', '<script\u00a0type="module" src="/_astro/x.js"></script>'],
  ['NBSP between approved attributes', '<script type="module"\u00a0src="/_astro/x.js"></script>'],
  ['vertical tab between approved attributes', '<script type="module"\u000bsrc="/_astro/x.js"></script>'],
]) {
  test(`rendered HTML guard rejects ${description}`, () => {
    assert.ok(inspectHtml(`<html><body>${local}</body></html>`, '/').some((error) => error.includes('unsafe script')));
  });
}

for (const [description, opening] of [
  ['a slash-terminated event handler', '<script type="module" src="/_astro/x.js" onload/>'],
  ['a third attribute', '<script type="module" src="/_astro/x.js" data-extra="true">'],
  ['a duplicate type attribute', '<script type="module" type="module" src="/_astro/x.js">'],
  ['a duplicate src attribute', '<script type="module" src="/_astro/x.js" src="/_astro/y.js">'],
  ['a bare attribute', '<script type="module" src="/_astro/x.js" defer>'],
]) {
  test(`rendered HTML guard rejects ${description}`, () => {
    const unsafe = `${opening}</script>`;
    assert.ok(inspectHtml(`<html><body>${unsafe}</body></html>`, '/').some((error) => error.includes('unsafe script')));
  });
}

test('rendered HTML guard rejects event-handler attributes on local module entries', () => {
  for (const attribute of ['onload="alert(1)"', 'oncustom']) {
    const local = `<script type="module" src="/_astro/smooth-scroll.abc123.js" ${attribute}></script>`;
    assert.ok(inspectHtml(`<html><body>${local}</body></html>`, '/').some((error) => error.includes('unsafe script')));
  }
});

test('rendered HTML guard rejects an event handler with a spaced script close', () => {
  const unsafe = '<script type="module" src="/_astro/smooth-scroll.abc123.js" onload="alert(1)"></script >';
  assert.ok(inspectHtml(`<html><body>${unsafe}</body></html>`, '/').some((error) => error.includes('unsafe script')));
});

test('rendered HTML guard rejects an inline body with a whitespace-tolerant script close', () => {
  const unsafe = `<script type="module" src="/_astro/smooth-scroll.abc123.js">alert(1)</script
  >`;
  assert.ok(inspectHtml(`<html><body>${unsafe}</body></html>`, '/').some((error) => error.includes('unsafe script')));
});

test('rendered HTML guard rejects an opening script without a valid close', () => {
  const unsafe = '<script type="module" src="/_astro/smooth-scroll.abc123.js">';
  assert.ok(inspectHtml(`<html><body>${unsafe}</body></html>`, '/').some((error) => error.includes('unsafe script')));
});

test('build-directory guard reports a missing approved route', () => {
  const directory = mkdtempSync(join(tmpdir(), 'youtube-site-build-'));
  try {
    writeFileSync(join(directory, 'index.html'), '<!doctype html><html><head><title>Home</title></head><body><h1>Home</h1></body></html>');
    const { errors } = validateBuildDirectory(directory);
    assert.ok(errors.some((error) => error.includes('/system/')));
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});

test('build-directory guard rejects missing and non-file local module assets', () => {
  const directory = mkdtempSync(join(tmpdir(), 'youtube-site-build-'));
  try {
    mkdirSync(join(directory, '_astro', 'directory.js'), { recursive: true });
    writeFileSync(
      join(directory, 'index.html'),
      `<!doctype html><html><head><title>Home</title></head><body><h1>Home</h1>
      <script type="module" src="/_astro/missing.js"></script>
      <script type="module" src="/_astro/directory.js"></script></body></html>`,
    );
    const { errors } = validateBuildDirectory(directory);
    for (const asset of ['/_astro/missing.js', '/_astro/directory.js']) {
      assert.ok(errors.some((error) => error.includes(`missing local asset: ${asset}`)));
    }
  } finally {
    rmSync(directory, { recursive: true, force: true });
  }
});

test('production guard identifies every open actual launch blocker', () => {
  const register = Array.from({ length: 8 }, (_, index) => `### LB-0${index + 1} — Open blocker`).join('\n');
  assert.deepEqual(findOpenLaunchBlockers(register), [
    'LB-01', 'LB-02', 'LB-03', 'LB-04', 'LB-05', 'LB-06', 'LB-07', 'LB-08',
  ]);
});
