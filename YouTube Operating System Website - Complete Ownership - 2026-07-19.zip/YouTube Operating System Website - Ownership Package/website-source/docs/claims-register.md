# Claims Register

## Operating rule

No quantitative, comparative, client-specific, capacity, integration, automation, or software-capability claim may appear publicly unless its row is updated with acceptable evidence, permission where applicable, and an explicit public-use approval. Prototype markers must use the claim ID and must not resemble published proof.

Status terms follow `docs/source-register.md`. “Allowed with qualification” permits only the wording in the decision column; it does not validate a stronger version.

| ID | Claim wording | Source | Current status | Evidence required | Public-use decision |
|---|---|---|---|---|---|
| C-001 | “We operated 11 localized YouTube channels.” | S-001, conversation transcript | Supported but requiring evidence | URLs for all channels; ownership or operator authorization; dates and scope of responsibility; localization records; permission to name or anonymize the project | **Withhold.** Prohibited until the evidence package and permission are approved. |
| C-002 | “The channel/project reached 100,000 subscribers.” | S-001 | Supported but requiring evidence | Channel URL; dated YouTube analytics or public milestone record; proof of the team’s role; permission; exact timeframe | **Withhold.** Do not show the number, award imagery, or implied milestone. |
| C-003 | “A localized/Arabic channel reached one million subscribers.” | S-001; wording is ambiguous | Prohibited from public use until verified | Exact channel and language; dated analytics; ownership and role records; clarification that the transcript refers to subscribers rather than another metric; permission | **Withhold.** Ambiguity alone is disqualifying. |
| C-004 | “Client income increased 10–30×.” | S-001 | Prohibited from public use until verified | Client-level before/after financial records; defined metric, baseline, period, sample, confounders, attribution method, and written permission; legal review of advertising language | **Withhold.** Do not publish as a guarantee, range, case result, headline, or sales implication. |
| C-005 | “We make a client number one in its niche” or “system of domination.” | S-001 | Prohibited from public use until verified | Objective definition of “number one”; independent category data; timeframe; attributable methodology; permission; substantiation across representative work | **Withhold.** Replace with non-comparative positioning language such as “build a clearer, more authoritative market position.” |
| C-006 | “The system supports 120 channels” or “we operate 120 channels.” | S-002, Project Bible | Future hypothesis | Current portfolio count; capacity model; staffing and quality controls; service-level data; operating history at the stated scale | **Internal only.** It may be documented as a future design constraint, never as current capacity or traction. |
| C-007 | “YouTube is integrated with the client’s CRM, website, email, and sales team.” | S-002 | Provisional strategy mixed with future hypothesis | Current delivery map; named integration types; security/privacy review; live implementation evidence; client permission; limitations | **Withhold as a capability.** Public copy may say the methodology considers the wider buyer journey; it may not claim technical integration. |
| C-008 | “The service automatically creates tasks, sends reminders, optimizes packaging, or triggers analytics actions.” | S-002 | Future hypothesis | Implemented workflow inventory; logs; QA evidence; human-review boundaries; privacy/security assessment | **Withhold.** No automation claims in the site or prototype. |
| C-009 | “Clients receive a portal, dashboard, approval center, content map, asset library, or portfolio view.” | S-002 | Future hypothesis | Deployed product evidence; supported feature list; access-control review; data-processing terms; current client availability | **Withhold.** No product screens, dashboard motifs presented as UI, or feature-list implication. |
| C-010 | “AI performs research, scripting, analytics, QA, or production.” | S-002 | Future hypothesis | Implemented module evidence; provenance and review controls; accuracy evaluation; privacy/security assessment; contractual disclosure | **Withhold.** AI is not part of the public website offer at this stage. |
| C-011 | “We build and operate the YouTube function inside your business.” | Approved session direction; supported by S-001 and S-002 as intent | Provisional strategy | Before launch: confirm present service scope, responsible legal entity, delivery capacity, exclusions, and contract alignment | **Allowed for the private prototype.** Public launch requires LB-01 and LB-02 closure; avoid implying employees, software, or guaranteed outcomes. |
| C-012 | “The method connects business goals → audience research → positioning → content architecture → production → publishing → analytics → business decisions.” | Approved session direction; S-002 | Confirmed from source material as methodology | Confirm that each named stage is genuinely delivered in the selected engagement; document any stage that is advisory rather than done-for-you | **Allowed with qualification.** Present as the operating method, not as software automation or a guarantee. |
| C-013 | “YouTube creates a stable flow of attention, trust, demand, leads, or sales.” | S-001 and S-002 | Provisional strategy; outcomes require evidence | For performance wording: attributable client data, timeframe, baseline, definitions, and permission | **Allowed only as possibility or objective:** “designed to support,” “can help,” or “connects content decisions to business goals.” Never “will generate,” “stable flow,” or a guaranteed result. |
| C-014 | “Meaningful organic results take a few months.” | S-001 | Supported but requiring evidence | Define result, client/channel context, starting condition, publishing cadence, and representative historical data | **Withhold the timeframe.** Public copy may state that YouTube is a compounding, iterative channel and is not suited to instant-result expectations. |
| C-015 | “We use VidIQ, TubeBuddy, parsers, or proprietary research tools.” | S-001 | Confirmed from source material only as conversational description | Current tool inventory; licenses; security review; client disclosure terms; proof of what is proprietary versus third-party | **Omit.** Tools are not proof of the service and should not imply proprietary software. |
| C-016 | “The company offers diagnostic sessions, strategic intensives, channel launches, full management, and internal-team enablement.” | S-002 | Provisional strategy | Confirm which engagement models are currently saleable, their inclusions/exclusions, capacity, commercial terms, and delivery owner | **Allowed as prototype service architecture.** Before launch, remove unavailable offers and align wording with the approved contract scope. |
| C-017 | “The work improves authority, reputation, pricing power, conference invitations, or lead quality.” | S-001 | Supported but requiring evidence | Claim-specific client evidence, definitions, timeframe, attribution, and permission | **Withhold as an achieved result.** It may appear only as an unguaranteed client objective or measurement question. |

## Proof-area behavior

- **Private prototype:** show an internal, plainly labeled evidence-reserved module linked to C-001–C-005 and C-017. Do not use fake logos, blurred brand marks, invented quotes, sample metrics, or layouts that look like completed case cards.
- **Production with verified evidence:** render only the approved wording, denominator, timeframe, source note, and permission scope.
- **Production without verified evidence:** replace the proof module and Results page case section with the measurement framework and evidence standards. Do not publish empty case placeholders.

## Evidence acceptance checklist

A claim may move to public use only when the project records:

1. the exact approved wording;
2. the artifact or source that substantiates it;
3. the metric definition, baseline, denominator, and timeframe where relevant;
4. the company’s precise role in causing or supporting the result;
5. written permission for client, logo, quote, or identifiable data use;
6. any required legal or advertising review;
7. the approving person and approval date;
8. the pages and contexts in which use is allowed.
