# Visual Redesign and Smooth-Scroll Verification — 2026-07-18

## Verdict

The redesigned seven-route Astro site passes the local private-prototype acceptance gate at commit `634bcda89eb0c84b93045633e72bdba0a63fea6a`. The cool-paper, ink, cobalt, and locally hosted IBM Plex visual system is present; the homepage owns the sole title card; inner routes use the quieter editorial introduction; and Lenis enhances ordinary wheel/trackpad movement while keyboard, anchor, touch, reduced-motion, and no-JavaScript behavior retain native fallbacks.

This is not production or launch acceptance. The production validator correctly fails closed while LB-01 through LB-08 and private-review annotations remain open. No deployment, publishing, form activation, data collection, analytics, or external integration occurred.

## System under test

- Commit: `634bcda89eb0c84b93045633e72bdba0a63fea6a` (`test: verify redesigned scroll experience`).
- Node.js: `v26.3.0`.
- npm: `11.16.0`.
- Automated browser: Google Chrome `150.0.7871.125` through Playwright Core `1.61.1`.
- Routes: `/`, `/system/`, `/services/`, `/fit/`, `/results/`, `/about/`, `/apply/`.
- Preview origin: `http://127.0.0.1:4321` using the built static output.

## Deterministic command evidence

Each command below was run separately from a clean build worktree.

| Command | Exit | Exact result |
|---|---:|---|
| `npm run check` | 0 | Astro checked 43 files: 0 errors, 0 warnings, 0 hints. |
| `npm test` | 0 | 52 tests passed; 0 failed, cancelled, skipped, or todo. |
| `npm run validate:content` | 0 | 106 stable IDs, 7 pages, 5 services, 7 stages, and 4 measurement layers passed. |
| `npm run build` | 0 | Static Astro build completed with exactly 7 pages. |
| `npm run validate:build` | 0 | 7/7 routes; 1 JS file at 5,636 B gzip; 1 CSS file at 5,247 B gzip; largest initial transfer 17,348 B gzip. |
| `npm run verify:browser` | 0 | 7/7 routes; 35 route/viewport checks; 14 Axe scans; local fonts; correct title-card ownership; Lenis movement; keyboard, anchor, history, reduced-motion, and no-JavaScript behavior; zero third-party requests. |
| `npm audit --omit=dev` | 0 | `found 0 vulnerabilities`. |
| `npm run validate:production` | 1, expected | Intentionally failed with all 8 actual launch blockers open and private internal review annotations still present. |

The first sandboxed audit attempt could not resolve `registry.npmjs.org` and exited 1 with `getaddrinfo ENOTFOUND`. The exact same `npm audit --omit=dev` command was then rerun with narrowly approved registry access and returned exit 0 with zero vulnerabilities. The DNS failure is not presented as an advisory result.

## Build, asset, and request evidence

- JavaScript: 1 generated module, 5,636 B gzip, below the 25 KB compressed limit.
- CSS: 1 generated stylesheet, 5,247 B gzip, below the 60 KB compressed limit.
- Largest initial transfer: 17,348 B gzip.
- Fonts: 7 local WOFF2 files—two IBM Plex Sans Condensed, three IBM Plex Sans, and two IBM Plex Mono files—with the local SIL Open Font License notice.
- Third-party requests: 0 across the automated browser route/viewport matrix.
- Remote visitor assets: 0; build validation found only approved local output.
- Homepage title cards: 1. Inner-route title cards: 0.
- Browser reflow matrix: all 7 routes at 320×568, 375×812, 768×1024, 1024×768, and 1440×900, for 35 checks total.
- Accessibility engine: 14 Axe scans at 375 and 1440 CSS pixels across all routes, with no serious or critical violation emitted by the acceptance harness.

## Interaction acceptance matrix

The expanded pass used the built output in ordinary-motion Chrome unless stated otherwise.

| Interaction | Observed result | Status |
|---|---|---:|
| Wheel / trackpad equivalent | A 900 px wheel input produced progressive Home samples of `45` at 0 ms, `274` at 17 ms, `444` at 101 ms, `599` at 180 ms, `747` at 351 ms, `800` at 601 ms, and `809` at 901 ms. The response began immediately and settled without a long theatrical tail. | Pass |
| PageDown / PageUp | `0 → 860 → 0`. | Pass |
| End / Home | `0 → 13,725 → 0`. | Pass |
| Space / Shift+Space | `0 → 860 → 0`. | Pass |
| ArrowDown / ArrowUp | `0 → 40 → 0`. | Pass |
| Skip link | First Tab focused “Skip to main content”; Enter immediately focused `main#main-content` and set `#main-content`. | Pass |
| Direct anchor | Direct `/#main-content` resolved to the single main landmark; the browser harness also verified anchor/history behavior. | Pass |
| Mobile navigation by keyboard | The native disclosure opened with Enter and closed with Enter; its focused control retained the tested 44 px target and visible outline. | Pass |
| FAQ by keyboard | The native FAQ disclosure opened with Enter and closed with Enter. | Pass |
| Reduced motion before load | Computed mode was `native`, no `.lenis` class was present, root scroll behavior was `auto`, and the FAQ marker transition computed to 0.00001 s. | Pass |
| Reduced motion changed live | Changing to Reduce Motion immediately produced native mode and removed `.lenis`; restoring the preference restarted Lenis. | Pass |
| Native touch | A touch-capable 375×812 emulation received a real touch swipe and moved from `scrollY 0` to `863`. Lenis remained available for non-touch input while the `syncTouch: false` contract left touch movement native. | Pass |
| Navigate during wheel inertia | Immediate navigation landed on `/system/` at `scrollY 0`, with an empty fragment and active Lenis mode. | Pass |
| Back / Forward | Back returned to `/`; Forward returned to `/system/`; both had empty fragments, stable `scrollY 0`, and a correctly remounted Lenis mode. | Pass |
| JavaScript disabled | All 7 routes retained their H1, substantial main content, and route navigation. On Home, the skip link focused main and set the hash; native Menu and FAQ disclosures opened; navigation reached `/system/`. | Pass |

The default-motion browser harness also verified the local-font load, one-Home/no-inner title-card rule, Lenis class and mode, visible CTA focus, no horizontal overflow, no failed requests, and no non-GET or cross-origin request.

## Screenshot evidence and visual inspection

The following deterministic captures replaced the prior screenshots. Each was opened and inspected at original resolution:

- [`home-desktop-1440.png`](screenshots/home-desktop-1440.png) — Home, 1440×900.
- [`home-mobile-320.png`](screenshots/home-mobile-320.png) — Home, 320×568.
- [`system-tablet-768.png`](screenshots/system-tablet-768.png) — System, 768×1024.
- [`results-evidence-1024.png`](screenshots/results-evidence-1024.png) — Results at the internal evidence section, 1024×768; the target heading was visible at capture and the page was at `scrollY 3022`.
- [`apply-preview-375.png`](screenshots/apply-preview-375.png) — Apply, 375×812.

The visible review found no old cream/serif/terracotta palette, decorative card grid, fake UI chrome, repeated inner-route title card, horizontal overflow, clipped heading, focus/annotation collision, or unintended blank field. Content continuing below a short mobile viewport is ordinary document flow, not clipping. Captures used a reduced-motion, animation-disabled context for stable pixels; ordinary-motion scrolling was tested separately.

## Limitations that remain unverified

- Safari 26.4 is installed, but this runner had no Playwright WebKit executable at the configured path. Safari/WebKit interactions were not executed and are explicitly unverified; no Chromium result is inferred to cover Safari.
- VoiceOver and other human assistive-technology behavior were not run. Native semantic order, landmarks, focus behavior, disclosure behavior, reduced motion, reflow, and serious/critical Axe checks are covered, but announcements and rotor behavior still require a human pass before production acceptance.
- No production origin exists. HTTPS, response headers, CSP/HSTS, domain controls, caching, rollback, and live-origin performance remain unverified.
- No production inquiry system exists, so form validation, spam/rate limits, processor behavior, retention/deletion, delivery failure, and response ownership are intentionally untestable.

## Expected private-prototype boundary and next gate

`npm run validate:production` must remain non-zero at this gate. The open boundary is:

- LB-01 public identity and accountable contact;
- LB-02 current service scope and availability;
- LB-03 evidence publication decision;
- LB-04 geography, privacy obligations, and notices;
- LB-05 production inquiry form and processor;
- LB-06 factual, claims, identity, and content approval;
- LB-07 production hosting, deployment, and security controls;
- LB-08 production-candidate release verification, including Safari and assistive technology.

The single next gate is owner or independent-evaluator review of this local private prototype. Public launch, live forms, evidence publication, public identity, data collection, and deployment remain blocked until separately authorized and closed with evidence.
