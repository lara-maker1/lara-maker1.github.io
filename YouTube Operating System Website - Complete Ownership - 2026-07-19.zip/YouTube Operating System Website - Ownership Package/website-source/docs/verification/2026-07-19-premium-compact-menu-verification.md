# Premium Compact Menu Verification — 2026-07-19

## Verdict

The refined compact navigation passes the local private-prototype acceptance gate at commit `1631605c3913b1b963afba918d1669134e1fc6a5`. At compact fine-pointer widths it opens automatically, reveals progressively over the approved slow interval, preserves its native `open` attribute through the visual close, reverses cleanly on pointer re-entry, and protects the open state while focus remains within the menu. Its 204 px panel, restrained radii, monochrome row inversion, and single cobalt inset edge match the approved Editorial Shutter direction.

Tap, Enter, Space, Escape, focus, initial and live reduced motion, no-JavaScript disclosure, and the unchanged wide desktop navigation are covered. This is not production or launch acceptance. The production validator correctly fails closed while LB-01 through LB-08 and private-review annotations remain open. No deployment, publishing, form activation, data collection, analytics, or external integration occurred.

## System under test

- Commit: `1631605c3913b1b963afba918d1669134e1fc6a5` (`fix: verify clean checkout builds first`).
- Implementation range: `d673f6e1f6309eb08f3ea25ec56b91b968b19aad..1631605c3913b1b963afba918d1669134e1fc6a5`; the first runtime interaction commit is `7c252bd7c96c4fb408e09f2e109a618e07f256dd`.
- Node.js: `v26.3.0`.
- npm: `11.16.0`.
- Automated browser: Google Chrome `150.0.7871.125` through Playwright Core `1.61.1`.
- Routes: `/`, `/system/`, `/services/`, `/fit/`, `/results/`, `/about/`, `/apply/`.
- Browser-verifier preview: an isolated dynamic origin, `http://127.0.0.1:49311` for this run.
- Screenshot preview: `http://127.0.0.1:55173`, selected only after confirming that the port had no listener; the preview was stopped after capture.

## Deterministic command evidence

Each command below was run separately against the built worktree at the system-under-test commit.

| Command | Exit | Exact result |
|---|---:|---|
| `npm run check` | 0 | Astro checked 44 files: 0 errors, 0 warnings, 0 hints. |
| `npm test` | 0 | 56 tests passed; 0 failed, cancelled, skipped, or todo. The added contract requires the complete verifier to build before tests inspect generated output, so a clean source handoff no longer depends on stale `dist/` state. |
| `npm run validate:content` | 0 | 106 stable IDs, 7 pages, 5 services, 7 stages, and 4 measurement layers passed. |
| `npm run build` | 0 | Static Astro build completed with exactly 7 pages. |
| `npm run validate:build` | 0 | 7/7 routes; 1 JS file at 6,301 B gzip; 1 CSS file at 5,701 B gzip; largest initial transfer 18,497 B gzip. |
| `npm run verify:browser` | 0 | 7/7 routes; 35 route/viewport checks; 14 Axe scans; local fonts; title-card ownership; Lenis movement; premium compact-menu fine-pointer, re-entry, focus, coarse-pointer, keyboard, reduced-motion, no-JavaScript, and desktop-navigation behavior; zero third-party requests. |
| `npm audit --omit=dev` | 0 | `found 0 vulnerabilities`. |
| `npm run validate:production` | 1, expected | Intentionally failed with all 8 actual launch blockers open and private internal review annotations still present. |

The first sandboxed browser-verifier attempt could not bind `127.0.0.1` and exited 1 with `EPERM`. The exact same command was rerun with narrowly scoped local-bind/browser permission and passed at the isolated dynamic port above. The first restricted-network audit attempt could not resolve `registry.npmjs.org` and exited 1 with `getaddrinfo ENOTFOUND`; the exact same audit command was then rerun with approved registry access and returned exit 0 with zero vulnerabilities. Neither sandbox restriction is presented as product failure or acceptance evidence.

## Build, asset, and request evidence

- JavaScript: 1 generated local module, 6,301 B gzip, below the 25 KB compressed limit.
- CSS: 1 generated stylesheet, 5,701 B gzip, below the 60 KB compressed limit.
- Largest initial transfer: 18,497 B gzip.
- Routes: exactly 7 generated static pages.
- Browser reflow matrix: all 7 routes at 320×568, 375×812, 768×1024, 1024×768, and 1440×900, for 35 checks total.
- Accessibility engine: 14 Axe scans at 375 and 1440 CSS pixels across all routes, with no serious or critical violation emitted by the acceptance harness.
- Third-party requests: 0 across the automated route/viewport matrix; local IBM Plex assets remained local.
- Wide desktop invariant: at 1440 px the desktop navigation remained visible and the compact disclosure remained hidden.

## Compact-menu interaction acceptance matrix

The expanded browser pass used the built output in ordinary-motion Chrome unless stated otherwise.

| Interaction | Observed result | Status |
|---|---|---:|
| Fine-pointer automatic opening | Moving onto Menu at 1024×768 produced native `open` plus the controlled opening/open states. The evidence capture sampled reveal heights of `80.78125` px at 40 ms, `316.3125` px at 420 ms, and `334.5625` px at 1,150 ms; the sequence was monotonic and finished in `open`. | Pass |
| Panel geometry | The settled reveal measured exactly `204` px wide and `334.5625` px high. Document horizontal overflow was `0` px. | Pass |
| Non-current row response | After hovering “The System” for 360 ms, its background was `rgb(11, 11, 11)`, text was `rgb(255, 255, 255)`, and its shadow included `rgb(24, 74, 232) 2px 0px 0px 0px inset`; the tested row height was `44.28125` px. The harness also confirmed that this non-current row did not carry the cobalt edge before hover. | Pass |
| Pointer-leave grace and close | Moving outside left native `open` present after 100 ms. After a further 850 ms the disclosure finished as native closed with `data-menu-state="closed"`. | Pass |
| Re-entry during closing | After reopening for 1,100 ms, moving outside for 260 ms produced native `open` with `data-menu-state="closing"`. Re-entering and waiting 100 ms restored native `open` with `data-menu-state="open"`, without premature finalization. | Pass |
| Focus within | Focusing `/system/`, moving the pointer outside, and waiting 950 ms left the disclosure open, in the `open` state, and matching `:focus-within`. Moving focus to the wordmark then allowed the menu to close. | Pass |
| Keyboard, Enter, Space, and Escape | At 375×812 the summary had a visible outline and at least a 44 px target. Enter opened the menu; Tab exposed and focused the first 44 px navigation row; Escape completed the controlled close and returned focus to the summary; Space reopened it. | Pass |
| Touch / coarse pointer | In a touch-capable mobile context, a touch `pointerenter` left the menu closed and did not assume fine-pointer hover. The first tap opened it; the second tap entered the controlled `closing` state while native `open` remained present, then finalized closed. | Pass |
| Reduced motion before load | In an initial Reduce Motion context, Enter exposed the full menu immediately, compact-menu transition duration and delay computed at or below 0.001 s, native scrolling was active, and Escape immediately closed the menu and restored summary focus. | Pass |
| Reduced motion changed live | Changing to Reduce Motion during the controlled close finalized the menu closed within 250 ms and destroyed Lenis. Restoring the preference restarted Lenis. | Pass |
| JavaScript disabled | All 7 routes retained their H1, substantial main content, and route navigation. Native Menu and FAQ disclosures opened, and the compact navigation reached `/system/`. | Pass |

The same pass retained the prior local-font, sole-Home-title-card, keyboard scrolling, skip-link, anchor, browser-history, no-horizontal-overflow, no-failed-request, and no-cross-origin-request protections.

## Screenshot evidence and visual inspection

- [`menu-hover-1024.png`](screenshots/menu-hover-1024.png) — Home at 1024×768 after the Menu trigger had been hovered for at least 1,150 ms and the non-current “The System” row had been hovered for a further 360 ms.

The capture is a 1024×768 PNG, 80,702 bytes, with SHA-256 `779f910854fb7c2b0eb4fbe99cf9e803f7793d783609e999e7a1881a116711f4`. Before capture, the served title was verified as `YouTube systems for business | Private review`. The PNG was opened and inspected at original resolution. The visible result has no horizontal overflow, clipped menu content, visible numeric menu labels, oversized panel, square card treatment, colorful glow, focus collision, unreadable row text, or desktop-navigation regression. The hovered row uses only the approved ink inversion and narrow cobalt edge; the Home current-page edge remains distinct, and the white surface, low neutral shadow, and restrained corners remain legible over the Home title card. The small cobalt square visible beneath the panel is the existing intentional title-card marker, not menu overflow.

## Limitations that remain unverified

- Safari/WebKit was not executed for the compact-menu interaction and is explicitly unverified; no Chromium result is inferred to cover Safari.
- VoiceOver and other human assistive-technology behavior were not run. Native semantics, source order, focus management, practical targets, reduced motion, reflow, and serious/critical Axe checks are covered, but announcements and rotor behavior still require a human pass before production acceptance.
- No production origin exists. HTTPS, response headers, CSP/HSTS, domain controls, caching, rollback, and live-origin performance remain unverified.
- No production inquiry system exists, so form validation, spam/rate limits, processor behavior, retention/deletion, delivery failure, and response ownership remain intentionally untestable.

## Expected private-prototype boundary and next gate

`npm run validate:production` must remain non-zero at this gate. The open boundary remains LB-01 public identity and accountable contact; LB-02 current service scope and availability; LB-03 evidence publication; LB-04 geography, privacy obligations, and notices; LB-05 production inquiry form and processor; LB-06 factual, claims, identity, and content approval; LB-07 hosting, deployment, and security controls; and LB-08 production-candidate verification, including Safari and assistive technology.

The single next gate is owner or independent-evaluator review of this local private prototype. The compact-menu refinement does not authorize public launch, deployment, live forms, evidence publication, public identity, analytics, data collection, or any third-party visitor payload.
