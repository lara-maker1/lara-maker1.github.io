# Private Prototype Verification — 2026-07-17

## Verdict

The local seven-page English prototype meets the private-review gate. It is not approved for deployment or public launch. Production validation intentionally fails closed while LB-01 through LB-08 remain open and private review annotations are present.

## Verified scope

- Routes: `/`, `/system/`, `/services/`, `/fit/`, `/results/`, `/about/`, `/apply/`.
- Exact proposition: “We build and operate the YouTube function inside your business.”
- Exact primary CTA: “Request a strategy conversation.”
- Apply is explanatory content only: no form, fields, submit control, email link, scheduler, endpoint, storage, or follow-up promise.
- Results uses an unmistakable internal evidence-reserved treatment and publishes no fabricated client, testimonial, logo, metric, or quantitative outcome.
- About describes the operating belief and method without inventing a founder biography, credential, history, portrait, or identity fact.
- “YouTube Operating System” is presented as a coordinated service methodology, not software.
- Every page includes private `noindex, nofollow, noarchive` metadata; `robots.txt` disallows crawling.
- The built visitor output contains seven HTML files, one local CSS asset, zero JavaScript assets, no external request-bearing URLs, and no operational form controls.

## Automated evidence

The final clean verification pass uses the pinned lockfile and these commands:

```bash
npm ci
npm run check
npm test
npm run validate:content
npm run build
npm run validate:build
npm run verify:browser
npm audit --omit=dev --audit-level=high
npm run validate:production
```

Expected private-prototype results:

- Astro check: zero errors, warnings, or hints.
- Node tests: 25 passed, 0 failed.
- Content validator: 106 stable IDs, 7 pages, 5 services, 7 stages, and 4 measurement layers.
- Build validator: 7/7 routes, 0 visitor JavaScript, CSS and initial-transfer budgets below their hard limits.
- Chrome browser verifier: 35 route/viewport checks across 320, 375, 768, 1024, and 1440 CSS pixels; 14 Axe scans at mobile and desktop; JavaScript-disabled content/navigation; keyboard skip link, native menu, focus visibility, and practical target checks; reduced-motion checks; no horizontal overflow; and zero third-party requests.
- Official npm advisory check: zero known production-dependency vulnerabilities at high-or-greater audit severity (and zero vulnerabilities reported overall).
- Production validator: expected non-zero exit, naming all eight open actual launch blockers and the remaining private-review annotations.

## Visible browser review

Chrome and the Codex in-app browser were inspected at representative mobile, tablet, and desktop widths. Home, System, Services, Fit, Results, About, Apply, native mobile navigation, process rails, evidence-reserved state, and qualification-question preview were reviewed. No clipping or horizontal overflow was observed.

The visible pass found one defect at 320px: the native Menu label could shrink and wrap. A regression test was added before the CSS fix. The corrected target remains on one line, measures 44px high, and the page remains exactly 320px wide.

Screenshots:

- [`home-mobile-320.png`](screenshots/home-mobile-320.png)
- [`home-desktop-1440.png`](screenshots/home-desktop-1440.png)
- [`system-tablet-768.png`](screenshots/system-tablet-768.png)
- [`results-evidence-1024.png`](screenshots/results-evidence-1024.png)
- [`apply-preview-375.png`](screenshots/apply-preview-375.png)

## Accessibility and reflow interpretation

- Semantic landmarks, one H1 per page, native links and disclosures, active-page state, skip navigation, focus styles, target sizes, reduced motion, and serious/critical Axe findings are covered by automated checks.
- The 320px and 375px checks provide the standards-equivalent reflow widths for a 1280px viewport at 400% and a more stringent-than-200% narrow layout. Browser GUI zoom controls were not separately automated.
- VoiceOver was not run. Screen-reader announcements, reading order, and rotor behavior require a human assistive-technology pass before production acceptance.

## Browser and production limitations

- Current Google Chrome is the automated browser engine. The Codex in-app browser supplied an additional visible Chromium review surface.
- Safari is installed locally, but its computer-control accessibility state did not become available during this run. Safari remains unverified rather than assumed to pass. Firefox is not installed.
- No production origin exists, so HTTPS, live response headers, domain controls, CSP, HSTS, caching, rollback, and live performance are unverified.
- No production inquiry flow exists, so validation, spam/rate limits, processor behavior, retention/deletion, delivery failure, and response ownership are intentionally untestable.
- No deployment, publishing, outbound message, external data collection, analytics, or third-party integration occurred.

## Review gate

The single next gate is user or independent-evaluator review of the private local prototype. Launch work must not begin until separately authorized and the launch-blocker register is closed with evidence.
