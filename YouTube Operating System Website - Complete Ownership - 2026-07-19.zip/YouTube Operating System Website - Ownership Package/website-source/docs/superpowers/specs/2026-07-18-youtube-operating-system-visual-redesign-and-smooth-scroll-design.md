# YouTube Operating System visual redesign and smooth-scroll design

**Date:** 2026-07-18

**Decision state:** Approved by owner in conversation on 2026-07-18

**Written review state:** Approved

**Applies to:** Private Astro prototype only

## 1. Purpose and relationship to the governing specification

This addendum turns the approved anti-default visual direction and smooth-scrolling request into an implementation-ready design contract.

It supersedes only the visual-system, component-treatment, motion, and related performance details in sections 9, 10, 12, 13, 19, 21, and 22 of `2026-07-17-youtube-operating-system-site-design.md` where the two documents conflict.

The original specification remains authoritative for:

- the truth model and claim controls;
- audience, anti-audience, positioning, and voice;
- the seven-route information architecture;
- approved English content and content boundaries, except for the explicit homepage H1 approved in section 5;
- conversion and CTA boundaries;
- accessibility, security, privacy, SEO, and form deferral;
- the distinction between a private prototype and a production launch.

This redesign must not invent proof, client history, metrics, testimonials, integrations, team biographies, or service availability. It changes presentation, not truth status.

The homepage title-card H1 in section 5 is the only approved copy-level exception. The broader shared proposition remains “We build and operate the YouTube function inside your business”; the shorter “We build the YouTube function inside your business.” is a homepage-only title-card statement and must not silently replace the broader proposition site-wide.

## 2. Approved outcome

The site should feel like an intentionally art-directed operating practice for YouTube strategy, not a generic agency template, a software dashboard, or an AI-generated “editorial” landing page.

The approved direction combines:

1. a cool, high-contrast editorial canvas;
2. typography derived from programming, rundowns, transcripts, and editorial decisions;
3. one memorable homepage signature: a full-width 16:9 title card;
4. varied section pacing instead of a repeated card-grid rhythm;
5. a single cobalt annotation color used with discipline;
6. Lenis-enhanced wheel and trackpad scrolling over native browser scroll;
7. native touch, keyboard, reduced-motion, and no-JavaScript behavior.

The implementation is a coherent redesign of all seven routes, not a skin placed over the current cream-and-serif system.

## 3. Anti-default design rationale

### Rejected patterns

The implementation must explicitly avoid the patterns that made the prior version feel generated:

- warm cream or tan canvas paired with a high-contrast serif and terracotta accent;
- a dark “premium” theme with neon accent colors;
- broadsheet imitation, newspaper columns, and decorative hairline overload;
- generic split heroes, centered marketing heroes, and floating abstract shapes;
- a field of rounded cards with identical padding, radius, shadow, and hierarchy;
- invented logo tiles, fake product chrome, fictional charts, or miniature dashboards;
- ornamental eyebrow labels that do not classify the content below them;
- decorative numbering where sequence has no semantic meaning;
- repeated three-column feature grids and equal-height package cards;
- gratuitous gradients, glow, blur, glass effects, badges, and pill-shaped UI;
- motion used to make ordinary content appear more sophisticated.

### Subject-specific source material

The visual language should come from the actual subject:

- a **title card** establishes a programme's thesis;
- a **rundown** gives order only where order affects the work;
- a **transcript hierarchy** separates statement, context, and annotation;
- an **editorial decision** is distinct from an observation or metric;
- a **channel function** is an operating practice, not software.

Structural devices must encode one of those meanings. If a line, label, frame, index, or color field has no content job, remove it.

### Boldness budget

Spend visual boldness once per viewport. The homepage title card and the cobalt learning statement are the strongest moments. Adjacent sections become quieter so those moments retain authority.

## 4. Visual foundation

### Color tokens

| Token | Value | Required use |
|---|---:|---|
| Paper | `#F7F7F5` | default canvas |
| White | `#FFFFFF` | selected reading bands where separation is needed |
| Ink | `#0B0B0B` | primary text, rules, title-card field |
| Muted ink | `#525252` | secondary copy |
| Cobalt | `#184AE8` | the one signal/annotation color |
| Mid rule | `#A9A9A9` | strong non-text borders |
| Quiet rule | `#D5D5D5` | secondary dividers |
| Dark secondary | `#C7C7C7` | secondary text on Ink |
| Dark rule | `#555555` | dividers on Ink |
| Focus light | `#FFFFFF` | focus ring on Cobalt or Ink |
| Focus dark | `#0B0B0B` | focus ring on Paper or White |

Verified contrast ratios for the planned principal pairs are:

- Ink on Paper: 18.35:1;
- Muted ink on Paper: 7.28:1;
- Cobalt on Paper: 6.15:1;
- White on Cobalt: 6.60:1;
- White on Ink: 19.68:1.

Cobalt may carry emphasis but must never be the only carrier of state or meaning. Do not introduce cream, beige, tan, terracotta, amber, teal, gradients, or extra brand accents.

### Typography

Use locally hosted IBM Plex files under the SIL Open Font License:

- **Display:** IBM Plex Sans Condensed, weights 500 and 600;
- **Body:** IBM Plex Sans, weights 400, 500, and 600;
- **Utility:** IBM Plex Mono, weights 400 and 500.

Implementation requirements:

- commit only the required WOFF2 files and the applicable license notice;
- use `font-display: swap`;
- do not load fonts from Google Fonts, a CDN, or another runtime service;
- use system fallbacks after Plex, but do not use the fallback as the primary intended design;
- reserve uppercase for short display statements and compact utility labels;
- do not uppercase paragraphs, long navigation labels, FAQs, or support copy;
- maintain readable body measure, approximately 60–68 characters;
- avoid body weights below 400;
- prevent heading clipping and forced fixed heights at every viewport.

The type system is intentionally sans-led. A serif must not be reintroduced as a shortcut for “editorial.”

### Type scale

- Homepage title-card statement: `clamp(3rem, 8vw, 7.5rem)`, condensed 600, line-height 0.88–0.94.
- Inner-page H1: `clamp(3rem, 7vw, 6.5rem)`, condensed 600.
- Section H2: `clamp(2.25rem, 5vw, 4.5rem)`, condensed 500 or 600.
- H3: `clamp(1.35rem, 2.5vw, 2rem)`, condensed 500.
- Body: `clamp(1rem, 0.3vw + 0.95rem, 1.125rem)`, line-height 1.55–1.68.
- Utility labels: 0.6875–0.8125rem, Mono 500, line-height at least 1.35.

Exact clamp values may be tuned in-browser, but hierarchy and weight roles must remain stable.

### Geometry, rules, and space

- Default corner radius is zero.
- A radius is allowed only when required by an existing native control and must not become a visual motif.
- Do not use decorative box shadows.
- Use 1px rules, whitespace, background changes, and type scale for hierarchy.
- Preserve a 12-column wide-screen grid, six-column middle layout, and one-column narrow source order.
- Use fluid side gutters from 20px to 64px and cap the primary layout near 1440px.
- Section depth must vary according to content; do not apply one identical section component everywhere.
- All interactive controls keep a practical minimum 44px target.

## 5. Signature element: homepage title card

The homepage opens with one full-width 16:9-inspired black title card below the global header. It is the signature element of the system.

Required content:

- utility: `Method, not software`;
- utility: `Private review`;
- H1: `We build the YouTube function inside your business.`;
- summary: the existing approved homepage summary from the content source;
- fit line: the existing approved homepage fit line;
- primary and secondary calls to action from the governing content model.

Required treatment:

- black field, white statement, quiet gray supporting copy, one cobalt position marker;
- strong lower-left statement placement on wide screens;
- a content-bearing caption rail, not video controls;
- no play icon, progress bar, waveform, duration, recording light, view counter, fake timecode, or thumbnail treatment;
- no autoplay, video embed, or canvas animation;
- no assumption that the H1 itself is an image; it remains selectable semantic text;
- preserve one H1 and the existing document outline.

The frame may become taller than 16:9 when content or viewport width requires it. Readability and complete content take priority over maintaining an exact ratio.

On inner routes, do not repeat the black title card. Use a quieter editorial page-intro composition so the signature remains specific to Home.

## 6. Global composition and component mapping

### Header and footer

**SiteHeader** becomes a square, ruled three-zone structure on wide screens: typographic wordmark, primary navigation, and a cobalt CTA area. It must retain the current active-page semantics and accessible narrow-screen menu behavior. The CTA label may wrap rather than shrink below readable size.

**SiteFooter** uses the same typographic system and content-bearing rule structure. It must not become a dense sitemap, faux newsletter, or logo wall.

### Page introductions

**PageIntro** gains two explicit variants:

- `home`: the title-card treatment defined above;
- `standard`: an asymmetric but quiet inner-page introduction.

The variant must be a documented component input, not inferred from fragile selectors or route-specific DOM position.

### Content sections

The present content objects remain the source of truth. Their visible treatments change as follows:

| Existing component/content | Approved treatment |
|---|---|
| `SectionHeading` | content-bearing utility label plus condensed statement; no automatic decorative index |
| `FailureModeCard` | unboxed, ruled question/response composition with deliberately varied wide-screen placement |
| `OutcomeShift` | clear from/to editorial row, not a floating card |
| `ServiceCard` | full-width engagement row; no package-card grid |
| `ProcessRail` | full ordered presentation on `/system/`, where sequence is meaningful |
| `DecisionLoop` | observation → interpretation → assigned decision relationship; no decorative step badges |
| `MeasurementLayer` | ruled definition/table structure; never dashboard chrome |
| `FitMatrix` | explicit Strong fit / Poor fit columns or stacked sections |
| `EvidenceReserved` | candid ruled control-state block; never a fake case study |
| `FAQList` | native or equivalent disclosure semantics with restrained rules |
| `Notice` | square, text-led status region without badge styling |
| `PrimaryCTA` | solid cobalt or Ink action plus plain supporting copy; no pill treatment |

The Home page may summarize the connected method, but the full numbered or staged process belongs on `/system/`. Any sequence used elsewhere must express a real dependency, such as observation → interpretation → decision, and must not be numbered for decoration.

### Route character

The seven routes retain the approved information architecture while receiving distinct pacing:

- `/`: thesis, operating gap, learning distinction, engagement paths, qualification, and guarded evidence;
- `/system/`: the most systematic route, with the full meaningful process sequence;
- `/services/`: engagement constraints presented as editorial rows, not pricing tiers;
- `/fit/`: qualification contrasts with direct labels and no score gimmick;
- `/results/`: measurement logic and proof governance, never invented performance UI;
- `/about/`: method and operating principles, without fabricated founder lore or portraits;
- `/apply/`: fit-review path and current private-prototype boundary, without implying a live submission workflow.

Do not force every route into the homepage's exact section order or visual cadence.

## 7. Responsive behavior

### Wide: 1024px and above

- Use the 12-column grid and intentional asymmetry.
- Keep body copy within readable measure even when a field spans the viewport.
- Allow offset sections only when source order remains obvious.
- The title card may use a 16:9 minimum proportion inside the capped page frame.
- Cap content width instead of scaling line length or type indefinitely.

### Middle: 600–1023px

- Use a six-column adaptation.
- Collapse the header before labels become crowded.
- Reduce asymmetric offsets; do not create large empty gaps that detach related copy.
- Allow the title card to grow vertically as the statement wraps.

### Narrow: 320–599px

- Use one-column source order.
- Keep at least 20px side gutters.
- Convert staggered editorial compositions to an ordered vertical stack.
- The title card becomes a tall frame rather than shrinking type into an exact 16:9 box.
- Stack engagement rows, comparisons, fit sections, and caption rails without content loss.
- No horizontal page scroll at 320 CSS pixels or at 200% text zoom.
- Preserve 44px targets, visible focus, and usable navigation.

Content must tolerate headings approximately 50% longer, avoid fixed-height text containers, and retain logical reading order without CSS.

## 8. Smooth-scrolling behavior

### Intent

Smooth scrolling should make desktop wheel and trackpad movement feel more controlled and continuous. It must remain understated and must not become a visible “effect.”

The selected library is `lenis`, reviewed at version `1.3.25` on 2026-07-18. It is small, has zero runtime dependencies, and runs over native browser scroll. The implementation must pin the exact installed version in `package.json` and `package-lock.json`.

### Required Lenis configuration

```ts
new Lenis({
  autoRaf: true,
  anchors: true,
  smoothWheel: true,
  syncTouch: false,
  lerp: 0.12,
  wheelMultiplier: 0.9,
  stopInertiaOnNavigate: true,
});
```

Configuration rules:

- do not add `duration` when `lerp` is set;
- do not enable `syncTouch`; touch scrolling stays native;
- do not enable infinite scroll, horizontal scroll, scroll snapping, or nested-scroll scanning;
- do not add GSAP, ScrollTrigger, animation libraries, or a custom RAF loop;
- import the package's recommended `lenis/dist/lenis.css` locally through the build;
- keep the current CSS smooth-scroll behavior as a no-JavaScript fallback, while Lenis's active class prevents double smoothing;
- use CSS `scroll-margin-top` or equivalent for anchored headings when the header would obscure them.

### Progressive enhancement and lifecycle

Put initialization in an isolated `src/scripts/smooth-scroll.ts` module and load it once through `BaseLayout.astro`.

Runtime behavior:

1. Check `window.matchMedia('(prefers-reduced-motion: reduce)')` before construction.
2. If reduction is requested, do not construct Lenis and retain immediate native scroll.
3. If motion is allowed, construct one Lenis instance for the window.
4. If the media query changes to reduction during the session, destroy the active instance and return to native scrolling.
5. If the media query changes back, create one new instance without duplicating listeners.
6. Destroy the instance and listeners during any applicable page lifecycle cleanup.
7. If import or initialization fails, the page remains scrollable through native browser behavior.

The module must avoid global mutable state beyond one guarded instance and must not throw an error that interrupts other page behavior.

### Anchors, navigation, and focus

- Regular same-page anchors remain enabled through Lenis.
- Internal route navigation stops residual inertia before leaving the page.
- The skip link remains an immediate accessibility path and must place keyboard focus on `#main-content` without an animated delay.
- Hash changes, back/forward navigation, and direct URLs with fragments must reach the intended target.
- PageDown, PageUp, Home, End, Space, Shift+Space, arrow keys, and browser find remain native and usable.
- Focus must never be moved merely because scrolling occurs.

If Lenis's default anchor handling conflicts with skip-link focus or history behavior, the implementation must exempt the skip link and handle it through the browser's native anchor path. Passing the browser tests matters more than preserving a particular initialization shorthand.

### Explicit motion exclusions

Lenis is the only new motion dependency. The following remain disallowed:

- scroll locking or transform-based scroll hijacking;
- scroll-linked reveal sequences;
- parallax;
- section snapping;
- pinned storytelling panels;
- animated counters;
- cursor followers;
- continuous loops;
- decorative entrance animation;
- momentum on touch devices.

This addendum narrows the original “no scroll hijacking” rule: native-scroll Lenis enhancement is allowed, while scroll locking, transformed content, forced section navigation, and loss of browser controls remain prohibited.

## 9. Accessibility requirements

All original WCAG 2.2 AA requirements remain active. The redesign additionally requires:

- semantic text in the title card rather than text baked into an image;
- a visible focus ring with at least 2px apparent thickness and adequate contrast;
- underlined or otherwise non-color-only body links;
- a functional skip link in both native and Lenis modes;
- no loss of keyboard scrolling or browser history behavior;
- reduced-motion mode verified after initial load and after a live preference change;
- VoiceOver reading order that matches the visual narrative;
- no ARIA added where native HTML already expresses the relationship;
- no tiny utility copy below 11px equivalent;
- no information encoded only by cobalt, position, or a connecting rule.

## 10. Performance and dependency budget

Lenis is the single approved client-side behavior dependency. Its use is an explicit exception to the original 0KB target, not to the 25KB compressed hard budget.

Requirements:

- keep total first-party client JavaScript below 25KB compressed per page;
- do not add another client framework or hydrate Astro components for this redesign;
- bundle Lenis locally; no CDN or runtime network fetch;
- self-host fonts and preload only files needed above the fold;
- use `font-display: swap` and verify that fallback-to-Plex swap does not cause clipped text;
- keep CSS below the original 60KB compressed hard budget;
- preserve static HTML and core usability with JavaScript disabled;
- run a dependency audit and record any unresolved finding before acceptance.

Known Lenis constraints to verify rather than hide:

- Safari may cap smooth scrolling at 60fps and at 30fps in low-power mode;
- wheel events over an iframe are not forwarded;
- fixed-position elements may lag on older pre-M1 macOS Safari;
- nested scroll containers require explicit native-scroll treatment.

The current prototype has no approved iframe or nested application scroller. Do not add either as part of this work.

## 11. Implementation boundaries

### In scope

- replace the global color, typography, geometry, and section-composition system;
- add local IBM Plex font assets and license notice;
- add explicit PageIntro variants;
- restyle and, where necessary, minimally refactor existing Astro components;
- recompose all seven pages using existing approved content;
- add pinned Lenis dependency and isolated smooth-scroll initialization;
- expand automated and browser checks for the new visual and motion behavior;
- verify the private prototype at the defined viewports and interaction modes.

### Out of scope

- changing positioning, claims, evidence states, or service truth;
- adding photography, generated imagery, logos, testimonials, or case studies;
- activating a production application form or any external service;
- analytics, tracking, cookies, CMS, database, authentication, or personalization;
- production launch, indexing, deployment, or public-domain changes;
- autoplay media, embeds, WebGL, canvas effects, GSAP, or scroll animation;
- redesigning the content model merely to make styling easier;
- unrelated dependency upgrades or refactors.

## 12. Verification plan

### Static and automated checks

Run the repository's existing verification chain and extend it where needed:

```text
npm run check
npm test
npm run validate:content
npm run build
npm run validate:build
npm run verify:browser
npm audit
```

Automated coverage must confirm:

- all seven routes build and retain one H1;
- no approved content or claim-control markers disappear;
- local font assets resolve with no runtime font service;
- the Lenis bundle loads once and creates no console error;
- reduced-motion mode does not initialize smoothed wheel behavior;
- no horizontal overflow at the tested narrow viewport;
- skip link, navigation, FAQ disclosures, and all links remain keyboard accessible;
- Axe reports no serious or critical findings on representative routes.

### Browser and interaction matrix

Verify at minimum:

- Chromium desktop at 1440px, 1024px, 768px, and 320px widths;
- Safari/WebKit behavior where the available local browser tooling permits;
- keyboard-only navigation and scrolling;
- mouse-wheel and trackpad-style delta input on desktop;
- native touch-style scrolling at a mobile viewport;
- `prefers-reduced-motion: reduce` before load;
- live reduced-motion preference change after load;
- JavaScript disabled;
- 200% text zoom and narrow reflow;
- direct fragment load, same-page anchor, skip link, route navigation during inertia, and browser back/forward;
- no clipped fixed/sticky header, footer, title-card content, or focus outline;
- no unexpected layout shift during local font swap.

Browser automation can verify state and regressions, but perceived scroll restraint and section pacing require a manual visual pass.

## 13. Acceptance criteria

The redesign is ready for owner review only when all of the following are true:

1. The cream/serif/terracotta system is fully removed from production source.
2. The site uses the approved Paper, Ink, Cobalt, and cool-gray palette without gradients or extra accents.
3. IBM Plex Sans Condensed, Sans, and Mono are locally hosted and licensed.
4. Home has one semantic title-card signature and inner routes do not repeat it.
5. Components no longer read as a repeated grid of rounded marketing cards.
6. Rules, labels, numbering, and color fields all carry content meaning.
7. All seven routes retain their approved content, claims boundaries, navigation, and CTA boundaries.
8. Lenis smooths desktop wheel input using the approved restrained configuration.
9. Touch, keyboard, skip-link, fragment, history, reduced-motion, and no-JavaScript scrolling remain usable.
10. No parallax, scroll-linked reveal, snapping, scroll lock, or additional animation system is present.
11. The full verification chain passes, with any manual limitation stated explicitly.
12. The work remains a private, noindex prototype and is not deployed or launched.

## 14. Source references

The direction and implementation constraints were informed by:

- Anthropic frontend design guidance: <https://github.com/anthropics/skills/blob/main/skills/frontend-design/SKILL.md>
- Addy Osmani frontend UI engineering guidance: <https://github.com/addyosmani/agent-skills/blob/main/skills/frontend-ui-engineering/SKILL.md>
- Joshua David Thomas frontend design principles: <https://github.com/joshuadavidthomas/agent-skills/blob/main/frontend-design-principles/SKILL.md>
- IBM Plex source and license: <https://github.com/IBM/plex>
- Lenis official repository, API, limitations, and license: <https://github.com/darkroomengineering/lenis>

These sources provide design and implementation constraints, not content claims for the site.

## 15. Written-spec review gate

Before implementation planning begins, the owner must review this written addendum and either:

- approve it as written; or
- identify a specific change to visual direction, typography, title-card behavior, component treatment, Lenis behavior, or verification scope.

After written approval, create the implementation plan from this addendum and the governing 2026-07-17 specification. Do not begin the production-code redesign from this document alone while its written review state remains awaiting owner review.
