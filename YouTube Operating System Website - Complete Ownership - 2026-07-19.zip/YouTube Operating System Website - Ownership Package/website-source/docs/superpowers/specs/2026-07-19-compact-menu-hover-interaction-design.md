# Compact Menu Hover Interaction Design

**Date:** 2026-07-19

**Status:** Owner-approved design; implementation not started

**Repository:** `youtube-operating-system-site`

**Governing baseline:** `138bf9cb9bff05704573f63b7e24d444d3349362`

## 1. Purpose

Refine the compact navigation so it opens automatically under a fine-pointer cursor, drops slowly and continuously, and gives each link a restrained premium response. The result must feel quieter and more deliberate than the current native snap-open disclosure without adding colorful glow, theatrical motion, or generic “vibecoded” effects.

This design changes only the compact `<details class="nav-disclosure">` navigation shown below the existing `72rem` desktop breakpoint. The wide desktop navigation remains visible and unchanged.

## 2. Approved direction

The approved direction is the refined **Editorial Shutter**:

- compact, content-led width;
- slow architectural reveal;
- soft but non-pill geometry;
- white, ink, neutral rules, and one restrained cobalt cue;
- number-free navigation rows;
- monochrome cursor response rather than colorful illumination;
- no bounce, stagger, gradient, spotlight, or neon glow.

The visual companion approval established the following exact geometry and feel:

- panel width: `12.75rem`, capped on narrow viewports by `calc(100vw - 2rem)`;
- trigger radius: `7px`;
- panel radius: `8px`;
- row radius: `5px`;
- opening duration: `1050ms`;
- current-page and hover accent: a `2px` cobalt inset edge;
- the long “Request a strategy conversation” row may wrap naturally;
- no visible `01`, `02`, or other numeric row labels.

The `12.75rem` width is deliberately sized around the longest navigation word plus useful horizontal padding, not the full width of the longest sentence. It keeps the panel compact while allowing the CTA to wrap.

## 3. Scope

### In scope

- Automatically open the compact disclosure when a hover-capable, fine pointer enters it.
- Keep it open while the pointer or keyboard focus remains within the disclosure.
- Close it smoothly after the pointer leaves, with a short crossing grace period.
- Preserve tap, click, Enter, Space, Escape, focus, reduced-motion, and no-JavaScript behavior.
- Add the approved compact wrapper structure needed for a natural-height reveal.
- Replace the current rigid `20rem` panel width and square geometry with the approved dimensions.
- Refine compact navigation rows and the current-page treatment.
- Extend source and browser verification for the new interaction.

### Out of scope

- Changing the wide desktop navigation at or above `72rem`.
- Changing route labels, route count, CTA copy, page content, claims, or launch status.
- Adding a menu library, animation library, pointer-tracking library, or new dependency.
- Adding cursor-following light, gradients, blur fields, glass effects, bounce, spring motion, or staggered link entrances.
- Changing Lenis settings or page scrolling.
- Deployment, publishing, analytics, forms, data collection, or third-party requests.

## 4. Structure and visual system

`SiteHeader.astro` keeps the native `<details>` and `<summary>` elements. A reveal wrapper is added between the summary and mobile navigation so CSS can animate the navigation’s natural height without a guessed `max-height`.

Conceptual structure:

```html
<details class="nav-disclosure" data-menu-state="closed">
  <summary>...</summary>
  <div class="nav-disclosure__reveal">
    <div class="nav-disclosure__reveal-inner">
      <nav aria-label="Mobile navigation">...</nav>
    </div>
  </div>
</details>
```

The reveal wrapper uses a grid row transition from `0fr` to `1fr`; its inner wrapper uses `min-height: 0` and overflow containment. This provides a continuous natural-height reveal and avoids the uneven velocity caused by a large arbitrary `max-height`.

JavaScript adds `data-menu-enhanced` only after the state controller mounts. CSS gives `details[open]:not([data-menu-enhanced])` an immediate visible reveal, so the server-rendered disclosure continues to work when JavaScript is unavailable even though its initial `data-menu-state` is `closed`.

### Trigger

- Retains a minimum `44px` target.
- Uses a white surface, one-pixel ink border, `7px` radius, and two-pixel cobalt lower inset.
- The plus mark rotates to 45 degrees over `820ms` using the same restrained easing family.
- Hover may add only a low neutral shadow; no colored outer glow.

### Panel

- Inline size: `min(12.75rem, calc(100vw - 2rem))`.
- Right-aligned to the trigger.
- White background, one-pixel ink border, `8px` radius, and a low neutral black shadow.
- No gradient, transparency wash, blur, or colored halo.

### Navigation rows

- Minimum `44px` target and `5px` radius.
- White background, ink text, and neutral separators at rest.
- No visible numeric suffixes.
- The current page retains `aria-current="page"` and a quiet two-pixel cobalt inset edge. The existing visible “Current” suffix becomes visually hidden so state remains available to assistive technology without widening the compact panel.
- Hover and keyboard focus shift the row to ink with white text, add the same two-pixel cobalt inset edge, and move the left padding by no more than `0.25rem`.
- The response uses a low neutral shadow only. It must not resemble a neon or backlit gaming control.

## 5. Motion contract

### Opening

- Trigger: immediate on fine-pointer entry; no hover-intent delay.
- Height and vertical position: `1050ms cubic-bezier(0.16, 1, 0.3, 1)`.
- Opacity: `680ms ease` with a `100ms` delay.
- Plus rotation: `820ms cubic-bezier(0.16, 1, 0.3, 1)`.
- No overshoot, bounce, spring, or item stagger.

### Closing

- Pointer-leave grace: `180ms` before closing begins.
- Height and position: `620ms cubic-bezier(0.4, 0, 0.2, 1)`.
- Opacity: `360ms ease` without a delay.
- The native `open` attribute remains present during the visual close and is removed only after the closing transition completes. This prevents the browser from snapping the panel away before it can animate.
- Re-entering before finalization cancels both the grace timer and closing finalizer, then reverses cleanly toward open.

### Link response

- Background and color: `320ms` maximum.
- Padding/edge movement: `420ms` maximum.
- No pointer-coordinate tracking or continuous cursor-following effect.

### Reduced motion

Under `prefers-reduced-motion: reduce`, reveal, close, mark rotation, row movement, opacity, and shadow transitions become effectively immediate. Automatic hover opening may remain, but it must not animate.

## 6. Interaction state and lifecycle

A focused module, `src/scripts/navigation-menu.ts`, owns the enhanced behavior. It is imported by the existing processed client entry so the built site continues to emit exactly one local JavaScript module.

The module manages these states through `data-menu-state`:

- `closed` — native disclosure not open;
- `opening` — `open` is present and the collapsed wrapper is preparing to animate;
- `open` — reveal target is fully open;
- `closing` — visual close is running while native `open` remains present.

### Fine-pointer hover

- Enhancement is eligible only when `(hover: hover) and (pointer: fine)` matches.
- Pointer entry cancels pending close work and opens the disclosure.
- Pointer leave starts the `180ms` grace period.
- A close does not start while keyboard focus remains inside the disclosure.
- Pointer re-entry reverses an in-progress close without a snap.

### Click, touch, and keyboard

- The summary remains the one activation control.
- With JavaScript, summary activation is coordinated by the state module so both open and close can animate.
- Tap, mouse click, Enter, and Space toggle the disclosure.
- Escape closes it and returns focus to the summary.
- On touch or a non-hover pointer, the menu stays open until the visitor toggles it, presses Escape, selects navigation, or navigates away.
- The wide desktop menu receives no event behavior from this module.

### Focus and navigation

- Focus inside the panel prevents pointer-leave closure.
- Navigation links keep visible focus outlines and practical target sizes.
- No focus is moved on hover-open.
- Opening creates no history entry and persists no state.

### Mounting and cleanup

- The module returns a cleanup function that removes media-query, pointer, click, key, focus, and timer work.
- Existing `pagehide` and BFCache `pageshow` handling mounts and unmounts the navigation enhancement with the Lenis lifecycle.
- Cleanup clears the `180ms` grace timer and any `620ms` closing finalizer.

## 7. Failure and fallback behavior

- **JavaScript unavailable:** native `<details>` click, touch, and keyboard disclosure remains usable through the explicit `details[open]:not([data-menu-enhanced])` CSS fallback; automatic hover opening and animated close are absent.
- **Reduced motion:** state changes are immediate and native-feeling.
- **Hover media changes:** the enhancement stops hover-specific behavior and leaves touch/click toggling usable.
- **Interrupted close:** pointer re-entry or renewed focus cancels finalization and restores the open target.
- **Missing disclosure:** the module exits without throwing or changing other page behavior.
- **Route navigation or BFCache:** timers and listeners are removed; no stale menu state or residual animation survives navigation.

## 8. Verification design

Implementation follows test-driven development. A failing contract is added before production code.

### Source contracts

- Compact header keeps native `<details>` and `<summary>` semantics.
- Reveal and inner wrappers exist.
- Approved width, radii, durations, easing, current edge, and reduced-motion overrides are explicit.
- No numeric row label, gradient, blur, cursor tracking, animation library, or new dependency is introduced.
- The navigation module checks the fine-pointer media query, has grace/finalizer cleanup, and supports Escape.
- The existing client entry imports the navigation module while generated output remains one local module.

### Browser behavior

At a compact fine-pointer viewport:

- moving the pointer onto Menu sets native `open` and enters the opening/open state;
- measured panel height increases between an early and mid-animation sample and reaches its final height after the approved duration;
- crossing from trigger into the panel does not close it;
- moving outside preserves it during the grace window, then closes smoothly;
- re-entry during grace or closing cancels finalization;
- hovering a row produces ink background, white text, and the two-pixel cobalt edge;
- panel width is approximately `12.75rem` and does not overflow at 320px.

Existing and extended checks also require:

- Enter/Space toggling, Escape closure, focus retention, and `44px` targets;
- touch/non-hover activation without hover dependency;
- instant reduced-motion behavior at initial load and after a live preference change;
- no-JavaScript content, navigation, and native disclosure behavior;
- no change to the wide desktop navigation;
- no horizontal overflow, console error, failed request, or third-party request;
- all seven routes, existing Axe scans, claims guards, build guards, and budget ceilings remain green.

Timing assertions must use broad state/monotonicity bounds rather than exact frame coordinates so the test verifies real motion without becoming a frame-timing benchmark.

## 9. Acceptance criteria

The work is accepted only when:

1. The compact menu opens automatically under a fine-pointer cursor and visibly takes about one second to reveal.
2. Moving into the panel or back during closing never causes a snap or accidental disappearance.
3. The panel is compact, number-free, softly shaped, and approximately `12.75rem` wide.
4. Row response is premium and restrained: monochrome inversion, one cobalt edge, no colorful glow.
5. Touch, click, keyboard, Escape, focus, reduced motion, and no-JavaScript fallbacks pass.
6. Wide desktop navigation, page scrolling, route content, claims, privacy, and launch blockers remain unchanged.
7. The site still builds seven routes with one local client module, zero third-party requests, and the existing JS/CSS limits.
8. Representative compact-menu screenshots and live interaction inspection show no clipping, overflow, focus collision, exaggerated rounding, or “vibecoded” effect language.

## 10. Private-prototype boundary

This interaction polish does not change the product gate. The site remains a local private prototype. Public launch, deployment, forms, evidence publication, identity, analytics, and data collection remain blocked and outside this work.
