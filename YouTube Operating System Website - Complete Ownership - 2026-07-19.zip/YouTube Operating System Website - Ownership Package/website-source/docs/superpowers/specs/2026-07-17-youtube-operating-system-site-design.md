# YouTube Operating System Site — Design Specification

**Date:** 2026-07-17

**Status:** Written specification awaiting user review

**Mode:** Planner / design-spec writer

**Current gate:** Documentation only

**Primary CTA:** “Request a strategy conversation”

## 1. Objective

Create an English-first B2B authority website for a research-led YouTube strategy and production service. The website must make one category-level proposition clear:

> We build and operate the YouTube function inside your business.

The site explains a coordinated methodology that connects:

> Business goals → audience research → positioning → content architecture → production → publishing → analytics → business decisions

“YouTube Operating System” is the name of this service methodology. It must never imply that an internal application, client portal, dashboard, AI system, automated integration, or SaaS platform currently exists.

### Success criteria

The design succeeds when a qualified visitor can:

1. understand within the hero that the offer is an operated business function, not isolated video editing;
2. recognize why research, positioning, production, and learning must work as one loop;
3. determine whether their business and expectations fit the service;
4. understand the provisional engagement paths without invented pricing or availability;
5. distinguish method-led business outcomes from guarantees;
6. reach one clear next step: “Request a strategy conversation”;
7. encounter no fabricated proof, software screens, integrations, or capacity claims;
8. use the site across keyboard, screen reader, reduced-motion, mobile, tablet, and desktop contexts;
9. load the core experience as semantic static HTML with minimal dependencies and no required client JavaScript;
10. understand, from a separate implementation-plan session, exactly what content, components, states, and verification evidence the prototype needs.

### Non-success signals

- The visitor describes the company as an editing shop, creator agency, or SaaS product.
- The site implies fast, guaranteed, viral, or revenue-certain results.
- A diagram resembles a product dashboard or feature screenshot.
- The conversion path collects data in the private prototype.
- Missing facts are smoothed over with plausible copy rather than labeled, omitted, or blocked.

## 2. Truth model and scope boundary

The site has five truth classes:

| Class | Meaning | Website treatment |
|---|---|---|
| Confirmed from source material | Directly appears in a supplied input, but may not be independently verified | Use only when it describes intent or method; performance facts still require evidence |
| Supported but requiring evidence | Anecdotal or internally described outcome/capability | Keep out of public copy until the claims register is cleared |
| Provisional strategy | Approved working choice for positioning, architecture, copy, or design | Use in the private prototype with conservative wording |
| Future hypothesis | Possible platform, automation, operating scale, or product direction | Keep internal and outside website scope |
| Prohibited until verified | Likely to mislead without evidence or permission | Omit from public-facing output |

The source and claims registers control this classification. A broader source statement never overrides the narrower public-use decision in `docs/claims-register.md`.

## 3. Audience and anti-audience

### Primary audience

Established, expertise-led, sufficiently high-margin businesses for which a purchase requires education, comparison, reputation, and trust. Typical characteristics:

- the business has a real, sellable product or service;
- an expert, founder, practitioner, or credible spokesperson can participate;
- the buyer needs to understand a complex decision rather than react to a commodity offer;
- useful knowledge, examples, and customer questions already exist inside the business;
- the team can sustain review and recording responsibilities;
- leadership accepts YouTube as a compounding, iterative channel rather than an instant lead source;
- the business is prepared to connect content decisions to business priorities and qualitative demand signals.

Examples may include professional services, specialized consultancies, medical or legal businesses, technical B2B firms, high-consideration education, real estate/development, financial services, and expertise-led technology companies. These examples describe fit patterns, not claims of sector-specific experience.

### Buyer roles

- Founder or owner seeking a repeatable authority channel.
- Marketing leader who needs a coherent YouTube operating model.
- Subject-matter expert with strong knowledge but fragmented production.
- Business development or revenue leader who needs better buyer education.

### Anti-audience

The site must explicitly discourage prospects who:

- require immediate leads or a guaranteed payback date;
- want virality, publishing volume, or low-cost editing as the primary outcome;
- lack a defined offer or credible expertise;
- cannot provide subject-matter access, source material, or review time;
- judge the work only by views or subscriber totals;
- repeatedly delay inputs but expect unchanged delivery timing;
- expect the operator to invent expertise, evidence, or opinions on the company’s behalf;
- want internal YouTube software, a client portal, or an AI content product.

The anti-audience language should feel diagnostic and respectful, not elitist.

## 4. Positioning

### Category

An operated YouTube function for business.

### Core promise

> We build and operate the YouTube function inside your business.

### Supporting explanation

> Research, positioning, content architecture, production, publishing, and learning—connected to the decisions your business needs to make.

### Value framing

The service turns scattered video activity into a coordinated operating method. It is designed to help a business clarify its point of view, teach the market, answer buyer questions, accumulate a useful content library, and learn from audience behavior. Those are intended functions and possible outcomes, not guarantees.

### Differentiation

| Dimension | Fragmented production pattern | YouTube Operating System method |
|---|---|---|
| Starting point | A requested video or publishing quota | Business context, audience evidence, and positioning |
| Unit of work | An individual deliverable | A connected content and learning system |
| Topic selection | Inspiration, trends, or internal preference | Audience questions, market patterns, and business relevance |
| Production | Hand-offs between isolated specialists | Defined decisions, roles, inputs, and review points |
| Measurement | Views and subscribers in isolation | Attention, audience behavior, qualified-demand signals, and business learning |
| After publishing | Delivery is complete | Evidence feeds the next content and positioning decision |

This table describes the proposed method. It must not make unverifiable claims about every agency or production company.

### Voice

- clear, exact, calm, and commercially literate;
- confident about process, restrained about outcomes;
- specific enough to show operating depth without jargon dumping;
- direct about fit, trade-offs, participation, and time horizons;
- free of creator-economy hype, AI hype, adversarial “domination,” and vanity language.

## 5. Messaging hierarchy

### Level 1 — Category promise

“We build and operate the YouTube function inside your business.”

### Level 2 — The problem

Publishing videos is not the same as building a YouTube system. Fragmented research, unclear positioning, irregular production, and isolated analytics make output difficult to sustain and difficult to learn from.

### Level 3 — The method

Business goals guide audience research; research sharpens positioning; positioning organizes content; content moves through a defined production system; publishing creates evidence; evidence informs the next business and content decision.

### Level 4 — Intended business value

The method is designed to support clearer category education, stronger buyer understanding, more consistent market presence, reusable sales education, and better-informed content decisions. Copy must use “designed to,” “can support,” or equivalent qualified language.

### Level 5 — Engagement

The company can provisionally diagnose, design, launch, operate, or help install the method inside a client team. Final availability is controlled by LB-02.

### Level 6 — Qualification

The service fits established businesses willing to provide expertise, participate in decisions, and invest in a compounding channel. It does not fit instant-result or output-only expectations.

### Level 7 — Evidence

Proof is published only when the exact claim, evidence, timeframe, role, and permission are approved. Until then, the site explains what will be measured.

### Level 8 — CTA

“Request a strategy conversation.”

## 6. Information architecture

### Global navigation

Order: Home, The System, Services, Who It Is For, Results, About, Apply.

- Desktop: text wordmark at left, primary navigation centered or right, high-emphasis CTA at far right.
- Mobile: wordmark and one accessible navigation control. The expanded state exposes all seven routes and preserves visible focus.
- Footer: short method statement, route list, approved business identity/contact when LB-01 closes, privacy/terms when required, and no unapproved social icons.
- The active page is conveyed by more than color and uses `aria-current="page"`.

### 6.1 Home — `/`

**Visitor question:** What is this, why is it different, and should I continue?

Section contract:

1. **Hero**
   - Eyebrow: “A YouTube function for established businesses.”
   - H1: “We build and operate the YouTube function inside your business.”
   - Support: the approved research-to-decisions explanation.
   - Primary CTA: “Request a strategy conversation.”
   - Secondary link: “See how the system works.”
   - Fit line: “For expertise-led businesses where buyers need explanation, comparison, and trust.”
2. **Publishing is not a system**
   - State the gap between making videos and operating a business function.
   - Use four failure-mode cards: unclear position; topics without evidence; production without ownership; analytics without decisions.
3. **The methodology loop**
   - Show seven connected stages: business context; audience evidence; positioning; content architecture; production; publishing; learning and decisions.
   - Use a process rail/loop, not a software screenshot.
4. **What the system is designed to change**
   - Clarify the intended shifts: scattered ideas to a content thesis; isolated videos to a library; internal assumptions to audience evidence; reporting to decisions.
   - Avoid numeric outcomes.
5. **Ways to engage**
   - Summarize diagnostic, strategy, launch, managed operation, and team enablement paths.
   - Link to Services; mark availability as subject to fit and scope.
6. **Fit / poor fit**
   - Two-column diagnostic with a direct link to Who It Is For.
7. **How the method differs**
   - Use the comparison dimensions in Section 4, framed as operating patterns rather than attacks on competitors.
8. **Claim-safe proof area**
   - Private prototype: internal evidence-reserved module referencing claims C-001–C-005 and C-017; visually distinct from a case study.
   - Production: verified cases or measurement framework under D-011 and LB-03.
9. **FAQ**
   - “Is this a video production service?”
   - “How quickly should we expect results?”
   - “Do you guarantee views, leads, or revenue?”
   - “How involved does our team need to be?”
   - “Can you work with an internal production team?”
   - “Is the YouTube Operating System software?”
   - Answers reinforce service method, participation, iterative timing, no guarantees, and no existing software.
10. **Final CTA**
   - Restate fit and use the exact primary CTA.

**Home acceptance:** A first-time visitor can state the offer and its non-software boundary after reading the hero and first two sections.

### 6.2 The System — `/system/`

**Visitor question:** What actually happens, and how do decisions connect?

Section contract:

1. **Page introduction:** methodology, not software; the system exists as a coordinated service process.
2. **Seven-stage operating loop:** each stage shows its input, governing question, output, and dependency.

| Stage | Governing question | Output |
|---|---|---|
| Business context | What must YouTube help the business explain or learn? | priorities, offer context, constraints, decision criteria |
| Audience evidence | What does the intended buyer ask, misunderstand, compare, or fear? | evidence-backed questions and language patterns |
| Positioning | What useful role should the channel occupy? | audience promise, point of view, editorial boundaries |
| Content architecture | How do individual topics form a coherent library? | pillars, clusters, narratives, formats, intended viewer shifts |
| Production | What turns an approved idea into a publishable asset? | explicit owners, inputs, review states, and quality checks |
| Publishing | Is the asset packaged and released for the intended viewer and purpose? | published content with documented hypothesis and CTA |
| Learning and decisions | What happened, why might it have happened, and what changes next? | observations, hypotheses, and assigned decisions |

3. **Decision loop:** “What happened → what the evidence suggests → what we change.” Distinguish observation from interpretation.
4. **Client inputs and operator responsibilities:** show what the client supplies and what the service coordinates. Do not imply every task is always done-for-you.
5. **What the system is not:** no portal, API, automation, AI platform, CRM replacement, or guaranteed attribution.
6. **CTA:** strategy conversation for businesses that want to examine the whole operating function.

**Diagram accessibility:** Every visual loop has a nearby ordered text equivalent. Connectors do not carry meaning by color alone.

### 6.3 Services — `/services/`

**Visitor question:** What type of engagement might fit our current state?

Provisional service cards:

1. **Diagnostic session** — identify the most important operating constraint and next decision.
2. **Strategy intensive** — define audience evidence, positioning, content architecture, and a practical operating model.
3. **Channel launch or reset** — translate approved strategy into a coordinated production and publishing foundation.
4. **Ongoing YouTube operation** — coordinate research, planning, production, publishing, and the learning cadence.
5. **Internal-team enablement** — help a client team install roles, standards, reviews, and decision rhythms while execution remains internal.

Each card must contain:

- “Best when” fit condition;
- provisional scope expressed as categories, not fixed quantities;
- client participation expectations;
- intended decision or operating outcome;
- explicit exclusion of guaranteed performance;
- CTA to Apply.

Do not publish prices, fixed timelines, deliverable counts, capacity, or contractual commitments until LB-02 closes. Do not list the future SaaS model.

### 6.4 Who It Is For — `/fit/`

**Visitor question:** Are our business, team, and expectations ready for this?

Section contract:

1. **Fit thesis:** high-consideration buying and credible expertise make YouTube strategically useful.
2. **Strong-fit signals:** working offer, sufficient margin, identifiable expertise, real audience questions, leadership commitment, recording access, and willingness to learn over time.
3. **Readiness inputs:** business priorities, audience knowledge, offers, source material, examples, spokesperson availability, review owner, and reasonable decision cadence.
4. **Poor-fit signals:** instant leads, guaranteed virality, output-only procurement, unavailable expertise, no defined offer, or no review ownership.
5. **Self-assessment:** a short non-submitting checklist in the private prototype. It must not score, store, or transmit answers.
6. **CTA:** “Request a strategy conversation” for readers who meet most strong-fit signals.

Avoid revenue thresholds, employee counts, or geography restrictions until approved.

### 6.5 Results — `/results/`

**Visitor question:** How will value be judged, and what evidence exists?

Private-prototype section contract:

1. **Evidence principle:** views matter, but they are not sufficient on their own.
2. **Four measurement layers:**
   - attention: impressions, qualified reach, returning viewers;
   - content behavior: click-through, watch behavior, recurring questions, library use;
   - qualified demand: relevant inquiries, sales-conversation quality, content-assisted buyer education;
   - operating quality: cycle time, approval friction, learning cadence, reuse of insights.
3. **Decision format:** observation → interpretation → next decision.
4. **Evidence-reserved notice:** `[LB-03: verified case evidence or approved claim-free Results treatment]`. This is an internal review annotation, not a fake case card.
5. **No-guarantee note:** outcomes depend on the offer, market, expertise, participation, production, timing, and other factors.

Production has three allowed states only:

- verified case evidence approved through the claims register;
- claim-free measurement framework explicitly approved under LB-03;
- no Results route, with navigation and links updated.

Never use invented logos, anonymized stories that are still identifiable, fabricated quotes, unlabeled sample charts, vanity counters, or unsupported “before/after” graphics.

### 6.6 About — `/about/`

**Visitor question:** What does this company believe, and why is its way of working credible?

Section contract:

1. **Operating belief:** businesses need a durable YouTube function, not recurring content chaos.
2. **Principles:** business before content; evidence before topic volume; defined decisions and ownership; human judgment over uncontrolled automation; learning after publication.
3. **Method origin:** use conservative language about practical experience organizing research, content, production, localization, and channel learning. Do not publish channel counts or milestones.
4. **Company/founder story:** private prototype annotation `[LB-06: approved company and founder story]`. If no biography is approved for production, omit the personal profile and use an approved company-method narrative.
5. **Team representation:** describe required roles only if it is clear they are functions within an engagement, not necessarily employees. Do not publish ages, headcount, names, or credentials without approval.
6. **CTA:** invite a strategy conversation, not a parasocial founder pitch.

### 6.7 Apply — `/apply/`

**Visitor question:** What happens if I request a conversation, and what information will be needed?

Private-prototype section contract:

1. **Heading:** “Request a strategy conversation.”
2. **Expectation:** explain that the first step is a fit review, not an instant sales call or guaranteed engagement.
3. **Process:** request → fit review → strategy conversation if appropriate → clearly scoped next step.
4. **Static question preview:** company and role; website if relevant; offer/business model; current YouTube state; primary objective; main operating constraint; team participation; timing context.
5. **No-collection notice:** “This private prototype does not submit or store information.”
6. **Control behavior:** render the preview as explanatory content, not enabled form controls. There is no submit button, endpoint, mail link, scheduler, or external destination.
7. **Launch marker:** `[LB-05: approved production inquiry flow]`.

Production behavior is defined in Sections 15 and 16.

## 7. Conversion path

### Primary path

Home or interior page → Apply → fit expectations → production form → same-origin submission → fit review → human response → strategy conversation when appropriate.

### Secondary paths

- Hero → The System → Apply.
- Home failure modes → Services → Apply.
- Fit summary → Who It Is For → Apply.
- Measurement statement → Results → Apply.

### Conversion rules

- Use the exact CTA label consistently.
- A primary CTA always points to `/apply/`; it never opens an unapproved external tool.
- One primary CTA treatment per viewport is enough; persistent or sticky CTAs are not required.
- Secondary links are visually quieter and describe the destination.
- Do not use countdowns, scarcity, fake availability, exit popups, lead magnets, newsletter gates, chat prompts, or instant-booking claims.
- The Apply page explains uncertainty: submitting a request does not guarantee fit, acceptance, timing, or results.

## 8. Component and content boundaries

### Global components

- **SiteHeader:** identity, primary navigation, active state, CTA.
- **SiteFooter:** concise positioning, navigation, approved identity/contact, legal links.
- **PageIntro:** eyebrow, H1, restrained summary, optional CTA.
- **PrimaryCTA:** one label and destination, with page-specific supporting sentence.
- **SectionHeading:** optional eyebrow, heading, introduction, stable anchor.
- **ProcessRail / DecisionLoop:** semantic ordered list plus visual connectors.
- **FailureModeCard:** problem, consequence, system response; no icon-only meaning.
- **OutcomeShift:** from/to operating change with claim-safe language.
- **ServiceCard:** fit, scope categories, participation, intended outcome, exclusion.
- **FitMatrix:** strong-fit and poor-fit lists with non-color indicators.
- **MeasurementLayer:** metric category, interpretation caution, decision use.
- **EvidenceReserved:** internal-only prototype annotation; impossible to confuse with proof.
- **FAQList:** native headings and buttons if collapsible; content remains available without script.
- **Notice:** prototype, claim, privacy, or limitation notice with severity conveyed in text.

### Content boundaries

Keep content separate from presentation using stable IDs and English source files. Recommended logical groups:

- site identity and metadata;
- navigation and footer;
- methodology stages;
- failure modes and outcome shifts;
- services;
- fit and anti-fit signals;
- measurement layers;
- FAQs;
- CTA labels and supporting text;
- claim-controlled evidence items;
- launch-blocker annotations for private review.

Every evidence item must include a claims-register ID and a publication state in source content. Templates must fail closed when an evidence item is not approved: omit it from production rather than rendering a generic card.

### Content rules

- One H1 per page.
- Prefer one idea per paragraph and concrete subheadings.
- No content string should imply an application feature merely because it uses “system.”
- Do not embed English copy deeply in decorative components when the same component appears on multiple pages.
- English source content may live under an internal `en` namespace while URLs remain unprefixed for the first release.
- No CMS or live content API.

## 9. Visual system

### Design idea

The visual metaphor is an editorial operating manual: clear rails, annotations, stage relationships, decision loops, and deliberate whitespace. It should feel rigorous and human, not mechanical or software-like.

### Provisional color tokens

| Token | Value | Use |
|---|---:|---|
| Canvas | `#F6F2EA` | warm page background |
| Surface | `#FFFDFC` | cards and raised reading surfaces |
| Ink | `#122033` | primary text, dark CTA, dark sections |
| Muted ink | `#4B596A` | secondary text that still meets contrast |
| System teal | `#236B6A` | relationships, stage labels, links where underlined |
| Teal wash | `#DDEBE7` | process backgrounds and low-emphasis highlights |
| Signal amber | `#A84F16` | restrained callout, index, or status emphasis |
| Amber wash | `#F4E1D2` | signal background |
| Rule | `#C9C2B8` | non-text borders and separators |
| Focus blue | `#005FCC` | visible focus indicator |
| Focus blue on dark | `#8EC5FF` | focus indicator on ink surfaces |

Calculated contrast against Canvas is 14.69:1 for Ink, 6.41:1 for Muted ink, 5.56:1 for System teal, 4.96:1 for Signal amber, and 5.36:1 for Focus blue. Canvas on Ink is 14.69:1; the dark-surface focus token on Ink is 9.05:1. Recheck the implemented tokens and states in-browser before acceptance. Signal colors are accents, not the sole carrier of state.

### Typography

- Display/editorial: `"Iowan Old Style", "Palatino Linotype", "Book Antiqua", Georgia, serif`.
- Body/UI: `-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`.
- No remote fonts in the private prototype.
- Body default: 18px equivalent, 1.6–1.7 line height, maximum measure about 68 characters.
- Display H1: fluid range approximately 44–88px, tightened line height, never clipped at 320px.
- H2: fluid range approximately 32–56px.
- H3: 22–30px.
- Labels: 13–15px with modest tracking; never use all caps for long text.
- Avoid font weights below 400 for body copy.

### Spacing and grid

- Base spacing rhythm: 4, 8, 12, 16, 24, 32, 48, 64, 96, 128px.
- Content container: maximum 1200px with fluid 20–48px side gutters.
- Desktop: 12-column grid; primary reading content commonly spans 7–8 columns.
- Tablet: 6-column adaptations.
- Mobile: single-column source order.
- Major sections use generous vertical space; related labels and explanations remain visually grouped.

### Shape and treatment

- Borders: 1px rules with restrained contrast.
- Corner radius: 0–12px; avoid a field of identical floating rounded cards.
- Shadows: minimal or absent; hierarchy comes from space, tone, and rules.
- Buttons: clear solid primary, quieter text or outlined secondary, minimum 44×44px target.
- Icons: optional, simple, and never substitutes for text.
- Diagrams: CSS/SVG relationships only when semantic text equivalents exist; no fictional charts or UI chrome.

### Imagery

Baseline: no photography is required. The design must work with typography and process graphics. If rights-cleared imagery later appears, it should show real expertise, working sessions, source material, or production context—not generic camera crews or staged creator clichés. Every image needs an explicit decorative/informative decision and appropriate alt treatment.

### Motion

- Motion is optional and never required to understand sequence or state.
- Allowed: short 160–220ms opacity/position transitions for navigation or focus-adjacent disclosure.
- Disallowed: autoplay video, scroll hijacking, parallax, continuous loops, animated counters, cursor effects, and staged “dashboard” assembly.
- Under `prefers-reduced-motion: reduce`, remove nonessential transitions and smooth scrolling.

## 10. Responsive behavior

Design from content priority rather than device names.

### Narrow screens: 320–599px

- Single-column content and source order.
- Hero copy wraps without orphaned one-word lines where practical.
- Primary CTA becomes full-width only when that improves target size; it must not become sticky by default.
- Process loop becomes a numbered vertical rail with visible labels and text connectors.
- Comparison tables transform into paired dimension blocks; no horizontal data loss.
- Fit columns stack with explicit “Strong fit” and “Poor fit” headings.
- Navigation opens without covering focus or trapping keyboard users.
- No horizontal page scrolling at 320 CSS pixels with 200% zoom.

### Medium screens: 600–1023px

- Six-column grid; cards use one or two columns based on readable width.
- Process stages may use a two-column stepping layout if source order remains logical.
- Header may retain compact navigation or use the accessible menu based on measured fit.

### Wide screens: 1024px and above

- Twelve-column grid with asymmetrical editorial compositions.
- Keep paragraphs within readable measure even when diagrams span wider.
- Use whitespace and rules to connect stages; do not fill the viewport with cards.
- At 1440px and wider, cap content width rather than scaling type and lines indefinitely.

### Content resilience

- Components tolerate headings approximately 50% longer for future localization.
- No fixed-height text containers.
- Navigation has a documented long-label fallback.
- Diagrams do not rely on precise text length or absolute-positioned copy.

## 11. Accessibility

Target WCAG 2.2 AA for both private prototype and production.

Required behavior:

- semantic landmarks: header, nav, main, footer;
- a visible-on-focus skip link to main content;
- logical heading hierarchy and one H1 per route;
- keyboard access to every interactive element in a predictable order;
- no positive `tabindex` and no keyboard trap;
- visible focus with sufficient contrast and no clipping or obscuring;
- active, error, success, and warning states conveyed with text and structure, not color alone;
- 44×44px minimum pointer target where practical and no tightly crowded controls;
- links distinguishable in body copy without relying only on color;
- text zoom to 200% and reflow at 400% without loss of content or function;
- reduced-motion support;
- meaningful page titles and link labels;
- SVGs with correct accessible names or hidden when decorative;
- images with contextual alt text or empty alt when decorative;
- no text embedded in images;
- FAQ disclosure uses native semantics or correctly managed `aria-expanded` and relationships;
- form errors summarized at the top, linked to fields, and described inline in production;
- success or asynchronous error notices announced through an appropriate live region without stealing focus unexpectedly.

Manual verification includes full keyboard use and VoiceOver on macOS/iOS. Automated accessibility checks assist but do not replace manual review.

## 12. Technical direction

### Architecture requirements

- static HTML output;
- content-driven English source structure;
- reusable components without a client-side application runtime;
- core site usable with JavaScript disabled;
- local/system assets by default;
- no CMS, database, authentication, API integration, or runtime personalization;
- no external services in the private prototype;
- predictable build and lockfile when a generator is selected;
- localization-ready content boundaries without multilingual output.

### Options

| Option | Advantages | Costs / risks | Decision |
|---|---|---|---|
| Astro static output | Components, layouts, content organization, zero-JS defaults, selective enhancement, maintainable seven-page structure | Node build dependency and framework conventions | **Recommended provisional default** |
| Eleventy | Small static-generator model, flexible templates, low runtime footprint | More template/data conventions to define; component ergonomics and schema tooling may require extra choices | Acceptable alternative |
| Plain HTML/CSS | Fewest build dependencies and transparent output | Repeated navigation/metadata across seven pages, higher drift risk, weaker content/schema boundaries | Acceptable only with a documented include/build mechanism; otherwise not preferred |

A React/Next.js client application, CMS framework, and database-backed architecture are not justified by the approved requirements.

### Framework decision rule

The implementation-plan session may confirm Astro after checking the local runtime and hosting constraints. A different choice is acceptable only if it preserves static output, zero-JS core behavior, local content, low dependency count, localization readiness, and all verification requirements. No framework is scaffolded at this documentation gate.

## 13. Performance

### Budgets for the production candidate

- Core pages require 0KB of client JavaScript unless a specific accessible interaction justifies it.
- Total first-party client JavaScript: target 0KB; hard budget 25KB compressed per page.
- CSS: target below 45KB compressed; hard budget 60KB compressed.
- Initial page transfer excluding an intentionally approved video: target below 750KB; hard budget 1MB.
- No autoplay media, remote fonts, tag managers, chat, maps, or embed payloads in the baseline.
- Images use explicit width/height, modern formats where supported, responsive sources, and lazy loading below the fold.
- Hero imagery is optional; text must establish meaning without it.

### User-experience targets

At the 75th percentile on representative production traffic when measurement becomes available:

- Largest Contentful Paint ≤ 2.5 seconds;
- Interaction to Next Paint ≤ 200ms;
- Cumulative Layout Shift ≤ 0.1.

Laboratory checks should target Lighthouse performance, accessibility, best-practices, and SEO scores of 95 or higher on representative mobile and desktop runs, while treating underlying failures and field metrics as more important than the score.

## 14. Security and privacy

### Private prototype

- local only;
- no data collection or submission;
- no analytics, cookies, remote fonts, tracking pixels, chat, maps, scheduler, forms, or embeds;
- no secrets, tokens, environment credentials, or vendor identifiers;
- no fabricated production endpoint.

### Production baseline

- HTTPS everywhere; enable HSTS only after HTTPS and subdomain implications are verified;
- domain registrar and hosting MFA;
- least-privilege deployment access and documented ownership;
- no frontend secrets; secrets exist only in the approved server environment;
- server-side validation and sanitization for every submitted field;
- contextual output escaping; never render raw submitted HTML;
- same-origin form submission by default;
- CSRF protection appropriate to the selected architecture, including strict cookie settings if cookies are used and validation of request origin for browser submissions;
- rate limiting, bot/spam controls, payload-size limits, and method/content-type restrictions;
- minimal collection, documented retention, deletion behavior, and controlled access;
- generic public errors with private structured diagnostics and correlation IDs;
- dependency lockfile, minimal packages, vulnerability review, and secret scanning;
- vendor inventory with purpose, data categories, origins, retention, owner, and removal path;
- privacy requirements determined before launch from the actual entity, operating geography, audience geography, and data flow.

### Recommended response headers

Verify rather than merely configure:

- `Content-Security-Policy` with a baseline equivalent to `default-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; img-src 'self' data:; font-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-src 'none'; upgrade-insecure-requests`;
- use CSP hashes or nonces for any approved inline structured-data script rather than adding broad unsafe directives;
- `Referrer-Policy: strict-origin-when-cross-origin`;
- `X-Content-Type-Options: nosniff`;
- `Permissions-Policy` disabling camera, microphone, geolocation, and other unused capabilities;
- `Cross-Origin-Opener-Policy: same-origin` unless a documented integration requires a different value;
- `X-Frame-Options: DENY` as legacy defense alongside CSP `frame-ancestors`;
- `Strict-Transport-Security` after deployment validation.

### Future embeds and messaging

The baseline permits no frames. If a later approved embed is necessary:

- list exact vendor origins in CSP; never use broad wildcards;
- set an intentional iframe `sandbox` and the narrowest `allow` policy;
- supply accessible title and non-embed fallback;
- verify loading, privacy, keyboard, performance, and failure behavior;
- for `postMessage`, verify the sender origin against an exact allowlist, validate message shape, and send only to an exact target origin—never `*`.

## 15. Prototype versus production data flow

| Concern | Private prototype | Production candidate |
|---|---|---|
| Apply experience | Static explanation and question preview; no enabled fields | Accessible form after LB-05 closure |
| Network submission | None | HTTPS POST to approved same-origin handler by default |
| Validation | Not applicable because nothing is collected | Client-side convenience plus authoritative server validation |
| Storage/relay | None | Minimal approved destination with documented retention and access |
| Scheduler | None | Human follow-up by default; vendor only after separate approval |
| Analytics | None | Deferred; may remain absent |
| Diagnostics | Local build/browser output only | Private structured server logs with correlation ID and redaction |
| Third parties | None | Only approved, inventoried processors |

### Production form flow

Browser → HTTPS same-origin endpoint → request size/type check → rate and spam controls → field allowlist → normalization, validation, and sanitization → approved destination → generic success response.

On any validation or delivery failure, the endpoint returns a safe status and public message without exposing stack traces, vendor details, internal addresses, raw payloads, or whether a specific email/account exists.

## 16. Form fields, validation, and failure behavior

### Minimal production field proposal

Final approval belongs to LB-05. The recommended minimal set is:

| Field | Requirement | Server rule |
|---|---|---|
| Name | Required | trim; normalize; 2–100 characters; reject control characters |
| Work email | Required | trim; normalize domain case; 3–254 characters; syntactic validation; do not claim mailbox verification unless performed |
| Company | Required | trim; 2–150 characters |
| Company website | Optional | allow only `https` or `http`; maximum 2,048 characters; do not fetch the submitted URL synchronously |
| Role | Optional | trim; maximum 100 characters |
| Current YouTube state | Required selection | allowlist of approved values; no free-form HTML |
| Primary objective | Required | allowlist or 20–1,000 characters, depending on final UI |
| Main operating constraint | Required | 20–2,000 characters |
| Participation and timing context | Optional | approved selection plus up to 1,000 characters |
| Privacy acknowledgment | Required | explicit acknowledgment linked to the approved privacy notice; separate from any marketing consent |

Do not request revenue, passwords, account access, sensitive personal data, health data, confidential client data, or YouTube/CRM credentials in the public form.

### Validation behavior

- Labels remain visible; placeholders are examples, not labels.
- Required fields are identified in text.
- On client validation, show an error summary and inline errors; move focus to the summary after submit.
- Errors state how to fix the field and are programmatically associated.
- On server validation, return the same field-level model without reflecting unsafe input.
- Preserve non-sensitive field values after a correctable error.
- Ignore or reject unexpected fields using an explicit allowlist.
- Normalize and validate on the server even if the browser reports success.
- Set a conservative payload-size limit and request timeout.
- Use a honeypot and timing/rate signals before adding a CAPTCHA. A CAPTCHA requires vendor, accessibility, privacy, and failure-path review.

### Failure states

- **Network unavailable:** “We couldn’t send your request. Your information has not been confirmed as received. Please try again.”
- **Validation failure:** “Please review the highlighted fields.” Include linked field details.
- **Rate limited:** “We can’t accept another request right now. Please wait and try again.” Do not reveal thresholds.
- **Backend/vendor failure:** “We couldn’t confirm receipt of your request. Please try again later.” Log a private correlation ID.
- **Success:** “Your request was received. If there is a fit, the team will reply using the contact information you provided.” Do not promise response time until approved.

The UI must never show success before the server confirms durable acceptance by the approved destination.

## 17. SEO foundations

### Technical foundation

- unique, descriptive title and meta description for every page;
- one canonical URL per production page;
- semantic headings, landmarks, lists, and internal links;
- XML sitemap and correct `robots.txt` for production;
- private/local prototype is not published; any later review environment must be access-controlled and marked `noindex`, with `noindex` treated as indexing guidance rather than access control;
- stable, readable routes defined in Section 6;
- Open Graph and social metadata using rights-cleared local assets only;
- redirect and 404 behavior verified if routes change;
- no keyword stuffing or generated location/sector pages.

### Provisional title pattern

- Home: `[LB-01: Company name] | YouTube systems for business`
- The System: `The YouTube Operating System | [LB-01]`
- Services: `YouTube strategy and operations services | [LB-01]`
- Who It Is For: `Who the YouTube operating method fits | [LB-01]`
- Results: `How YouTube work is measured | [LB-01]`
- About: `About the operating method | [LB-01]`
- Apply: `Request a strategy conversation | [LB-01]`

These are review markers, not publishable metadata until LB-01 closes.

### Structured data

Use only factual, visible, approved data. `Organization` and `Service` may be considered after identity and offer approval. Do not add `Review`, `AggregateRating`, invented founding facts, unverified service areas, or claim-rich FAQ markup. Any inline JSON-LD must comply with CSP through an approved hash/nonce strategy.

## 18. Analytics and tracking deferral

Analytics is not required for the private prototype and is not a default production dependency. Before adding any measurement vendor, define:

- the decision the metric will support;
- the minimum event/data fields required;
- whether first-party aggregate measurement can answer the need;
- applicable consent and disclosure requirements;
- retention and access;
- vendor/processor terms and data residency;
- script weight, reliability, accessibility, and CSP changes;
- how to remove the vendor cleanly.

No marketing pixels, session replay, cross-site identifiers, or fingerprinting are assumed. A production launch without nonessential analytics is acceptable.

## 19. Test and browser-verification strategy

### Automated checks for the later implementation

- clean static build from the lockfile;
- generated HTML validation across all seven routes;
- internal link, canonical, sitemap, and missing-asset check;
- content-schema check for stable IDs, required page metadata, service fields, and claims-register references;
- production build scan that fails if internal `[LB-` markers or unapproved evidence states are rendered;
- scan for prohibited quantitative claims and future-platform terms in public output;
- automated accessibility checks on each route with zero critical or serious violations;
- Lighthouse checks against Section 13 budgets on representative mobile and desktop settings;
- JavaScript and transfer-size budget checks;
- browser-network check confirming that the private prototype makes no third-party requests and no data submissions;
- production form integration tests for valid, invalid, unexpected, oversized, spam-like, rate-limited, timeout, destination-failure, and duplicate-submit cases;
- production form security tests for cross-origin submission, CSRF controls, output escaping, and disallowed methods/content types;
- deployed-header verification against the production origin;
- secret and dependency scans appropriate to the selected stack.

### Manual viewport matrix

- 320×568;
- 375×812;
- 768×1024;
- 1024×768;
- 1440×900;
- one larger desktop width to verify container caps.

At every size, inspect navigation, hero wrapping, process order, comparisons, fit lists, CTA visibility, footer, long labels, zoom, focus, and horizontal overflow.

### Browser and assistive-technology matrix

- current Safari on macOS and iOS;
- current Chrome on macOS and Android;
- current Firefox on macOS;
- VoiceOver on macOS and iOS for landmarks, headings, navigation, diagrams, disclosures, and forms;
- keyboard-only traversal using real Tab, Shift+Tab, Enter, Space, Escape, arrow keys where the control pattern requires them;
- reduced-motion setting enabled at operating-system level;
- JavaScript disabled for core navigation and content.

### Manual content/claims review

- compare every rendered page with the claims register;
- confirm “Operating System” never reads as application functionality;
- confirm evidence-reserved modules cannot be mistaken for published cases;
- confirm no company, founder, client, channel, geography, price, contact, or capacity fact has been invented;
- confirm all private annotations are absent from a production build;
- confirm About, service, form, metadata, and footer content match final approvals.

## 20. Claims and placeholder handling

### Structured markers

Use `[LB-##: concise description]` only in source content and private-review output. Every marker maps to `docs/launch-blockers.md`. Do not use generic blanks or plausible filler.

Use claim IDs `C-###` in source metadata and review annotations. A claim state must default to non-public. Only an explicit approved state allows production rendering.

### Build behavior

- Private review may render blocker annotations in a visually explicit “Review note — not public copy” component.
- Production mode must fail if any blocker annotation reaches generated pages, titles, descriptions, structured data, alt text, or links.
- Unapproved evidence records are omitted, not anonymized or converted into sample content.
- Missing optional content collapses cleanly; no empty headings, cards, carousels, or navigation links remain.
- Missing required launch content fails the production build with the controlling blocker ID.

### Claim-safe copy patterns

Prefer:

- “designed to support”;
- “the method connects”;
- “the team evaluates”;
- “the engagement may include, depending on scope”;
- “YouTube is treated as a compounding, iterative channel.”

Avoid:

- “will generate leads/revenue”;
- “10–30×”;
- “number one” or “dominate”;
- “guaranteed” or “predictable” outcomes;
- “proprietary platform,” “dashboard,” “AI engine,” or “automated integration”;
- “we operate 120 channels”;
- vague superlatives such as “best,” “leading,” or “world-class.”

## 21. Implementation anti-goals

The later prototype must not include:

- internal operations software or data models for a platform;
- client authentication, accounts, portals, approvals, or dashboards;
- YouTube API, CRM, email, calendar, analytics, attribution, or revenue integrations;
- AI research, writing, analysis, quality, or automation modules;
- portfolio/capacity planning;
- SaaS pricing, subscriptions, checkout, or billing;
- live form or contact collection in the private prototype;
- CMS, blog engine, or multilingual publishing;
- fake UI, charts, cases, testimonials, logos, subscriber awards, metrics, or client brands;
- stock camera-crew imagery, YouTube-red branding, neon gradients, floating social icons, vanity counters, or motion spectacle;
- deployment, domain setup, or external publication without a separately approved gate;
- new scope inferred from future-platform sections of the Project Bible.

## 22. Definition of done

### Written-spec gate — current session

This documentation gate is complete only when:

- README and all five required docs exist at the required paths;
- both supplied inputs are registered with limitations;
- required claims have evidence and public-use decisions;
- provisional decisions and launch blockers are explicit;
- this specification covers product, pages, copy, conversion, components, visual behavior, responsive behavior, accessibility, performance, security, privacy, data flow, forms, SEO, analytics deferral, testing, claims, and scope;
- scans find no vague incomplete markers or unsupported public claims;
- all files are directly inspected;
- only project documentation is committed in the project-local repository;
- the next state is user review, not an implementation plan.

### Private-prototype gate — later session

The private prototype is done only when:

- all seven routes render locally from a clean static build;
- the exact positioning, non-software boundary, fit, and CTA are present;
- Apply is static and non-submitting;
- no third-party request, tracking, remote asset, or secret exists;
- blocker annotations are explicit review notes and claims remain withheld;
- responsive, keyboard, VoiceOver, reduced-motion, no-JavaScript, link, accessibility, and performance checks pass at the defined baseline;
- no website is deployed or called launch-ready;
- verification evidence is recorded for a separate evaluator.

### Production-launch gate — future

Production is done only when:

- LB-01 through LB-08 are closed with evidence;
- all production copy, identity, claims, permissions, privacy, form, hosting, and security decisions are approved;
- the live origin passes the browser, accessibility, performance, form, link, metadata, header, and data-flow checks;
- no internal blocker markers, unapproved claims, fake evidence, or future-platform implications appear;
- a rollback owner and post-launch monitoring path exist.

## 23. Anti-definition-of-done

None of the following is sufficient:

- the pages look polished in one desktop screenshot;
- a framework scaffold or component library exists;
- all copy slots are filled with plausible text;
- a Lighthouse score is high while manual accessibility or claims review is incomplete;
- a form looks complete but has no verified server validation, delivery, privacy, and failure behavior;
- the site is deployed to a URL;
- unverified metrics are labeled “example,” “anonymous,” or “representative” but still resemble proof;
- a process diagram is styled as a product interface;
- a future platform capability is presented as imminent;
- the site works only with JavaScript, pointer input, or one browser;
- launch blockers are moved into comments or hidden documentation without closure evidence;
- the written specification exists but has not passed user review;
- implementation planning or code begins before that review approval.

## 24. Written-spec review gate

This document is the durable design baseline, not an implementation plan. The next action is user review. If approved, a separate session may invoke the implementation-planning workflow, confirm or replace the provisional Astro recommendation, and translate this specification into an ordered build plan. No website implementation is authorized by this document alone.
