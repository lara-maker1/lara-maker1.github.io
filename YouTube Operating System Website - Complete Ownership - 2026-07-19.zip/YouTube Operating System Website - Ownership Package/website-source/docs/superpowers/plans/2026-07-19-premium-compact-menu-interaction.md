# Premium Compact Menu Interaction Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the compact menu’s snap-open disclosure with the approved slow editorial reveal and restrained cursor-reactive rows while preserving native touch, keyboard, reduced-motion, no-JavaScript, privacy, and build controls.

**Architecture:** Keep the native `<details>`/`<summary>` structure, add one natural-height reveal wrapper, and create a focused `navigation-menu.ts` state module. Import that module through the existing `smooth-scroll.ts` client entry so Astro continues to emit exactly one local script; CSS owns appearance and motion, while JavaScript only coordinates hover eligibility, animated native state, timers, Escape, and lifecycle cleanup.

**Tech Stack:** Astro 7.1.1, TypeScript 6.0.3, native details/summary, CSS grid-track transitions, Node test runner, Playwright Core 1.61.1 with local Chrome, Axe Core 4.12.1.

---

## Authority and invariants

- Governing interaction specification: `docs/superpowers/specs/2026-07-19-compact-menu-hover-interaction-design.md`.
- Governing site specification: `docs/superpowers/specs/2026-07-17-youtube-operating-system-site-design.md`.
- Visual baseline: `docs/superpowers/specs/2026-07-18-youtube-operating-system-visual-redesign-and-smooth-scroll-design.md`.
- Starting commit: `8592170` (`docs: specify premium compact menu interaction`).
- Preserve seven routes, current content, claims, launch blockers, private metadata, one local client bundle, zero third-party runtime requests, and existing JS/CSS ceilings.
- Do not alter the wide desktop navigation at or above `72rem`.
- Do not modify Lenis settings, add dependencies, deploy, push, publish, activate forms, or stage `.superpowers/`.

## File responsibility map

### Create

- `src/scripts/navigation-menu.ts` — compact disclosure state, hover eligibility, activation, Escape, timers, media changes, and cleanup.
- `docs/verification/2026-07-19-premium-compact-menu-verification.md` — exact command, browser, visual, and limitation evidence.
- `docs/verification/screenshots/menu-hover-1024.png` — approved open/hover state at `1024×768`.

### Modify

- `src/components/SiteHeader.astro` — reveal wrappers and explicit mark hook; content and semantics stay unchanged.
- `src/styles/global.css` — approved compact dimensions, radii, natural-height transition, state selectors, restrained row response, and reduced-motion behavior.
- `src/scripts/smooth-scroll.ts` — mount/unmount the new module through the existing single client entry.
- `tests/browser-contracts.test.mjs` — source contracts for structure, tokens, state module, single-entry integration, and browser coverage.
- `scripts/verify-browser.mjs` — real compact hover, transition, re-entry, close, keyboard, reduced-motion, no-JS, and desktop invariance checks.
- `README.md` — add the new spec, plan, and verification record to the authority order; preserve the private-prototype boundary.

### Deliberately unchanged

- `package.json`, `package-lock.json`, Astro/TypeScript configuration, page content, route files, claims/source/blocker registers, production validator, Lenis options, and public-launch status.

## Task 1: Lock the compact structure and visual contract

**Files:**
- Modify: `tests/browser-contracts.test.mjs`
- Modify: `src/components/SiteHeader.astro`
- Modify: `src/styles/global.css`

- [ ] **Step 1: Add the failing structure and style contract**

Append this test after the existing narrow-screen menu test:

```js
test('the compact menu uses the approved editorial reveal and restrained surface', () => {
  const header = source('src/components/SiteHeader.astro');
  const css = source('src/styles/global.css');

  assert.match(header, /class="nav-disclosure__mark"/);
  assert.match(header, /class="nav-disclosure__reveal"/);
  assert.match(header, /class="nav-disclosure__reveal-inner"/);
  assert.match(header, /data-menu-state="closed"/);

  for (const contract of [
    /width:\s*min\(12\.75rem,\s*calc\(100vw\s*-\s*2rem\)\)/,
    /border-radius:\s*7px/,
    /border-radius:\s*8px/,
    /border-radius:\s*5px/,
    /grid-template-rows:\s*0fr/,
    /grid-template-rows:\s*1fr/,
    /1050ms\s+cubic-bezier\(\.16,\s*1,\s*\.3,\s*1\)/,
    /620ms\s+cubic-bezier\(\.4,\s*0,\s*\.2,\s*1\)/,
    /box-shadow:\s*inset\s+2px\s+0\s+var\(--cobalt\)/,
    /\[open\]:not\(\[data-menu-enhanced\]\)/,
  ]) assert.match(css, contract);

  assert.doesNotMatch(header, />0[1-9]</);
  assert.doesNotMatch(css, /linear-gradient|radial-gradient|backdrop-filter|filter:\s*blur/i);
});
```

- [ ] **Step 2: Run the focused test and verify RED**

Run:

```bash
node --test --test-name-pattern="compact menu uses" tests/browser-contracts.test.mjs
```

Expected: FAIL on the missing reveal/mark hooks and approved CSS contracts.

- [ ] **Step 3: Add the natural-height wrapper without changing navigation content**

Replace the compact disclosure in `SiteHeader.astro` with:

```astro
<details class="nav-disclosure" data-menu-state="closed">
  <summary><span>Menu</span><span class="nav-disclosure__mark" aria-hidden="true">＋</span></summary>
  <div class="nav-disclosure__reveal">
    <div class="nav-disclosure__reveal-inner">
      <nav aria-label="Mobile navigation">
        <ul>
          {navigation.map((item) => (
            <li><a href={item.href} aria-current={currentPath === item.href ? 'page' : undefined}>{item.label}</a></li>
          ))}
        </ul>
      </nav>
    </div>
  </div>
</details>
```

- [ ] **Step 4: Replace the compact menu CSS with the approved surface and state rules**

Replace the rules from `.nav-disclosure` through the compact `aria-current` marker with:

```css
.nav-disclosure {
  position: relative;
  flex: 0 0 auto;
}

.nav-disclosure > summary {
  display: flex;
  min-height: 44px;
  min-width: 5.5rem;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3);
  padding: 0.45rem 0.75rem;
  border: 1px solid var(--ink);
  border-radius: 7px;
  background: var(--white);
  box-shadow: inset 0 -2px var(--cobalt);
  color: var(--ink);
  cursor: pointer;
  font-size: 0.875rem;
  font-weight: 750;
  list-style: none;
  white-space: nowrap;
  transition: background-color 320ms ease, box-shadow 320ms ease;
}

.nav-disclosure > summary::-webkit-details-marker {
  display: none;
}

.nav-disclosure__mark {
  transition: transform 620ms cubic-bezier(.4, 0, .2, 1);
}

.nav-disclosure[data-menu-state="open"] > summary .nav-disclosure__mark {
  transform: rotate(45deg);
  transition: transform 820ms cubic-bezier(.16, 1, .3, 1);
}

.nav-disclosure__reveal {
  position: absolute;
  top: calc(100% + 0.55rem);
  right: 0;
  display: grid;
  width: min(12.75rem, calc(100vw - 2rem));
  grid-template-rows: 0fr;
  opacity: 0;
  transform: translateY(-0.8rem);
  pointer-events: none;
  transition:
    grid-template-rows 620ms cubic-bezier(.4, 0, .2, 1),
    opacity 360ms ease,
    transform 620ms cubic-bezier(.4, 0, .2, 1),
    box-shadow 360ms ease;
}

.nav-disclosure[data-menu-state="open"] .nav-disclosure__reveal {
  grid-template-rows: 1fr;
  opacity: 1;
  transform: translateY(0);
  box-shadow: 0 24px 60px rgba(11, 11, 11, 0.14);
  pointer-events: auto;
  transition:
    grid-template-rows 1050ms cubic-bezier(.16, 1, .3, 1),
    opacity 680ms ease 100ms,
    transform 1050ms cubic-bezier(.16, 1, .3, 1),
    box-shadow 680ms ease 100ms;
}

.nav-disclosure[open]:not([data-menu-enhanced]) .nav-disclosure__reveal {
  grid-template-rows: 1fr;
  opacity: 1;
  transform: translateY(0);
  box-shadow: 0 24px 60px rgba(11, 11, 11, 0.14);
  pointer-events: auto;
  transition: none;
}

.nav-disclosure__reveal-inner {
  min-height: 0;
  overflow: hidden;
}

.nav-disclosure nav {
  width: 100%;
  padding: 0.55rem;
  border: 1px solid var(--ink);
  border-radius: 8px;
  background: var(--white);
}

.nav-disclosure ul,
.desktop-nav ul,
.site-footer ul {
  list-style: none;
}

.nav-disclosure a {
  position: relative;
  display: flex;
  min-height: 44px;
  align-items: center;
  padding: 0.65rem 0.72rem;
  border-bottom: 1px solid var(--rule);
  border-radius: 5px;
  background: var(--white);
  color: var(--ink);
  font-weight: 600;
  line-height: 1.25;
  text-decoration: none;
  transition:
    background-color 320ms cubic-bezier(.2, .8, .2, 1),
    color 280ms ease,
    padding-left 420ms cubic-bezier(.2, .8, .2, 1),
    box-shadow 320ms ease;
}

.nav-disclosure li:last-child a {
  margin-top: 0.25rem;
  border-top: 1px solid var(--ink);
  border-bottom-color: transparent;
  font-weight: 700;
}

.nav-disclosure a[aria-current="page"] {
  box-shadow: inset 2px 0 var(--cobalt);
}

.nav-disclosure a[aria-current="page"]::after {
  content: "Current";
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip: rect(0 0 0 0);
  clip-path: inset(50%);
  white-space: nowrap;
}

@media (hover: hover) and (pointer: fine) {
  .nav-disclosure > summary:hover {
    background: var(--paper);
    box-shadow: inset 0 -2px var(--cobalt), 0 10px 28px rgba(11, 11, 11, 0.08);
  }

  .nav-disclosure a:hover {
    padding-left: 0.97rem;
    background: var(--ink);
    box-shadow: inset 2px 0 var(--cobalt), 0 8px 20px rgba(11, 11, 11, 0.11);
    color: var(--white);
  }
}

.nav-disclosure a:focus-visible {
  padding-left: 0.97rem;
  background: var(--ink);
  box-shadow: inset 2px 0 var(--cobalt), 0 8px 20px rgba(11, 11, 11, 0.11);
  color: var(--white);
}
```

Keep the existing global reduced-motion rule; it already forces every transition to `0.01ms !important`.

- [ ] **Step 5: Run focused and complete static tests**

Run:

```bash
node --test --test-name-pattern="compact menu uses" tests/browser-contracts.test.mjs
npm test
```

Expected: focused PASS; full suite PASS with the pre-behavior test count plus one new test.

- [ ] **Step 6: Commit the static surface**

```bash
git add src/components/SiteHeader.astro src/styles/global.css tests/browser-contracts.test.mjs
git commit -m "style: refine compact navigation surface"
```

## Task 2: Add the fine-pointer state lifecycle

**Files:**
- Create: `src/scripts/navigation-menu.ts`
- Modify: `src/scripts/smooth-scroll.ts`
- Modify: `tests/browser-contracts.test.mjs`

- [ ] **Step 1: Add the failing state-module contract**

Append:

```js
test('the compact menu state module preserves native fallbacks and cleans up timers', () => {
  const menu = source('src/scripts/navigation-menu.ts');
  const entry = source('src/scripts/smooth-scroll.ts');

  for (const contract of [
    /\(hover:\s*hover\)\s*and\s*\(pointer:\s*fine\)/,
    /LEAVE_GRACE_MS\s*=\s*180/,
    /CLOSE_DURATION_MS\s*=\s*620/,
    /pointerenter/,
    /pointerleave/,
    /event\.key\s*===\s*'Escape'/,
    /focus\(\{\s*preventScroll:\s*true\s*\}\)/,
    /menuEnhanced/,
    /cancelAnimationFrame/,
    /clearTimeout/,
  ]) assert.match(menu, contract);

  assert.match(entry, /mountNavigationMenu/);
  assert.doesNotMatch(menu, /gsap|anime|motion|cursorX|cursorY|mousemove/i);
});
```

- [ ] **Step 2: Run the focused test and verify RED**

Run:

```bash
node --test --test-name-pattern="state module preserves" tests/browser-contracts.test.mjs
```

Expected: FAIL because `src/scripts/navigation-menu.ts` does not exist.

- [ ] **Step 3: Create the complete state module**

Create `src/scripts/navigation-menu.ts`:

```ts
const FINE_POINTER_QUERY = '(hover: hover) and (pointer: fine)';
const REDUCED_MOTION_QUERY = '(prefers-reduced-motion: reduce)';
const LEAVE_GRACE_MS = 180;
const CLOSE_DURATION_MS = 620;

type MenuState = 'closed' | 'opening' | 'open' | 'closing';

export function mountNavigationMenu(): () => void {
  const details = document.querySelector<HTMLDetailsElement>('.nav-disclosure');
  const summary = details?.querySelector<HTMLElement>(':scope > summary');
  if (!details || !summary) return () => {};

  const finePointer = window.matchMedia(FINE_POINTER_QUERY);
  const reducedMotion = window.matchMedia(REDUCED_MOTION_QUERY);
  let pointerInside = false;
  let closeTimer: number | undefined;
  let finalizer: number | undefined;
  let openingFrame: number | undefined;

  const state = (): MenuState => (details.dataset.menuState as MenuState | undefined) ?? 'closed';
  const setState = (next: MenuState): void => {
    details.dataset.menuState = next;
  };

  const clearCloseTimer = (): void => {
    if (closeTimer === undefined) return;
    window.clearTimeout(closeTimer);
    closeTimer = undefined;
  };

  const clearFinalizer = (): void => {
    if (finalizer === undefined) return;
    window.clearTimeout(finalizer);
    finalizer = undefined;
  };

  const clearOpeningFrame = (): void => {
    if (openingFrame === undefined) return;
    window.cancelAnimationFrame(openingFrame);
    openingFrame = undefined;
  };

  const finishClosed = (): void => {
    clearFinalizer();
    details.open = false;
    setState('closed');
  };

  const openMenu = (): void => {
    clearCloseTimer();
    clearFinalizer();
    clearOpeningFrame();
    const current = state();

    if (details.open && (current === 'open' || current === 'opening')) return;
    details.open = true;

    if (reducedMotion.matches) {
      setState('open');
      return;
    }

    if (current === 'closing') {
      setState('open');
      return;
    }

    setState('opening');
    openingFrame = window.requestAnimationFrame(() => {
      openingFrame = undefined;
      if (details.open) setState('open');
    });
  };

  const closeMenu = (immediate = false): void => {
    clearCloseTimer();
    clearFinalizer();
    clearOpeningFrame();

    if (!details.open) {
      setState('closed');
      return;
    }

    if (immediate || reducedMotion.matches) {
      finishClosed();
      return;
    }

    setState('closing');
    finalizer = window.setTimeout(finishClosed, CLOSE_DURATION_MS);
  };

  const scheduleClose = (): void => {
    clearCloseTimer();
    closeTimer = window.setTimeout(() => {
      closeTimer = undefined;
      if (!pointerInside && !details.matches(':focus-within')) closeMenu();
    }, LEAVE_GRACE_MS);
  };

  const handlePointerEnter = (event: PointerEvent): void => {
    pointerInside = true;
    clearCloseTimer();
    if (finePointer.matches && event.pointerType !== 'touch') openMenu();
  };

  const handlePointerLeave = (event: PointerEvent): void => {
    pointerInside = false;
    if (finePointer.matches && event.pointerType !== 'touch') scheduleClose();
  };

  const handleSummaryClick = (event: MouseEvent): void => {
    event.preventDefault();
    if (details.open && state() !== 'closing') closeMenu();
    else openMenu();
  };

  const handleKeydown = (event: KeyboardEvent): void => {
    if (event.key !== 'Escape' || !details.open) return;
    event.preventDefault();
    closeMenu();
    summary.focus({ preventScroll: true });
  };

  const handleFocusOut = (): void => {
    window.setTimeout(() => {
      if (finePointer.matches && !pointerInside && !details.matches(':focus-within')) scheduleClose();
    }, 0);
  };

  const handleFinePointerChange = (): void => {
    clearCloseTimer();
    if (!finePointer.matches) pointerInside = false;
  };

  const handleReducedMotionChange = (): void => {
    if (!reducedMotion.matches) return;
    clearOpeningFrame();
    if (state() === 'closing') finishClosed();
    else if (details.open) setState('open');
  };

  details.dataset.menuEnhanced = '';
  details.open = false;
  setState('closed');
  details.addEventListener('pointerenter', handlePointerEnter);
  details.addEventListener('pointerleave', handlePointerLeave);
  details.addEventListener('keydown', handleKeydown);
  details.addEventListener('focusout', handleFocusOut);
  summary.addEventListener('click', handleSummaryClick);
  finePointer.addEventListener('change', handleFinePointerChange);
  reducedMotion.addEventListener('change', handleReducedMotionChange);

  return () => {
    clearCloseTimer();
    clearFinalizer();
    clearOpeningFrame();
    details.removeEventListener('pointerenter', handlePointerEnter);
    details.removeEventListener('pointerleave', handlePointerLeave);
    details.removeEventListener('keydown', handleKeydown);
    details.removeEventListener('focusout', handleFocusOut);
    summary.removeEventListener('click', handleSummaryClick);
    finePointer.removeEventListener('change', handleFinePointerChange);
    reducedMotion.removeEventListener('change', handleReducedMotionChange);
    details.open = false;
    setState('closed');
    delete details.dataset.menuEnhanced;
  };
}
```

- [ ] **Step 4: Integrate with the existing one-entry lifecycle**

At the top of `smooth-scroll.ts`, add:

```ts
import { mountNavigationMenu } from './navigation-menu';
```

Add module state beside the Lenis state:

```ts
let unmountNavigationMenu: (() => void) | null = null;
```

Update `mount()` and `unmount()`:

```ts
function mount(): void {
  bind();
  start();
  unmountNavigationMenu ??= mountNavigationMenu();
}

function unmount(): void {
  stop();
  unbind();
  unmountNavigationMenu?.();
  unmountNavigationMenu = null;
}
```

- [ ] **Step 5: Run focused, full, and type checks**

Run separately:

```bash
node --test --test-name-pattern="state module preserves" tests/browser-contracts.test.mjs
npm test
npm run check
npm run build
npm run validate:build
```

Expected: every command exits 0; build remains seven routes and one local JS file below 25KB gzip.

- [ ] **Step 6: Commit the interaction module**

```bash
git add src/scripts/navigation-menu.ts src/scripts/smooth-scroll.ts tests/browser-contracts.test.mjs
git commit -m "feat: add premium compact menu interaction"
```

## Task 3: Verify real hover, motion, re-entry, and fallbacks

**Files:**
- Modify: `tests/browser-contracts.test.mjs`
- Modify: `scripts/verify-browser.mjs`

- [ ] **Step 1: Add a failing browser-harness coverage contract**

Extend the browser-runner contract array with:

```js
/nav-disclosure__reveal/,
/data-menu-state/,
/hoverSummary/,
/Escape/,
/menuEarlyHeight/,
/menuMidHeight/,
/menuFinalHeight/,
```

- [ ] **Step 2: Run the focused contract and verify RED**

Run:

```bash
node --test --test-name-pattern="browser runner covers" tests/browser-contracts.test.mjs
```

Expected: FAIL because the runner does not yet sample the compact reveal.

- [ ] **Step 3: Add the compact fine-pointer motion pass**

Before the existing `375×812` keyboard pass, navigate Home at `1024×768`, obtain unique summary/details/reveal locators, and add this behavior:

```js
await page.setViewportSize({ width: 1024, height: 768 });
await page.goto(baseUrl, { waitUntil: 'networkidle' });

const hoverMenu = page.locator('.nav-disclosure');
const hoverSummary = page.locator('.nav-disclosure > summary');
const hoverReveal = page.locator('.nav-disclosure__reveal');
const hoverFirstLink = page.locator('.nav-disclosure nav a[href="/"]');
const summaryBox = await hoverSummary.boundingBox();

if (!summaryBox) errors.push('Compact Menu trigger has no pointer geometry at 1024px.');
else {
  await page.mouse.move(summaryBox.x + summaryBox.width / 2, summaryBox.y + summaryBox.height / 2);
  await page.waitForTimeout(80);
  const menuEarlyHeight = await hoverReveal.evaluate((element) => element.getBoundingClientRect().height);
  await page.waitForTimeout(360);
  const menuMidHeight = await hoverReveal.evaluate((element) => element.getBoundingClientRect().height);
  await page.waitForTimeout(720);
  const menuFinalHeight = await hoverReveal.evaluate((element) => element.getBoundingClientRect().height);
  const openState = await hoverMenu.evaluate((element) => ({ open: element.open, state: element.dataset.menuState }));

  if (!openState.open || openState.state !== 'open') errors.push(`Compact hover did not open: ${JSON.stringify(openState)}.`);
  if (!(menuEarlyHeight > 0 && menuMidHeight > menuEarlyHeight && menuFinalHeight > menuMidHeight)) {
    errors.push(`Compact reveal was not progressively increasing: ${menuEarlyHeight}, ${menuMidHeight}, ${menuFinalHeight}.`);
  }

  const panelWidth = await hoverReveal.evaluate((element) => element.getBoundingClientRect().width);
  if (Math.abs(panelWidth - 204) > 2) errors.push(`Compact panel width is ${panelWidth}px instead of approximately 204px.`);

  await hoverFirstLink.hover();
  const linkStyle = await hoverFirstLink.evaluate((element) => {
    const style = getComputedStyle(element);
    return { background: style.backgroundColor, color: style.color, boxShadow: style.boxShadow };
  });
  if (linkStyle.background !== 'rgb(11, 11, 11)' || linkStyle.color !== 'rgb(255, 255, 255)' || !linkStyle.boxShadow.includes('24, 74, 232')) {
    errors.push(`Compact row response is incorrect: ${JSON.stringify(linkStyle)}.`);
  }

  await page.mouse.move(4, 740);
  await page.waitForTimeout(100);
  if (!(await hoverMenu.evaluate((element) => element.open))) errors.push('Compact menu ignored the pointer-leave grace window.');
  await page.waitForTimeout(760);
  if (await hoverMenu.evaluate((element) => element.open)) errors.push('Compact menu did not finish closing after pointer leave.');

  await page.mouse.move(summaryBox.x + summaryBox.width / 2, summaryBox.y + summaryBox.height / 2);
  await page.waitForTimeout(1100);
  await page.mouse.move(4, 740);
  await page.waitForTimeout(260);
  await page.mouse.move(summaryBox.x + summaryBox.width / 2, summaryBox.y + summaryBox.height / 2);
  await page.waitForTimeout(100);
  const reentryState = await hoverMenu.evaluate((element) => ({ open: element.open, state: element.dataset.menuState }));
  if (!reentryState.open || reentryState.state !== 'open') errors.push(`Compact menu did not reverse cleanly on re-entry: ${JSON.stringify(reentryState)}.`);
}
```

- [ ] **Step 4: Extend keyboard, reduced-motion, no-JS, and desktop checks**

After the existing Enter assertion at `375×812`, press Escape and require `open === false` and focus on the summary; then reopen with Enter before testing the first link.

In the reduced-motion context, collect `.nav-disclosure__reveal` transition durations and require every duration to be at most `0.001` seconds.

In the no-JavaScript context, click `.nav-disclosure > summary`, require the native details element to open, and then continue the existing FAQ/navigation checks.

At `1440px`, require `.nav-disclosure` to be hidden and `.desktop-nav` to be visible.

- [ ] **Step 5: Run source and full browser verification**

Run separately:

```bash
node --test tests/browser-contracts.test.mjs
npm run build
npm run verify:browser
```

Expected: static contracts PASS; build emits seven routes; browser verifier reports 35 route/viewport checks, 14 Axe scans, the premium compact interaction, existing Lenis/fallback behavior, and zero third-party requests.

- [ ] **Step 6: Commit permanent browser coverage**

```bash
git add scripts/verify-browser.mjs tests/browser-contracts.test.mjs
git commit -m "test: verify premium compact menu behavior"
```

## Task 4: Capture acceptance evidence and update authority

**Files:**
- Create: `docs/verification/2026-07-19-premium-compact-menu-verification.md`
- Create: `docs/verification/screenshots/menu-hover-1024.png`
- Modify: `README.md`

- [ ] **Step 1: Run each deterministic command separately**

Run and record exact output and exit status:

```bash
npm run check
npm test
npm run validate:content
npm run build
npm run validate:build
npm run verify:browser
npm audit --omit=dev
npm run validate:production
```

Expected: every command except `validate:production` exits 0. Production validation remains an expected non-zero result with LB-01 through LB-08 open.

- [ ] **Step 2: Capture the approved open/hover state**

Start the built preview on `127.0.0.1:4321`. At `1024×768`, move a fine pointer onto Menu, wait `1150ms`, hover “The System,” and save the viewport screenshot to:

```text
docs/verification/screenshots/menu-hover-1024.png
```

Open the PNG at original resolution. Reject it for overflow, clipping, a panel wider than the approved compact width, visible numbers, square corners, colorful glow, focus collision, unreadable wrapping, or a title-card/desktop-navigation regression.

- [ ] **Step 3: Write the verification record**

Record:

- implementation commit and Node/npm/Chrome versions;
- exact command results;
- test count, route count, Axe count, JS/CSS gzip sizes, and largest transfer;
- measured panel width, opening samples, close/grace behavior, re-entry behavior, row hover colors, keyboard/Escape, touch/click, reduced motion, and no-JS results;
- screenshot path and visual inspection result;
- Safari/WebKit and VoiceOver limitations if still unexecuted;
- expected production-validator failure and unchanged private-prototype boundary.

- [ ] **Step 4: Update README authority order**

Place the 2026-07-19 interaction spec, this plan, and the new verification record immediately after the governing 2026-07-18 visual materials. Update the Current gate sentence to mention the refined compact hover menu while preserving the local-only, no-form, no-data, no-deployment boundary.

- [ ] **Step 5: Commit only acceptance artifacts**

```bash
git add README.md docs/verification/2026-07-19-premium-compact-menu-verification.md docs/verification/screenshots/menu-hover-1024.png
git commit -m "docs: record premium compact menu verification"
```

## Task 5: Final ledger and handoff

**Files:** No changes unless a verified defect requires a separate test-first fix.

- [ ] **Step 1: Run the final complete verifier after the evidence commit**

```bash
npm run verify
```

Expected: exit 0; seven routes, all Node tests, content/build checks, one local client module, 35 route/viewport checks, 14 Axe scans, compact hover behavior, Lenis, keyboard, reduced motion, no-JS, and zero third-party requests all pass.

- [ ] **Step 2: Check the exact feature ledger**

Use `8592170` as the implementation base:

```bash
git diff 8592170..HEAD --check
git diff --name-status 8592170..HEAD
git status --short
git log --oneline 8592170..HEAD
```

Expected: no whitespace errors, no uncommitted files, and only the planned component, CSS, script, tests, verifier, README, verification record, and screenshot changes.

- [ ] **Step 3: Scan runtime residue**

```bash
rg -n -i "linear-gradient|radial-gradient|backdrop-filter|filter:\s*blur|cursorX|cursorY|mousemove|gsap|anime" src/components/SiteHeader.astro src/styles/global.css src/scripts/navigation-menu.ts dist
rg -n -i "https?://" dist src/components src/styles src/scripts
```

Expected: no prohibited visual/interaction residue. Generated HTML contains only the existing `https://private-review.invalid/` canonical metadata; no runtime third-party asset appears.

- [ ] **Step 4: Hand off without expanding scope**

Report final commit, verification totals and budgets, local preview command/URL, screenshot link, Safari/assistive-technology limitations, and confirmation that `.superpowers/` was not staged. Do not merge, deploy, push, publish, close launch blockers, or activate data collection at this gate.
