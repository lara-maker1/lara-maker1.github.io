# YouTube Operating System Private Prototype Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build and verify a complete seven-route, English-first, static private website prototype that presents YouTube Operating System as an operated service methodology, collects no data, withholds unapproved claims, and remains local-only.

**Architecture:** Astro 7.1.1 generates semantic static HTML from auditable English content modules. Focused Astro components provide the shared editorial system, while Node scripts validate source content, generated routes, metadata, claims, accessibility contracts, network behavior, and budgets. The visitor experience ships no client JavaScript; native HTML handles navigation and disclosure behavior.

**Tech Stack:** Node 26.3.0, npm 11.16.0, Astro 7.1.1, TypeScript 6.0.3, `@astrojs/check` 0.9.9, Node's built-in test runner, `playwright-core` 1.61.1 using locally installed Chrome, and `axe-core` 4.12.1.

---

## Scope, authority, and deliberate deferrals

- This plan implements only the local private prototype authorized by the approved specification.
- Primary proposition: “We build and operate the YouTube function inside your business.”
- Primary CTA: “Request a strategy conversation” linking only to `/apply/`.
- “YouTube Operating System” always means a coordinated service method, never software.
- Evidence defaults to non-public. Review notes are visibly labeled internal annotations; they are never case-study-shaped content.
- Apply contains explanatory question previews only: no form, enabled control, submit button, endpoint, `mailto:`, scheduler, CRM, storage, or external destination.
- Production forms, public identity, final offer availability, evidence approval, privacy/legal decisions, hosting, deployment, production headers, public canonicals, launch-blocker closure, and launch are explicitly deferred.
- No authentication, database, CMS, API, analytics, cookies, pixels, chat, maps, remote fonts, remote assets, embeds, third-party scripts, platform UI, dashboard, AI feature, automation, billing, or SaaS behavior is built.
- No deploy, publish, push, or public URL is created.

## Confirmed technical baseline

- Repository: `website-source/` within the ownership-transfer package.
- Branch and approved implementation location: `main` (inline implementation on `main` was explicitly authorized by the session brief).
- Starting commit: `1116b36ea7f240353272fdad033ee8b49c48f97a`.
- Starting worktree: clean; exactly six tracked Markdown files; no scaffold.
- Runtime: Node `v26.3.0`; npm `11.16.0`; no global Astro.
- Official npm registry checks on 2026-07-17: Astro `7.1.1`, `@astrojs/check` `0.9.9`, `playwright-core` `1.61.1`, and `axe-core` `4.12.1`. The registry's current TypeScript 7 release is outside `@astrojs/check`'s declared `^5.0.0 || ^6.0.0` peer range, so the newest compatible release, TypeScript `6.0.3`, is pinned. Astro 7.1.1 requires Node `>=22.12.0` and npm `>=9.6.5`, so the local runtime is compatible.
- Astro is confirmed because it meets D-004 and D-012 with static output, reusable components, local content, zero-JavaScript defaults, and no application runtime.

## Complete file structure

```text
.
├── .gitignore                               # Excludes dependency/build artifacts and macOS metadata.
├── astro.config.mjs                       # Static output and review-site URL used only for local metadata.
├── package.json                           # Exact scripts and pinned direct dependencies.
├── package-lock.json                      # Deterministic npm dependency graph.
├── tsconfig.json                          # Strict Astro TypeScript baseline.
├── public/
│   └── robots.txt                         # Disallows all crawling for private review.
├── scripts/
│   ├── validate-content.mjs               # Stable-ID/schema and prohibited source-content guard.
│   ├── validate-build.mjs                 # Route, metadata, links, assets, annotation, claim, and budget guard.
│   ├── validate-production.mjs            # Intentional fail-closed production launch-blocker check.
│   └── verify-browser.mjs                 # Chrome/axe/network/viewport/browser-behavior checks.
├── src/
│   ├── env.d.ts                           # Astro type reference.
│   ├── components/
│   │   ├── DecisionLoop.astro             # Observation → interpretation → next decision sequence.
│   │   ├── EvidenceReserved.astro         # Internal review note, never public-style evidence.
│   │   ├── FAQList.astro                  # Native-details disclosure; content works without JS.
│   │   ├── FailureModeCard.astro           # Problem, consequence, response.
│   │   ├── FitMatrix.astro                 # Strong-fit and poor-fit lists with text indicators.
│   │   ├── MeasurementLayer.astro          # Claim-safe measurement category.
│   │   ├── Notice.astro                    # Explicit private/limitation notice.
│   │   ├── OutcomeShift.astro              # From/to operating change.
│   │   ├── PageIntro.astro                 # One-page H1 and optional CTA.
│   │   ├── PrimaryCTA.astro                # Exact CTA label and `/apply/` destination.
│   │   ├── ProcessRail.astro               # Semantic ordered method stages.
│   │   ├── SectionHeading.astro            # Stable anchored section heading.
│   │   ├── ServiceCard.astro               # Provisional service fields and exclusions.
│   │   ├── SiteFooter.astro                # Method summary and local route navigation.
│   │   └── SiteHeader.astro                # Text identity, active route, CTA, native mobile menu.
│   ├── content/en/
│   │   ├── about.mjs                       # Company-method narrative and principles.
│   │   ├── apply.mjs                       # Non-submitting qualification preview.
│   │   ├── fit.mjs                         # Fit, readiness, anti-fit, self-assessment content.
│   │   ├── home.mjs                        # Home sections, shifts, comparison, and FAQs.
│   │   ├── results.mjs                     # Measurement layers and evidence governance.
│   │   ├── services.mjs                    # Five provisional engagement paths.
│   │   ├── shared.mjs                      # Identity marker, navigation, page metadata, CTA.
│   │   └── system.mjs                      # Seven stages, responsibilities, and boundaries.
│   ├── layouts/
│   │   └── BaseLayout.astro                # Metadata, noindex, landmarks, header/footer, global CSS.
│   ├── pages/
│   │   ├── about.astro
│   │   ├── apply.astro
│   │   ├── fit.astro
│   │   ├── index.astro
│   │   ├── results.astro
│   │   ├── services.astro
│   │   └── system.astro                    # Exactly the seven approved routes.
│   └── styles/
│       └── global.css                      # Editorial manual tokens, grids, responsive and a11y states.
├── tests/
│   ├── content.test.mjs                    # TDD source contracts and claim governance.
│   ├── build.test.mjs                      # TDD generated route/metadata/link contracts.
│   ├── browser-contracts.test.mjs          # Browser script configuration and no-form/no-JS contracts.
│   └── validators.test.mjs                 # Fixture tests for content, build, and production guards.
├── docs/
│   ├── decision-log.md                     # D-012 updated to confirmed Astro implementation.
│   ├── verification/
│   │   └── 2026-07-17-private-prototype-verification.md
│   └── superpowers/plans/
│       └── 2026-07-17-youtube-operating-system-site-implementation.md
└── README.md                               # Runbook, scope, and truthful final prototype state.
```

## Content ledger used by the implementation

The implementation uses stable IDs and exact claims-safe concepts below. Copy may be line-broken for layout, but meaning and qualification must not be strengthened.

### Shared metadata and identity

```js
export const site = {
  identity: { id: 'site-identity', publicName: null, reviewLabel: 'YouTube Operating System', blockerId: 'LB-01' },
  proposition: 'We build and operate the YouTube function inside your business.',
  explanation: 'Research, positioning, content architecture, production, publishing, and learning—connected to the decisions your business needs to make.',
  cta: { id: 'primary-cta', label: 'Request a strategy conversation', href: '/apply/' },
  reviewMode: true,
};

export const navigation = [
  ['home', 'Home', '/'], ['system', 'The System', '/system/'],
  ['services', 'Services', '/services/'], ['fit', 'Who It Is For', '/fit/'],
  ['results', 'Results', '/results/'], ['about', 'About', '/about/'],
  ['apply', 'Apply', '/apply/'],
].map(([id, label, href]) => ({ id, label, href }));
```

All pages use unique review-safe titles and descriptions, `robots: noindex, nofollow, noarchive`, one H1, and a local-review canonical under `https://private-review.invalid`. The `.invalid` origin is metadata only and is never requested or deployed.

### Home

- `home-hero`: exact proposition, approved support line, CTA, “See how the system works,” and fit line.
- `home-failure-modes`: unclear position; topics without evidence; production without ownership; analytics without decisions. Each states a consequence and method response.
- `home-method-loop`: seven stages from business context through learning and decisions.
- `home-outcome-shifts`: scattered ideas → content thesis; isolated videos → connected library; internal assumptions → audience evidence; reporting → next decisions.
- `home-engagements`: diagnostic, strategy, launch/reset, ongoing operation, and internal-team enablement, qualified as provisional and scope-dependent.
- `home-fit`: established expertise-led businesses with decision participation versus instant-result, output-only, or software-product expectations.
- `home-comparison`: starting point, unit of work, topic selection, production, measurement, and after publishing.
- `home-evidence`: an internal review note naming C-001–C-005 and C-017 without reproducing their claims.
- `home-faq`: six specification questions; answers state service method, compounding iteration, no guarantees, meaningful participation, possible internal-team collaboration depending on scope, and no software.

### The System

Each of `stage-business-context`, `stage-audience-evidence`, `stage-positioning`, `stage-content-architecture`, `stage-production`, `stage-publishing`, and `stage-learning-decisions` includes the exact input, governing question, output, and dependency from the specification. The page also contains:

```js
export const decisionSteps = [
  { id: 'decision-observation', label: 'Observation', text: 'State what happened without turning the observation into a conclusion.' },
  { id: 'decision-interpretation', label: 'Interpretation', text: 'Explain what the available evidence may suggest, including uncertainty and alternatives.' },
  { id: 'decision-next', label: 'Next decision', text: 'Assign the content, positioning, production, or measurement change to test next.' },
];
```

Client inputs include priorities, expertise, source material, spokesperson access, and review ownership. Operator responsibilities include research synthesis, positioning facilitation, architecture, coordination, packaging, publishing support, and learning cadence, always qualified by engagement scope. “What the system is not” explicitly names no portal, API, automation, AI platform, CRM replacement, or guaranteed attribution.

### Services

The exact service IDs are `service-diagnostic`, `service-strategy`, `service-launch-reset`, `service-ongoing-operation`, and `service-team-enablement`. Each has `bestWhen`, `scopeCategories`, `participation`, `intendedDecision`, and the same exclusion: “Performance is not guaranteed; availability and final scope require fit and service approval.” No price, timeline, count, capacity, or contract promise is present.

### Fit

Strong-fit signals cover working offer, sufficient margin without a threshold, identifiable expertise, real audience questions, leadership commitment, recording access, and willingness to learn. Readiness inputs cover priorities, audience knowledge, offers, source material, examples, spokesperson availability, review owner, and reasonable decision cadence. Poor-fit signals cover instant leads, guaranteed virality, output-only procurement, unavailable expertise, no defined offer, and no review ownership. The self-assessment is a semantic list of questions, not controls, scoring, storage, or submission.

### Results

The four exact layer IDs are `measurement-attention`, `measurement-content-behavior`, `measurement-qualified-demand`, and `measurement-operating-quality`. They describe the specification's signals, interpretation caution, and decision use. The page uses the decision sequence above, an internal review note controlled by LB-03, and a no-guarantee note. It contains no case cards, logos, metrics, quotes, stories, or charts.

### About

The page says a durable YouTube function replaces recurring content chaos and explains five principles: business before content; evidence before topic volume; decisions and ownership; human judgment over uncontrolled automation; learning after publication. It conservatively describes the method as organizing research, content, production, localization considerations, and channel learning, without biography, credentials, history, headcount, staff, channel count, milestone, or portrait. LB-06 appears only in an internal review note.

### Apply

The page heading is the exact CTA. It explains fit review first, then strategy conversation when appropriate, then a clearly scoped next step. The preview items are company and role, website if relevant, offer/business model, current YouTube state, primary objective, main operating constraint, team participation, and timing context. The exact notice “This private prototype does not submit or store information.” appears with an LB-05 internal review note. No `<form>`, form control, submit behavior, endpoint, `mailto:`, scheduler, or external link is rendered.

---

### Task 1: Establish the pinned static build and test harness

**Files:**
- Create: `.gitignore`
- Create: `package.json`
- Create: `package-lock.json`
- Create: `astro.config.mjs`
- Create: `tsconfig.json`
- Create: `src/env.d.ts`
- Test: `tests/content.test.mjs`

- [ ] **Step 1: Create the exact package and configuration baseline**

`.gitignore` contains `node_modules/`, `dist/`, `.astro/`, and `.DS_Store` so clean installs and builds cannot pollute the project ledger.

```json
{
  "name": "youtube-operating-system-private-site",
  "version": "0.1.0",
  "private": true,
  "type": "module",
  "engines": { "node": ">=22.12.0", "npm": ">=9.6.5" },
  "scripts": {
    "dev": "ASTRO_TELEMETRY_DISABLED=1 astro dev --host 127.0.0.1",
    "build": "ASTRO_TELEMETRY_DISABLED=1 astro build",
    "preview": "ASTRO_TELEMETRY_DISABLED=1 astro preview --host 127.0.0.1",
    "check": "ASTRO_TELEMETRY_DISABLED=1 astro check",
    "test": "node --test tests/*.test.mjs",
    "validate:content": "node scripts/validate-content.mjs",
    "validate:build": "node scripts/validate-build.mjs",
    "validate:production": "node scripts/validate-production.mjs",
    "verify:browser": "node scripts/verify-browser.mjs",
    "verify": "npm run check && npm test && npm run validate:content && npm run build && npm run validate:build && npm run verify:browser"
  },
  "dependencies": { "astro": "7.1.1" },
  "devDependencies": {
    "@astrojs/check": "0.9.9",
    "axe-core": "4.12.1",
    "playwright-core": "1.61.1",
    "typescript": "6.0.3"
  }
}
```

`astro.config.mjs` exports `defineConfig({ output: 'static', site: 'https://private-review.invalid', trailingSlash: 'always' })`. `tsconfig.json` extends `astro/tsconfigs/strict`. `src/env.d.ts` contains `/// <reference types="astro/client" />`.

- [ ] **Step 2: Install from the exact manifest**

Run: `npm install --package-lock-only && npm ci`

Expected: exit 0, a deterministic `package-lock.json`, and no install script that downloads browser binaries.

- [ ] **Step 3: Write the first failing source-contract test**

Create `tests/content.test.mjs` so it imports `site`, `navigation`, `pages`, `services`, `methodStages`, `measurementLayers`, and `evidenceItems`; asserts seven unique routes, stable unique IDs, exact CTA/proposition, complete service/stage fields, `publicationState === 'non-public'` for evidence, and no prohibited expressions.

```js
const prohibited = [
  /11\s+channels?/i, /100,?000\s+subscribers?/i, /one\s+million\s+subscribers?/i,
  /10\s*[–-]\s*30\s*[×x]/i, /120\s+channels?/i, /guaranteed\s+(views|leads|revenue|results?)/i,
  /proprietary\s+(platform|dashboard|ai)/i, /client\s+portal/i, /automated\s+integration/i,
];
```

- [ ] **Step 4: Run the test and verify RED**

Run: `node --test tests/content.test.mjs`

Expected: FAIL because `src/content/en/shared.mjs` and related source modules do not exist.

- [ ] **Step 5: Commit the deterministic baseline only**

```bash
git add package.json package-lock.json astro.config.mjs tsconfig.json src/env.d.ts tests/content.test.mjs
git commit -m "chore: establish Astro prototype baseline"
```

### Task 2: Add governed English content modules

**Files:**
- Create: `src/content/en/shared.mjs`
- Create: `src/content/en/home.mjs`
- Create: `src/content/en/system.mjs`
- Create: `src/content/en/services.mjs`
- Create: `src/content/en/fit.mjs`
- Create: `src/content/en/results.mjs`
- Create: `src/content/en/about.mjs`
- Create: `src/content/en/apply.mjs`
- Modify: `tests/content.test.mjs`

- [ ] **Step 1: Implement the minimum shared exports and seven page records**

Use the exact shared content ledger above. Every page record has `{ id, route, navLabel, title, description, eyebrow, heading, summary }`; IDs and routes are unique. Private metadata uses the neutral review label and never puts an `[LB-` marker into title or description.

- [ ] **Step 2: Run the focused test and confirm the remaining field failures**

Run: `node --test tests/content.test.mjs`

Expected: FAIL on missing stage, service, measurement, evidence, or page-section fields rather than module-not-found.

- [ ] **Step 3: Implement all page-specific exports from the content ledger**

Use plain arrays and objects, stable kebab-case IDs, and no rendered HTML strings. Evidence records use this exact shape:

```js
export const evidenceItems = [{
  id: 'evidence-reserved-primary',
  claimIds: ['C-001', 'C-002', 'C-003', 'C-004', 'C-005', 'C-017'],
  publicationState: 'non-public',
  blockerId: 'LB-03',
  reviewSummary: 'Verified evidence and permissions have not cleared the claims register.',
}];
```

Launch notes use `{ id, blockerId, label: 'Review note — not public copy', text }`; only LB-01, LB-03, LB-05, and LB-06 appear where the specification permits them.

- [ ] **Step 4: Run content tests and verify GREEN**

Run: `node --test tests/content.test.mjs`

Expected: all source-contract tests pass with zero failures.

- [ ] **Step 5: Commit governed content**

```bash
git add src/content/en tests/content.test.mjs
git commit -m "feat: add governed English site content"
```

### Task 3: Render the shared shell, components, and seven static routes

**Files:**
- Create: all files under `src/components/`
- Create: `src/layouts/BaseLayout.astro`
- Create: all seven files under `src/pages/`
- Test: `tests/build.test.mjs`

- [ ] **Step 1: Write the failing generated-site test**

`tests/build.test.mjs` reads `dist/index.html` and each nested `dist/<route>/index.html`. It asserts: seven files exist; one H1 per file; unique title and description; canonical on `.invalid`; noindex meta; semantic `header`, `nav`, `main`, and `footer`; visible skip-link source; active navigation with `aria-current="page"`; all local route links resolve; Apply contains no `<form>`, `input`, `select`, `textarea`, `button[type=submit]`, `mailto:`, external scheduler, or network endpoint; and no `<script src>` or module client script exists.

- [ ] **Step 2: Run the build test and verify RED**

Run: `npm run build && node --test tests/build.test.mjs`

Expected: build or test FAIL because layouts, components, and routes do not exist.

- [ ] **Step 3: Implement `BaseLayout.astro`, `SiteHeader.astro`, and `SiteFooter.astro`**

`BaseLayout` owns `<title>`, description, canonical, `<meta name="robots" content="noindex, nofollow, noarchive">`, skip link, header, `<main id="main-content">`, footer, and one global stylesheet import. `SiteHeader` uses a text wordmark and native `<details class="nav-disclosure">` for the mobile menu, repeats the same route list once per visible navigation surface, applies `aria-current="page"`, and closes no menu with script. `SiteFooter` states that the methodology connects business context, content, and learning; it publishes no identity/contact/legal fiction.

- [ ] **Step 4: Implement the focused semantic components**

All components accept text/data props and render no unsafe HTML. `ProcessRail` is an `<ol>`; `DecisionLoop` is an `<ol>`; `FAQList` uses `<details><summary>`; `FitMatrix` uses titled `<section>`/lists; `EvidenceReserved` renders `role="note"`, the exact label “Review note — not public copy,” blocker/claim IDs, and a statement that the area is not proof; `Notice` includes its severity in visible text. Diagrams expose a nearby ordered text equivalent and hide purely decorative connectors with `aria-hidden="true"`.

- [ ] **Step 5: Compose all seven pages from content imports**

Each route imports its page record and section arrays. Home follows all ten section contracts. System renders stage input/question/output/dependency and the decision loop. Services renders all five card field groups. Fit renders the thesis, readiness, strong/poor fit, and non-interactive assessment. Results renders only measurement and internal evidence-reserved material. About renders company-method content without biography. Apply renders preview items as `<article>`/definition-list content and no controls.

- [ ] **Step 6: Run build tests and verify GREEN**

Run: `npm run build && node --test tests/build.test.mjs`

Expected: static build succeeds; seven generated-route tests pass; no missing route, metadata, link, form, or script contract.

- [ ] **Step 7: Commit the semantic site**

```bash
git add src/components src/layouts src/pages tests/build.test.mjs
git commit -m "feat: render seven-route private prototype"
```

### Task 4: Add fail-closed claim, route, asset, metadata, and budget guards

**Files:**
- Create: `scripts/validate-content.mjs`
- Create: `scripts/validate-build.mjs`
- Create: `scripts/validate-production.mjs`
- Create: `public/robots.txt`
- Test: `tests/validators.test.mjs`
- Modify: `tests/content.test.mjs`
- Modify: `tests/build.test.mjs`

- [ ] **Step 1: Add failing tests for validator behavior**

The tests run validators in fixture mode against temporary strings/directories and require failures for a prohibited claim, an external asset URL, a missing route, an unresolved internal link, an unlabeled LB marker, and production mode with open LB-01 through LB-08. They require success for the private rendered pattern `Review note — not public copy` paired with an allowed blocker ID.

- [ ] **Step 2: Run the validator tests and verify RED**

Run: `npm test`

Expected: FAIL because validator modules do not exist.

- [ ] **Step 3: Implement source and rendered-output validation**

`validate-content.mjs` walks only `src/content/en/*.mjs`, imports them, checks required objects/arrays and unique IDs, and scans visitor copy with the prohibited expressions. `validate-build.mjs` checks the seven exact outputs, one H1, titles, descriptions, canonicals, noindex, internal links/assets, no external `http(s)` request-bearing attributes, no forms or submission destinations, no scripts, no remote fonts, and gzip budgets: JS `<=25KB`, CSS `<=60KB`, each page transfer `<=1MB`. Internal `.invalid` canonicals are explicitly metadata-only and excluded from request-bearing checks.

- [ ] **Step 4: Implement the production gate**

`validate-production.mjs` always reads `docs/launch-blockers.md`, detects `LB-01` through `LB-08` as open, reports each controlling blocker, and exits 1. It also scans `dist` for any `[LB-` or “Review note — not public copy” content. This is a deliberate proof that production output cannot be claimed while required launch approvals are absent.

- [ ] **Step 5: Add the private robots policy**

```text
User-agent: *
Disallow: /
```

- [ ] **Step 6: Verify GREEN and the intentional production failure**

Run: `npm test && npm run validate:content && npm run build && npm run validate:build`

Expected: all private-prototype validators pass.

Run: `npm run validate:production`

Expected: exit 1 with LB-01 through LB-08 reported as open; this expected failure is recorded, never hidden or changed into a pass.

- [ ] **Step 7: Commit governance and build guards**

```bash
git add scripts public/robots.txt tests
git commit -m "test: enforce private prototype governance"
```

### Task 5: Implement the editorial operating-manual visual system accessibly

**Files:**
- Create: `src/styles/global.css`
- Modify: `src/components/SiteHeader.astro`
- Modify: `src/components/ProcessRail.astro`
- Modify: `src/components/DecisionLoop.astro`
- Modify: `src/components/FitMatrix.astro`
- Modify: `src/components/EvidenceReserved.astro`
- Test: `tests/browser-contracts.test.mjs`

- [ ] **Step 1: Write failing accessibility and responsive source contracts**

Assert the stylesheet includes the approved tokens, `:focus-visible`, `scroll-margin`, minimum `44px` targets, `overflow-wrap`, `@media (prefers-reduced-motion: reduce)`, narrow/medium/wide breakpoints, and no fixed-height text container. Assert components retain semantic list source order and review-note visible text.

- [ ] **Step 2: Run the contracts and verify RED**

Run: `node --test tests/browser-contracts.test.mjs`

Expected: FAIL because `global.css` and required class contracts do not exist.

- [ ] **Step 3: Implement exact visual tokens and base behavior**

```css
:root {
  --canvas: #f6f2ea; --surface: #fffdfc; --ink: #122033; --muted-ink: #4b596a;
  --system-teal: #236b6a; --teal-wash: #ddebe7; --signal-amber: #a84f16;
  --amber-wash: #f4e1d2; --rule: #c9c2b8; --focus: #005fcc;
  --focus-dark: #8ec5ff; --display: "Iowan Old Style", "Palatino Linotype", "Book Antiqua", Georgia, serif;
  --body: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  --container: 75rem; --measure: 68ch;
}
```

Use `clamp()` only for spacing and headings within the approved ranges, never viewport-only font scaling. Body is 18px/1.65. Layout uses a capped container with 20–48px gutters, generous section rhythm, rules rather than shadows, radii no larger than 12px, and a 12-column wide / 6-column medium / single-column narrow grid.

- [ ] **Step 4: Implement component treatments**

The first viewport shows the offer and a visible hint of the next section. Process rails use numbered stages and non-color text labels. Comparisons become paired dimension blocks on narrow viewports. Fit columns stack with explicit headings. Evidence notes use amber wash, a strong top rule, “INTERNAL REVIEW” text, blocker/claim IDs, and no proof-like card treatment. Buttons have at least 44px practical height; body links are underlined; focus uses a 3px contrasting outline with offset and is never clipped.

- [ ] **Step 5: Implement resilient navigation and reduced motion**

Desktop navigation appears only when measured space permits at `min-width: 72rem`; the native disclosure remains below that width. At 320px there is no horizontal page overflow. Under reduced motion, transitions and smooth scrolling are disabled. No animation is required to understand state.

- [ ] **Step 6: Run checks and verify GREEN**

Run: `npm run check && npm test && npm run build && npm run validate:build`

Expected: Astro check, all tests, build, and budget checks pass without errors.

- [ ] **Step 7: Commit the interface system**

```bash
git add src/styles src/components tests/browser-contracts.test.mjs
git commit -m "style: add editorial operating manual system"
```

### Task 6: Add automated browser, accessibility, network, and viewport verification

**Files:**
- Create: `scripts/verify-browser.mjs`
- Modify: `package.json`
- Modify: `tests/browser-contracts.test.mjs`

- [ ] **Step 1: Write the failing browser-runner contract**

Assert the runner covers all seven routes, all five required viewports, Axe `wcag2a`, `wcag2aa`, `wcag21aa`, and `wcag22aa` tags, console/page errors, non-loopback requests, horizontal overflow, focus order, active navigation, review-note labeling, Apply's lack of controls, reduced motion, and core content after JavaScript is disabled.

- [ ] **Step 2: Run the contract and verify RED**

Run: `node --test tests/browser-contracts.test.mjs`

Expected: FAIL because the complete runner is not present.

- [ ] **Step 3: Implement the browser runner**

The script starts `astro preview` on `127.0.0.1:4321`, waits for readiness, launches local Chrome through `playwright-core` with `channel: 'chrome'`, injects the local `axe-core/axe.min.js`, and fails on serious/critical Axe violations, console/page errors, failed requests, non-loopback requests, page overflow, missing landmarks/H1/active state, or Apply controls. It repeats the 320×568, 375×812, 768×1024, 1024×768, and 1440×900 checks. It creates a second context with `javaScriptEnabled: false` and verifies navigation/content on all routes, then a reduced-motion context and confirms computed transition/animation durations are disabled where applicable. It always closes the browser and preview child process.

- [ ] **Step 4: Run and verify GREEN**

Run: `npm run build && npm run verify:browser`

Expected: 7/7 routes pass automated Axe, console, network, JavaScript-disabled, reduced-motion, and 5-viewport overflow checks in local Chrome.

- [ ] **Step 5: Commit browser verification**

```bash
git add scripts/verify-browser.mjs package.json tests/browser-contracts.test.mjs
git commit -m "test: add browser accessibility verification"
```

### Task 7: Perform browser-visible QA and revise defects

**Files:**
- Modify as defects require: `src/styles/global.css`, `src/components/*.astro`, `src/pages/*.astro`, `src/content/en/*.mjs`
- Create: `docs/verification/2026-07-17-private-prototype-verification.md`

- [ ] **Step 1: Start the local development server**

Run: `npm run dev -- --port 4321`

Expected: local-only server at `http://127.0.0.1:4321/`.

- [ ] **Step 2: Connect the available in-app browser or Chrome-control surface**

Use the browser-control skill, obtain the runtime-default browser, read its complete documentation once, and open the local URL. Do not substitute DOM-only automation for visible inspection.

- [ ] **Step 3: Inspect every route at the required viewport matrix**

For every route, check navigation, hero/page-intro wrapping, process rail, comparison transformations, fit sections, Results internal state, Apply preview, footer, focus visibility, source order, clipping, overflow, console errors, failed requests, and third-party requests. Capture screenshots for representative 320×568, 768×1024, and 1440×900 states, plus any defect evidence.

- [ ] **Step 4: Perform visible interaction and accessibility checks**

Use real keyboard input for skip link, mobile disclosure, all navigation/CTA/body links, FAQ disclosures, and reverse traversal. Confirm focus remains visible and unclipped. Enable reduced motion and verify no essential state depends on animation. Disable JavaScript and confirm navigation, disclosures, and all core content remain usable. Inspect 200% zoom and 400% reflow. Use VoiceOver for landmarks, headings, navigation, process text equivalents, disclosures, Results notice, and Apply preview when the GUI surface permits reliable evidence.

- [ ] **Step 5: Fix each observed defect with TDD where behavior changes**

For every defect, first add or tighten a failing automated contract, run it to see the expected failure, implement the minimum fix, rerun the focused test, then repeat the visible check. Do not convert unavailable Safari, Firefox, mobile-engine, or VoiceOver evidence into a pass.

- [ ] **Step 6: Commit verified interface fixes**

```bash
git add src tests scripts
git commit -m "fix: resolve private prototype browser findings"
```

If no defect exists, do not create an empty commit.

### Task 8: Record verification, update project state, and close the private-prototype build gate

**Files:**
- Create: `docs/verification/2026-07-17-private-prototype-verification.md`
- Modify: `README.md`
- Modify: `docs/decision-log.md`

- [ ] **Step 1: Update D-012 without changing launch authority**

Record that Astro 7.1.1 was confirmed for the private prototype on Node 26.3.0 because it satisfies static output, local content, zero-JS visitor behavior, and low runtime dependency requirements. Keep deployment and hosting deferred.

- [ ] **Step 2: Write the evidence report**

Record exact commands, exit codes, test counts, build route count, validator results, expected production-gate failure, gzip/transfer sizes, automated browser/Axe results, browser-visible viewport checks, keyboard/focus evidence, JavaScript-disabled and reduced-motion evidence, screenshots, and precise limitations for unavailable Safari, Firefox, mobile engines, or VoiceOver. Do not use a pass label without fresh evidence.

- [ ] **Step 3: Update README to one truthful terminal state**

If every required private-prototype check passes, state “Private prototype complete and ready for user/evaluator review.” Otherwise state “Private prototype needs fixes” followed by exact failures. Include `npm ci`, `npm run verify`, and `npm run dev -- --port 4321`; state local-only, no data collection, no deployment, and open LB-01 through LB-08.

- [ ] **Step 4: Run the complete fresh verification gate**

```bash
npm ci
npm run check
npm test
npm run validate:content
npm run build
npm run validate:build
npm run verify:browser
npm run validate:production
```

Expected: all private-prototype commands exit 0; `validate:production` exits 1 for LB-01 through LB-08 by design. Record actual counts and sizes from output.

- [ ] **Step 5: Commit documentation and final state**

```bash
git add README.md docs/decision-log.md docs/verification/2026-07-17-private-prototype-verification.md
git commit -m "docs: record private prototype verification"
```

- [ ] **Step 6: Run the exact final repository checks**

```bash
git status --short --branch
git log --oneline -8
git diff HEAD^ --stat
npm test
npm run build
npm run validate:content
npm run validate:build
npm run verify:browser
```

Expected: `## main`, no worktree entries, focused commits visible, 7/7 static routes generated, all automated private-prototype checks passing, and no deployment/push.

## Specification coverage self-review

- **Objective, positioning, audience, anti-audience, messaging:** Tasks 2–3 and the content ledger.
- **Seven-route information architecture and conversion paths:** Tasks 2–3; exact route/link tests in Tasks 3–4.
- **Components and content separation with stable IDs:** file structure and Tasks 2–3.
- **Claim governance, Results evidence state, and About restrictions:** Tasks 2 and 4.
- **Static non-submitting Apply experience:** Tasks 2–4 and browser checks in Tasks 6–7.
- **Editorial visual system, responsive transformations, no fake UI or stock imagery:** Task 5 and visible QA in Task 7.
- **WCAG 2.2 AA structure, targets, focus, reflow, reduced motion, diagrams, and keyboard behavior:** Tasks 3, 5, 6, and 7.
- **Performance budgets and zero visitor JavaScript:** Tasks 3–4 and final fresh verification.
- **Security/privacy, no secrets, no third parties, no data flow:** Tasks 3–4 and network verification in Tasks 6–7.
- **Private noindex/robots and metadata:** Tasks 3–4. Production SEO and public canonicals remain deferred.
- **Testing, browser matrix, JavaScript-disabled behavior, VoiceOver honesty:** Tasks 6–8.
- **Launch blockers, deployment, production forms/headers, and production release:** explicitly deferred; production validation fails closed.

## Plan self-review results

- **Spec coverage:** every applicable private-prototype requirement maps to a task above; no platform, SaaS, production form, deployment, or launch work is included.
- **Instruction-completeness scan:** every code or verification step has an exact path, command, expected result, schema, or copy ledger. “Deferred” denotes deliberate out-of-scope production work with a controlling launch blocker, not unfinished prototype work.
- **Path/type/property consistency:** shared content exports, stable IDs, route records, service fields, stage fields, measurement fields, evidence fields, and launch-note fields have one shape throughout tests, templates, and validators.
- **Claim scan:** the plan repeats prohibited expressions only inside test regexes or describes them as prohibited. Visitor copy uses approved method, fit, measurement, and qualification language only.
- **Execution boundary:** implementation occurs inline on the explicitly approved `main` branch; no subagents, deployment, publishing, push, outreach, external collection, or destructive action is planned.
