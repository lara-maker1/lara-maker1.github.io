# YouTube Operating System Visual Redesign and Smooth Scroll Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the generic cream-and-serif prototype with the approved title-card-led IBM Plex visual system and add restrained Lenis wheel smoothing without weakening content governance, accessibility, native scrolling, or private-review controls.

**Architecture:** Keep Astro's static seven-route architecture and auditable content modules. Refactor the shared Astro shell and presentational components in place, add one local font layer, and initialize one guarded Lenis instance from `BaseLayout.astro`; native HTML remains the core experience when JavaScript is disabled or reduced motion is requested. Extend the existing Node and Playwright guards so the one approved client script is tightly bounded and every visual, motion, accessibility, and claims contract is regression-tested.

**Tech Stack:** Astro 7.1.1, TypeScript 6.0.3, CSS cascade layers, locally hosted IBM Plex WOFF2 assets under OFL-1.1, Lenis 1.3.25, Node's built-in test runner, Playwright Core 1.61.1 with local Chrome, and Axe Core 4.12.1.

---

## Authority, baseline, and invariants

- Governing content/truth specification: `docs/superpowers/specs/2026-07-17-youtube-operating-system-site-design.md`.
- Approved visual/motion addendum: `docs/superpowers/specs/2026-07-18-youtube-operating-system-visual-redesign-and-smooth-scroll-design.md`.
- Starting implementation commit: `c59cdc5` plus the plan/spec-approval documentation commit created at this planning gate.
- Preserve exactly seven routes, local static output, private noindex metadata, launch blockers, claim guards, no form, no data collection, and no third-party runtime request.
- Keep `site.proposition` as `We build and operate the YouTube function inside your business.`. Set only `pages[0].heading` to the approved title-card H1 `We build the YouTube function inside your business.`.
- Do not modify any content module beyond that explicit homepage-heading exception unless a test must preserve an existing stable ID or truth boundary.
- Do not stage or commit `.superpowers/`; it is an untracked visual-companion workspace outside the production artifact ledger.
- Do not deploy, publish, push, activate a form, add analytics, or change public-launch status.

## File responsibility map

### Create

- `src/assets/fonts/IBMPlexSansCondensed-Medium.woff2` — display weight 500.
- `src/assets/fonts/IBMPlexSansCondensed-SemiBold.woff2` — display weight 600.
- `src/assets/fonts/IBMPlexSans-Regular.woff2` — body weight 400.
- `src/assets/fonts/IBMPlexSans-Medium.woff2` — body weight 500.
- `src/assets/fonts/IBMPlexSans-SemiBold.woff2` — body weight 600.
- `src/assets/fonts/IBMPlexMono-Regular.woff2` — utility weight 400.
- `src/assets/fonts/IBMPlexMono-Medium.woff2` — utility weight 500.
- `src/assets/fonts/OFL.txt` — upstream IBM Plex OFL-1.1 license text.
- `src/styles/fonts.css` — seven local `@font-face` declarations and no other styling.
- `src/scripts/smooth-scroll.ts` — one Lenis lifecycle, reduced-motion switching, and immediate skip-link behavior.

### Modify

- `package.json`, `package-lock.json` — exact `lenis@1.3.25` dependency only.
- `src/layouts/BaseLayout.astro` — route marker and one processed client entry.
- `src/styles/global.css` — approved tokens, type, square geometry, title card, varied section pacing, all component and responsive states.
- `src/content/en/shared.mjs` — homepage-only H1 exception.
- `src/components/PageIntro.astro` — explicit `home` and `standard` variants.
- `src/components/SiteHeader.astro` — explicit wordmark presentation hooks for the ruled shell; footer treatment remains CSS-only with unchanged content.
- `src/components/FailureModeCard.astro`, `ServiceCard.astro`, `FitMatrix.astro`, `DecisionLoop.astro`, `MeasurementLayer.astro`, `Notice.astro`, `OutcomeShift.astro` — remove card/badge defaults and expose editorial row semantics.
- `src/components/ProcessRail.astro`, `SectionHeading.astro`, `EvidenceReserved.astro`, `FAQList.astro`, `PrimaryCTA.astro` — preserve semantics while aligning class contracts.
- `src/pages/index.astro` — home title-card variant, method synopsis instead of a duplicate full process rail, and purposeful section modifiers.
- `src/pages/system.astro`, `services.astro`, `fit.astro`, `results.astro`, `about.astro`, `apply.astro` — standard intro and route-specific section pacing.
- `scripts/validate-build.mjs` — permit only local processed module scripts while preserving the 25KB compressed JS ceiling.
- `scripts/verify-browser.mjs` — visual tokens, font loading, Lenis lifecycle, anchors, keyboard, no-JS, and reduced-motion verification.
- `tests/browser-contracts.test.mjs`, `tests/build.test.mjs`, `tests/validators.test.mjs`, `tests/content.test.mjs` — source and generated-output contracts for the approved exception.
- `README.md` — authoritative addendum/plan and redesigned private-review gate.
- `docs/verification/2026-07-18-visual-redesign-and-smooth-scroll-verification.md` — exact verification evidence and limitations.
- `docs/verification/screenshots/*.png` — replace all five representative screenshots with the approved implementation at the same named viewports.

### Deliberately unchanged

- All page-specific content modules other than `shared.mjs`.
- `astro.config.mjs`, `tsconfig.json`, `public/robots.txt`, claims/source/blocker registers, and production validator.
- Route count, URL structure, CTA destination, apply-page non-submission boundary, and all evidence markers.

## Task 1: Pin the approved font and color foundation

**Files:**
- Create: `src/assets/fonts/*.woff2`
- Create: `src/assets/fonts/OFL.txt`
- Create: `src/styles/fonts.css`
- Modify: `src/styles/global.css`
- Modify: `tests/browser-contracts.test.mjs`

- [ ] **Step 1: Replace the old visual-token test with a failing approved-foundation test**

In `tests/browser-contracts.test.mjs`, replace the first test and add the helpers below. This reads both CSS sources and checks the committed font files rather than relying on browser fallback behavior.

```js
const fontDirectory = resolve(root, 'src/assets/fonts');
const fontFiles = [
  'IBMPlexSansCondensed-Medium.woff2',
  'IBMPlexSansCondensed-SemiBold.woff2',
  'IBMPlexSans-Regular.woff2',
  'IBMPlexSans-Medium.woff2',
  'IBMPlexSans-SemiBold.woff2',
  'IBMPlexMono-Regular.woff2',
  'IBMPlexMono-Medium.woff2',
];

function visualCss() {
  return [source('src/styles/fonts.css'), source('src/styles/global.css')].join('\n');
}

test('the approved cool-paper visual foundation and local Plex files are explicit', () => {
  const css = visualCss();
  for (const token of ['#f7f7f5', '#ffffff', '#0b0b0b', '#525252', '#184ae8', '#a9a9a9', '#d5d5d5']) {
    assert.match(css, new RegExp(token, 'i'), `missing approved token ${token}`);
  }
  for (const rejected of ['#f6f2ea', '#fffdfc', '#122033', '#236b6a', '#ddebe7', '#a84f16', '#f4e1d2']) {
    assert.doesNotMatch(css, new RegExp(rejected, 'i'), `rejected token remains: ${rejected}`);
  }
  assert.match(css, /font-family:\s*"IBM Plex Sans Condensed"/);
  assert.match(css, /font-family:\s*"IBM Plex Sans"/);
  assert.match(css, /font-family:\s*"IBM Plex Mono"/);
  assert.match(css, /font-display:\s*swap/);
  assert.doesNotMatch(css, /fonts\.googleapis|https?:\/\//i);
  for (const file of fontFiles) assert.ok(existsSync(resolve(fontDirectory, file)), `missing local font ${file}`);
  assert.ok(existsSync(resolve(fontDirectory, 'OFL.txt')), 'missing IBM Plex license');
});
```

- [ ] **Step 2: Run the focused test and verify RED**

Run: `node --test --test-name-pattern="approved cool-paper" tests/browser-contracts.test.mjs`

Expected: FAIL because `src/styles/fonts.css` and the seven WOFF2 files do not exist.

- [ ] **Step 3: Fetch only the seven approved IBM Plex files from the official 1.1.0 packages**

Use temporary package archives so the font packages never become project dependencies:

```bash
mkdir -p /tmp/yos-plex-fonts src/assets/fonts
npm pack @ibm/plex-sans@1.1.0 --pack-destination /tmp/yos-plex-fonts
npm pack @ibm/plex-sans-condensed@1.1.0 --pack-destination /tmp/yos-plex-fonts
npm pack @ibm/plex-mono@1.1.0 --pack-destination /tmp/yos-plex-fonts
tar -xzf /tmp/yos-plex-fonts/ibm-plex-sans-1.1.0.tgz -C /tmp/yos-plex-fonts
cp /tmp/yos-plex-fonts/package/fonts/complete/woff2/IBMPlexSans-Regular.woff2 src/assets/fonts/
cp /tmp/yos-plex-fonts/package/fonts/complete/woff2/IBMPlexSans-Medium.woff2 src/assets/fonts/
cp /tmp/yos-plex-fonts/package/fonts/complete/woff2/IBMPlexSans-SemiBold.woff2 src/assets/fonts/
cp /tmp/yos-plex-fonts/package/LICENSE.txt src/assets/fonts/OFL.txt
```

Extract the Condensed and Mono archives into separate temporary directories before copying their files, because all three archives use a top-level `package/` directory:

```bash
mkdir -p /tmp/yos-plex-fonts/condensed /tmp/yos-plex-fonts/mono
tar -xzf /tmp/yos-plex-fonts/ibm-plex-sans-condensed-1.1.0.tgz -C /tmp/yos-plex-fonts/condensed
tar -xzf /tmp/yos-plex-fonts/ibm-plex-mono-1.1.0.tgz -C /tmp/yos-plex-fonts/mono
cp /tmp/yos-plex-fonts/condensed/package/fonts/complete/woff2/IBMPlexSansCondensed-Medium.woff2 src/assets/fonts/
cp /tmp/yos-plex-fonts/condensed/package/fonts/complete/woff2/IBMPlexSansCondensed-SemiBold.woff2 src/assets/fonts/
cp /tmp/yos-plex-fonts/mono/package/fonts/complete/woff2/IBMPlexMono-Regular.woff2 src/assets/fonts/
cp /tmp/yos-plex-fonts/mono/package/fonts/complete/woff2/IBMPlexMono-Medium.woff2 src/assets/fonts/
```

Run: `find src/assets/fonts -maxdepth 1 -type f -print | sort`

Expected: exactly seven WOFF2 files plus `OFL.txt`; no italic, serif, OTF, TTF, or extra weight.

- [ ] **Step 4: Create the complete local font layer**

Create `src/styles/fonts.css` with exactly these faces:

```css
@font-face {
  font-family: "IBM Plex Sans Condensed";
  src: url("../assets/fonts/IBMPlexSansCondensed-Medium.woff2") format("woff2");
  font-display: swap;
  font-style: normal;
  font-weight: 500;
}

@font-face {
  font-family: "IBM Plex Sans Condensed";
  src: url("../assets/fonts/IBMPlexSansCondensed-SemiBold.woff2") format("woff2");
  font-display: swap;
  font-style: normal;
  font-weight: 600;
}

@font-face {
  font-family: "IBM Plex Sans";
  src: url("../assets/fonts/IBMPlexSans-Regular.woff2") format("woff2");
  font-display: swap;
  font-style: normal;
  font-weight: 400;
}

@font-face {
  font-family: "IBM Plex Sans";
  src: url("../assets/fonts/IBMPlexSans-Medium.woff2") format("woff2");
  font-display: swap;
  font-style: normal;
  font-weight: 500;
}

@font-face {
  font-family: "IBM Plex Sans";
  src: url("../assets/fonts/IBMPlexSans-SemiBold.woff2") format("woff2");
  font-display: swap;
  font-style: normal;
  font-weight: 600;
}

@font-face {
  font-family: "IBM Plex Mono";
  src: url("../assets/fonts/IBMPlexMono-Regular.woff2") format("woff2");
  font-display: swap;
  font-style: normal;
  font-weight: 400;
}

@font-face {
  font-family: "IBM Plex Mono";
  src: url("../assets/fonts/IBMPlexMono-Medium.woff2") format("woff2");
  font-display: swap;
  font-style: normal;
  font-weight: 500;
}
```

- [ ] **Step 5: Replace the global token and primary typography blocks**

Put `@import "./fonts.css" layer(fonts);` before the existing layer declaration, add `fonts` as the first layer, and replace the `:root`, body, and heading font roles with this exact foundation:

```css
@import "./fonts.css" layer(fonts);

@layer fonts, reset, base, layout, components, utilities;

:root {
  color-scheme: light;
  --paper: #f7f7f5;
  --white: #ffffff;
  --ink: #0b0b0b;
  --muted-ink: #525252;
  --cobalt: #184ae8;
  --rule: #a9a9a9;
  --quiet-rule: #d5d5d5;
  --dark-secondary: #c7c7c7;
  --dark-rule: #555555;
  --focus: #0b0b0b;
  --focus-on-dark: #ffffff;
  --canvas: var(--paper);
  --surface: var(--white);
  --display: "IBM Plex Sans Condensed", "Arial Narrow", sans-serif;
  --body: "IBM Plex Sans", Arial, sans-serif;
  --utility: "IBM Plex Mono", ui-monospace, monospace;
  --container: 90rem;
  --measure: 66ch;
  --space-1: 0.25rem;
  --space-2: 0.5rem;
  --space-3: 0.75rem;
  --space-4: 1rem;
  --space-6: 1.5rem;
  --space-8: 2rem;
  --space-12: 3rem;
  --space-16: 4rem;
  --space-24: 6rem;
  --space-32: 8rem;
}

body {
  min-height: 100vh;
  background: var(--paper);
  color: var(--ink);
  font-family: var(--body);
  font-size: clamp(1rem, 0.3vw + 0.95rem, 1.125rem);
  font-weight: 400;
  line-height: 1.62;
  text-rendering: optimizeLegibility;
}

h1,
h2,
h3 {
  color: inherit;
  font-family: var(--display);
  font-weight: 500;
  line-height: 0.98;
  overflow-wrap: anywhere;
  text-wrap: balance;
}
```

Apply this exact mechanical mapping throughout the remaining stylesheet: `var(--system-teal)` → `var(--cobalt)`, `var(--teal-wash)` → `var(--white)`, `var(--signal-amber)` → `var(--cobalt)`, `var(--amber-wash)` → `var(--paper)`, and `var(--focus-dark)` → `var(--focus-on-dark)`. Do not leave aliases named `--system-teal`, `--teal-wash`, `--signal-amber`, or `--amber-wash`; the test must prove the old palette is gone.

- [ ] **Step 6: Run the focused and baseline tests**

Run: `node --test tests/browser-contracts.test.mjs`

Expected: PASS for the approved foundation and existing semantic contracts.

Run: `npm run check`

Expected: PASS with no missing asset or CSS parse error.

- [ ] **Step 7: Commit the font and token foundation**

```bash
git add src/assets/fonts src/styles/fonts.css src/styles/global.css tests/browser-contracts.test.mjs
git commit -m "style: establish anti-default visual foundation"
```

## Task 2: Add bounded Lenis progressive enhancement

**Files:**
- Create: `src/scripts/smooth-scroll.ts`
- Modify: `package.json`
- Modify: `package-lock.json`
- Modify: `src/layouts/BaseLayout.astro`
- Modify: `scripts/validate-build.mjs`
- Modify: `tests/build.test.mjs`
- Modify: `tests/validators.test.mjs`
- Modify: `tests/browser-contracts.test.mjs`

- [ ] **Step 1: Write failing source and generated-build contracts**

Add this source contract to `tests/browser-contracts.test.mjs`:

```js
test('the smooth-scroll module is restrained and honors native fallbacks', () => {
  const script = source('src/scripts/smooth-scroll.ts');
  for (const contract of [
    /autoRaf:\s*true/,
    /anchors:\s*true/,
    /smoothWheel:\s*true/,
    /syncTouch:\s*false/,
    /lerp:\s*0\.12/,
    /wheelMultiplier:\s*0\.9/,
    /stopInertiaOnNavigate:\s*true/,
    /prefers-reduced-motion:\s*reduce/,
    /\.destroy\(\)/,
    /#main-content/,
    /focus\(\{\s*preventScroll:\s*true\s*\}\)/,
  ]) assert.match(script, contract);
  assert.doesNotMatch(script, /syncTouch:\s*true|ScrollTrigger|gsap|scroll-snap|infinite:\s*true/i);
});
```

In `tests/build.test.mjs`, replace `the visitor build contains no client JavaScript` with:

```js
test('every route loads only the local processed smooth-scroll module', () => {
  for (const route of routes) {
    const html = htmlFor(route);
    const scripts = matches(html, /<script\b([^>]*)>([\s\S]*?)<\/script>/gi);
    assert.equal(scripts.length, 1, `${route.href} needs one processed module entry`);
    assert.match(scripts[0][1], /type="module"/i);
    assert.match(scripts[0][1], /src="\/_astro\/[^"]+\.js"/i);
    assert.doesNotMatch(scripts[0][1], /https?:\/\//i);
    assert.equal(scripts[0][2].trim(), '', `${route.href} must not contain inline visitor code`);
  }
});
```

Add two fixtures to `tests/validators.test.mjs`:

```js
test('rendered HTML guard rejects inline and remote visitor scripts', () => {
  const inline = '<script type="module">alert(1)</script>';
  const remote = '<script type="module" src="https://tracker.example/app.js"></script>';
  assert.ok(inspectHtml(`<html><body>${inline}</body></html>`, '/').some((error) => error.includes('unsafe script')));
  assert.ok(inspectHtml(`<html><body>${remote}</body></html>`, '/').some((error) => error.includes('unsafe script')));
});

test('rendered HTML guard permits a local generated module entry', () => {
  const local = '<script type="module" src="/_astro/smooth-scroll.abc123.js"></script>';
  assert.ok(!inspectHtml(`<html><body>${local}</body></html>`, '/').some((error) => error.includes('unsafe script')));
});
```

- [ ] **Step 2: Run the focused tests and verify RED**

Run: `node --test tests/browser-contracts.test.mjs tests/validators.test.mjs`

Expected: FAIL because the smooth-scroll source is absent and `inspectHtml()` still rejects every script.

- [ ] **Step 3: Install the one approved runtime dependency exactly**

Run: `npm install --save-exact lenis@1.3.25`

Expected: `package.json` contains `"lenis": "1.3.25"`; the lockfile records the exact package; `npm ls lenis` reports `lenis@1.3.25` and no peer error.

- [ ] **Step 4: Create the complete scroll lifecycle module**

Create `src/scripts/smooth-scroll.ts`:

```ts
import Lenis from 'lenis';
import 'lenis/dist/lenis.css';

const root = document.documentElement;
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const skipLink = document.querySelector<HTMLAnchorElement>('.skip-link');
const main = document.querySelector<HTMLElement>('#main-content');

let lenis: Lenis | null = null;
let listenersBound = false;

function start(): void {
  if (reducedMotion.matches || lenis) {
    root.dataset.scrollMode = 'native';
    return;
  }

  lenis = new Lenis({
    autoRaf: true,
    anchors: true,
    smoothWheel: true,
    syncTouch: false,
    lerp: 0.12,
    wheelMultiplier: 0.9,
    stopInertiaOnNavigate: true,
  });
  root.dataset.scrollMode = 'lenis';
}

function stop(): void {
  lenis?.destroy();
  lenis = null;
  root.dataset.scrollMode = 'native';
}

function handleMotionChange(): void {
  if (reducedMotion.matches) stop();
  else start();
}

function handleSkipLink(event: MouseEvent): void {
  if (!main) return;
  event.preventDefault();
  if (lenis) lenis.scrollTo(main, { immediate: true, force: true });
  else main.scrollIntoView({ behavior: 'auto', block: 'start' });
  main.focus({ preventScroll: true });
  if (window.location.hash !== '#main-content') {
    window.history.pushState(null, '', '#main-content');
  }
}

function bind(): void {
  if (listenersBound) return;
  reducedMotion.addEventListener('change', handleMotionChange);
  skipLink?.addEventListener('click', handleSkipLink);
  listenersBound = true;
}

function unbind(): void {
  if (!listenersBound) return;
  reducedMotion.removeEventListener('change', handleMotionChange);
  skipLink?.removeEventListener('click', handleSkipLink);
  listenersBound = false;
}

function mount(): void {
  bind();
  start();
}

function unmount(): void {
  stop();
  unbind();
}

window.addEventListener('pagehide', unmount);
window.addEventListener('pageshow', (event: PageTransitionEvent) => {
  if (event.persisted) mount();
});
mount();
```

- [ ] **Step 5: Load the processed module once from the shared layout**

Add `data-page={page.id}` to `<body>` and add this processed script immediately before `</body>` in `BaseLayout.astro`:

```astro
    <script>
      import '../scripts/smooth-scroll';
    </script>
```

Do not import the module in frontmatter, which would execute in the build environment instead of the browser.

- [ ] **Step 6: Narrow the build validator from zero-JS to safe-local-JS**

Replace the unconditional `<script>` rejection in `inspectHtml()` with this exact helper and call:

```js
function inspectScripts(html, route) {
  const errors = [];
  for (const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
    const attributes = match[1];
    const body = match[2].trim();
    const src = attributes.match(/\bsrc="([^"]+)"/i)?.[1];
    const isModule = /\btype="module"/i.test(attributes);
    const isLocalBuildAsset = /^\/_astro\/[a-z0-9._-]+\.js$/i.test(src ?? '');
    if (!isModule || !isLocalBuildAsset || body) {
      errors.push(`${route}: unsafe script; only an empty local generated module entry is allowed.`);
    }
  }
  return errors;
}
```

Inside the existing exported `inspectHtml(html, route)`, add `errors.push(...inspectScripts(html, route));` immediately after `const errors = [];` and remove only the old unconditional script rejection. Retain every existing landmark, metadata, external-request, form, blocker, image, and claim check verbatim.

At directory level, retain the 25KB gzip ceiling, remove the zero-file requirement, and add:

```js
if (jsFiles.length === 0) errors.push('Expected the approved smooth-scroll JavaScript asset; found none.');
if (jsFiles.length > 3) errors.push(`Unexpected JavaScript chunk count: ${jsFiles.length}.`);
```

The existing external URL scan and secret scan remain unchanged.

- [ ] **Step 7: Run RED-to-GREEN verification**

Run: `npm run check`

Expected: PASS.

Run: `npm test`

Expected: the source and validator tests PASS; `tests/build.test.mjs` may still read the previous `dist` and is expected to fail until the next build.

Run: `npm run build`

Expected: PASS and emit one local module entry plus local JS/CSS/font assets.

Run: `npm test`

Expected: PASS after the refreshed build.

Run: `npm run validate:build`

Expected: PASS with JavaScript below 25KB gzip and no external request-bearing URL.

- [ ] **Step 8: Commit the bounded scroll enhancement**

```bash
git add package.json package-lock.json src/scripts/smooth-scroll.ts src/layouts/BaseLayout.astro scripts/validate-build.mjs tests/build.test.mjs tests/validators.test.mjs tests/browser-contracts.test.mjs
git commit -m "feat: add accessible Lenis smooth scrolling"
```

## Task 3: Build the title-card shell and explicit page-intro variants

**Files:**
- Modify: `src/content/en/shared.mjs`
- Modify: `src/components/PageIntro.astro`
- Modify: `src/components/SiteHeader.astro`
- Modify: `src/pages/index.astro`
- Modify: `src/styles/global.css`
- Modify: `tests/content.test.mjs`
- Modify: `tests/browser-contracts.test.mjs`

- [ ] **Step 1: Add failing copy and structural contracts**

In `tests/content.test.mjs`, add this assertion to the shared-content test while preserving the broader proposition assertion:

```js
assert.equal(pages[0].heading, 'We build the YouTube function inside your business.');
assert.equal(site.proposition, 'We build and operate the YouTube function inside your business.');
```

Add to `tests/browser-contracts.test.mjs`:

```js
test('home owns the sole title-card variant and inner pages use the standard intro', () => {
  const intro = source('src/components/PageIntro.astro');
  const home = source('src/pages/index.astro');
  assert.match(intro, /variant\?:\s*'home'\s*\|\s*'standard'/);
  assert.match(intro, /page-intro--home/);
  assert.match(intro, /Method, not software/);
  assert.match(intro, /Private review/);
  assert.match(home, /variant="home"/);
  for (const route of ['system', 'services', 'fit', 'results', 'about', 'apply']) {
    assert.doesNotMatch(source(`src/pages/${route}.astro`), /variant="home"/);
  }
});
```

- [ ] **Step 2: Run focused tests and verify RED**

Run: `node --test tests/content.test.mjs tests/browser-contracts.test.mjs`

Expected: FAIL on the old home heading and missing `variant` contract.

- [ ] **Step 3: Make the homepage heading exception explicit**

In the home page record in `src/content/en/shared.mjs`, replace `heading: site.proposition` with:

```js
heading: 'We build the YouTube function inside your business.',
```

Do not change `site.proposition`, the footer statement, or the proposition test.

- [ ] **Step 4: Replace PageIntro with explicit semantic variants**

Keep the existing prop fields and add `variant?: 'home' | 'standard'`. The rendered branch must use this structure:

```astro
---
import PrimaryCTA from './PrimaryCTA.astro';

interface Props {
  eyebrow: string;
  heading: string;
  summary: string;
  variant?: 'home' | 'standard';
  showCta?: boolean;
  ctaSupport?: string;
  secondaryHref?: string;
  secondaryLabel?: string;
  fitLine?: string;
}

const {
  eyebrow,
  heading,
  summary,
  variant = 'standard',
  showCta = false,
  ctaSupport,
  secondaryHref,
  secondaryLabel,
  fitLine,
} = Astro.props;

const actions = showCta || (secondaryHref && secondaryLabel);
---

<section class:list={['page-intro', `page-intro--${variant}`]} aria-labelledby="page-heading">
  {variant === 'home' ? (
    <div class="title-card">
      <div class="title-card__meta" aria-label="Page context">
        <span>Method, not software</span>
        <span>Private review</span>
      </div>
      <div class="title-card__marker" aria-hidden="true"></div>
      <div class="title-card__copy">
        <p class="eyebrow">{eyebrow}</p>
        <h1 id="page-heading">{heading}</h1>
        <div class="title-card__caption">
          <p class="page-intro__summary">{summary}</p>
          {fitLine && <p class="fit-line">{fitLine}</p>}
        </div>
        {actions && (
          <div class="page-intro__actions">
            {showCta && <PrimaryCTA supportingText={ctaSupport} compact />}
            {secondaryHref && secondaryLabel && <a class="text-link text-link--on-dark" href={secondaryHref}>{secondaryLabel}</a>}
          </div>
        )}
      </div>
    </div>
  ) : (
    <div class="page-intro__copy">
      <p class="eyebrow">{eyebrow}</p>
      <h1 id="page-heading">{heading}</h1>
      <p class="page-intro__summary">{summary}</p>
      {actions && (
        <div class="page-intro__actions">
          {showCta && <PrimaryCTA supportingText={ctaSupport} compact />}
          {secondaryHref && secondaryLabel && <a class="text-link text-link--strong" href={secondaryHref}>{secondaryLabel}</a>}
        </div>
      )}
      {fitLine && <p class="fit-line">{fitLine}</p>}
    </div>
  )}
</section>
```

- [ ] **Step 5: Mark Home as the only title-card route**

Add `variant="home"` to the existing home `PageIntro` call. Leave every inner route on the default `standard` variant.

In `SiteHeader.astro`, give the existing wordmark spans explicit presentation hooks without changing their content:

```astro
<span class="wordmark__name">{site.identity.reviewLabel}</span>
<small class="wordmark__state">Private review</small>
```

- [ ] **Step 6: Apply the shell and title-card CSS contract**

Replace the current header, page-intro index, and intro rules with selectors that implement this exact geometry:

```css
.site-header {
  position: relative;
  z-index: 10;
  border-bottom: 1px solid var(--ink);
  background: color-mix(in srgb, var(--paper) 96%, transparent);
}

.site-header__inner {
  display: grid;
  min-height: 5rem;
  grid-template-columns: minmax(13rem, 1fr) auto;
  align-items: stretch;
  margin-inline: auto;
}

.wordmark {
  display: flex;
  min-width: 0;
  flex-direction: column;
  justify-content: center;
  padding: 1rem 1.25rem;
  color: var(--ink);
  font-family: var(--display);
  font-size: 1rem;
  font-weight: 600;
  line-height: 1;
  text-decoration: none;
  text-transform: uppercase;
}

.wordmark small,
.eyebrow,
.title-card__meta,
.item-index,
dt {
  font-family: var(--utility);
  font-size: 0.75rem;
  font-weight: 500;
  letter-spacing: 0.04em;
  line-height: 1.4;
  text-transform: uppercase;
}

.page-intro {
  width: min(100%, var(--container));
  margin-inline: auto;
}

.page-intro--standard {
  display: grid;
  min-height: min(42rem, 78vh);
  align-items: end;
  padding: clamp(5rem, 12vw, 10rem) clamp(1.25rem, 4.5vw, 4rem) clamp(3rem, 7vw, 6rem);
  border-bottom: 1px solid var(--ink);
}

.page-intro--standard .page-intro__copy {
  display: grid;
  max-width: 68rem;
  gap: 1.5rem;
}

.page-intro--standard h1 {
  max-width: 12ch;
  font-size: clamp(3rem, 7vw, 6.5rem);
  font-weight: 600;
}

.page-intro--home {
  padding: clamp(1rem, 2.5vw, 2.25rem);
}

.title-card {
  position: relative;
  display: grid;
  min-height: clamp(34rem, 64vw, 52rem);
  overflow: clip;
  padding: clamp(1.25rem, 3vw, 2.5rem);
  background: var(--ink);
  color: var(--white);
}

.title-card__meta {
  display: flex;
  align-self: start;
  justify-content: space-between;
  gap: 1rem;
  color: #a8a8a8;
}

.title-card__marker {
  position: absolute;
  top: 0;
  right: 9%;
  width: 1px;
  height: 100%;
  background: #333333;
}

.title-card__marker::after {
  position: absolute;
  top: 42%;
  left: -5px;
  width: 11px;
  height: 11px;
  background: var(--cobalt);
  content: "";
}

.title-card__copy {
  position: relative;
  z-index: 1;
  display: grid;
  align-self: end;
  gap: 1.5rem;
  max-width: 75rem;
}

.title-card h1 {
  max-width: 11ch;
  font-size: clamp(3rem, 8vw, 7.5rem);
  font-weight: 600;
  line-height: 0.9;
  text-transform: uppercase;
}

.title-card__caption {
  display: grid;
  gap: 1rem;
  padding-top: 1rem;
  border-top: 1px solid var(--dark-rule);
}

.title-card .page-intro__summary,
.title-card .fit-line,
.title-card .primary-cta-support {
  color: var(--dark-secondary);
}
```

At 72rem and wider, use these exact three-zone rules; at narrower widths retain the native `<details>` menu and its 44px targets:

```css
@media (min-width: 72rem) {
  .site-header__inner {
    grid-template-columns: minmax(16rem, 1fr) minmax(0, 2fr) auto;
  }

  .wordmark {
    border-right: 1px solid var(--ink);
    padding-inline: 2rem;
  }

  .desktop-nav {
    display: contents;
  }

  .desktop-nav ul {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 0.25rem;
    padding-inline: 1.5rem;
    list-style: none;
  }

  .desktop-nav ul a {
    display: inline-flex;
    min-height: 44px;
    align-items: center;
    padding: 0.5rem 0.65rem;
    color: var(--ink);
    font-size: 0.8125rem;
    font-weight: 500;
    text-decoration: none;
  }

  .button--header {
    display: flex;
    min-height: 5rem;
    align-items: center;
    padding-inline: 1.5rem;
    border: 0;
    border-left: 1px solid var(--ink);
    background: var(--cobalt);
    color: var(--white);
  }
}
```

Remove the old `.page-intro__index` rules and do not replace them with decorative BUSINESS/AUDIENCE/CONTENT/LEARNING boxes.

- [ ] **Step 7: Run focused tests, build, and visual smoke**

Run: `node --test tests/content.test.mjs tests/browser-contracts.test.mjs`

Expected: PASS.

Run: `npm run check && npm run build && npm run validate:build`

Expected: PASS.

Start local review and inspect Home at 1440px and 320px. Expected: one black semantic title card, no clipped H1, no horizontal overflow, and a standard white/paper introduction on every inner route.

- [ ] **Step 8: Commit the shell**

```bash
git add src/content/en/shared.mjs src/components/PageIntro.astro src/components/SiteHeader.astro src/pages/index.astro src/styles/global.css tests/content.test.mjs tests/browser-contracts.test.mjs
git commit -m "style: add title-card editorial shell"
```

## Task 4: Convert repeated cards into editorial rows and relationships

**Files:**
- Modify: `src/components/FailureModeCard.astro`
- Modify: `src/components/ServiceCard.astro`
- Modify: `src/components/FitMatrix.astro`
- Modify: `src/components/DecisionLoop.astro`
- Modify: `src/components/MeasurementLayer.astro`
- Modify: `src/components/Notice.astro`
- Modify: `src/components/OutcomeShift.astro`
- Modify: `src/styles/global.css`
- Modify: `src/pages/index.astro`
- Modify: `src/pages/services.astro`
- Modify: `tests/browser-contracts.test.mjs`

- [ ] **Step 1: Write the failing anti-card component contract**

Add:

```js
test('presentational components use content-bearing rows rather than decorative card indices', () => {
  const failure = source('src/components/FailureModeCard.astro');
  const service = source('src/components/ServiceCard.astro');
  const decision = source('src/components/DecisionLoop.astro');
  const measurement = source('src/components/MeasurementLayer.astro');
  assert.doesNotMatch(failure, /item-index/);
  assert.doesNotMatch(service, /item-index/);
  assert.match(service, /service-row__action/);
  assert.match(decision, /<ol class="decision-loop__list">/);
  assert.doesNotMatch(decision, /item-index/);
  assert.match(measurement, /Layer \{index \+ 1\}/);
  assert.match(source('src/components/FitMatrix.astro'), />Strong fit<|>Poor fit</);
});
```

Run: `node --test --test-name-pattern="presentational components" tests/browser-contracts.test.mjs`

Expected: FAIL on the existing decorative indices and missing service action class.

- [ ] **Step 2: Remove decorative numbering from failure, service, and decision markup**

For `FailureModeCard.astro`, remove the `index` prop and its `<p class="item-index">`; retain the article, H3, problem, and definition list.

For `ServiceCard.astro`, remove the `index` prop and render this final action after the definition list:

```astro
<a class="service-row__action" href="/apply/">
  <span>Request a strategy conversation</span><span aria-hidden="true">↗</span>
</a>
```

For `DecisionLoop.astro`, retain the semantic `<ol>` and remove the visual index paragraph. The ordered list itself carries the sequence.

Update every call site to stop passing the removed `index` props. Keep `MeasurementLayer`'s meaningful classification but change its label to:

```astro
<p class="item-index">Layer {index + 1}</p>
```

- [ ] **Step 3: Simplify fit and status symbols without losing text meaning**

In `FitMatrix.astro`, retain the explicit Strong fit/Poor fit headings and signal text. Replace check/cross glyphs with an em dash marked `aria-hidden="true"`; the heading and list text remain the actual meaning.

Keep `Notice`, `EvidenceReserved`, and FAQ native semantics unchanged. Styling may use rules and fields, but their internal/private labels must remain visible verbatim.

- [ ] **Step 4: Replace card-grid styling with these row contracts**

Use square geometry and no shadow. The central selectors must implement:

```css
.failure-grid {
  display: grid;
  grid-template-columns: repeat(12, minmax(0, 1fr));
  gap: clamp(2rem, 4vw, 5rem) 1.5rem;
}

.failure-mode {
  grid-column: span 5;
  min-width: 0;
  padding-top: 1rem;
  border-top: 1px solid var(--ink);
}

.failure-mode:nth-child(even) {
  grid-column: 7 / span 6;
  margin-top: clamp(2rem, 6vw, 6rem);
}

.service-grid {
  display: grid;
  border-top: 1px solid var(--ink);
}

.service-card {
  display: grid;
  min-width: 0;
  grid-template-columns: minmax(10rem, 0.75fr) minmax(0, 2fr) minmax(12rem, 0.8fr);
  gap: 2rem;
  padding: 1.5rem 0;
  border: 0;
  border-bottom: 1px solid var(--ink);
}

.service-card h3 {
  margin: 0;
}

.service-definition {
  display: grid;
  gap: 1rem;
  margin: 0;
}

.service-row__action {
  display: flex;
  min-height: 44px;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  align-self: start;
  color: var(--ink);
  font-family: var(--utility);
  font-size: 0.75rem;
  font-weight: 500;
  text-decoration-thickness: 1px;
  text-underline-offset: 0.3em;
  text-transform: uppercase;
}

.outcome-shift,
.comparison__row,
.measurement-layer,
.decision-loop__list li,
.fit-column,
.notice,
.evidence-reserved {
  border-radius: 0;
  box-shadow: none;
}

.decision-loop__list {
  display: grid;
  border-top: 1px solid currentColor;
  list-style-position: inside;
}

.decision-loop__list li {
  display: grid;
  gap: 0.75rem;
  padding: 1.5rem 0;
  border-bottom: 1px solid currentColor;
}

.fit-matrix {
  display: grid;
  border-top: 1px solid var(--ink);
}

.fit-column {
  padding: 2rem 0;
  border: 0;
  border-bottom: 1px solid var(--ink);
  background: transparent;
}
```

On viewports below 64rem, collapse `.failure-grid` and `.service-card` to one column, remove stagger margins, and preserve source order. Never restore rounded tags or card backgrounds.

- [ ] **Step 5: Run component tests and build checks**

Run: `node --test tests/browser-contracts.test.mjs`

Expected: PASS.

Run: `npm run check && npm run build && npm test && npm run validate:build`

Expected: PASS; all seven pages still render one H1 and claim-safe content.

- [ ] **Step 6: Commit the component conversion**

```bash
git add src/components/FailureModeCard.astro src/components/ServiceCard.astro src/components/FitMatrix.astro src/components/DecisionLoop.astro src/components/MeasurementLayer.astro src/components/Notice.astro src/components/OutcomeShift.astro src/styles/global.css src/pages/index.astro src/pages/services.astro tests/browser-contracts.test.mjs
git commit -m "style: replace generic cards with editorial rows"
```

## Task 5: Give all seven routes deliberate pacing

**Files:**
- Modify: `src/pages/index.astro`
- Modify: `src/pages/system.astro`
- Modify: `src/pages/services.astro`
- Modify: `src/pages/fit.astro`
- Modify: `src/pages/results.astro`
- Modify: `src/pages/about.astro`
- Modify: `src/pages/apply.astro`
- Modify: `src/styles/global.css`
- Modify: `tests/browser-contracts.test.mjs`

- [ ] **Step 1: Write a failing route-composition source contract**

Add:

```js
test('route pacing reserves sequence and cobalt emphasis for meaningful content', () => {
  const home = source('src/pages/index.astro');
  assert.doesNotMatch(home, /<ProcessRail/);
  assert.match(home, /class="method-synopsis"/);
  assert.match(home, /section--signal/);
  assert.match(source('src/pages/system.astro'), /<ProcessRail stages=\{methodStages\} detailed/);
  assert.match(source('src/pages/results.astro'), /section--signal/);
  assert.doesNotMatch(source('src/pages/services.astro'), /service-grid[^\n]*service-grid--compact/);
});
```

Run: `node --test --test-name-pattern="route pacing" tests/browser-contracts.test.mjs`

Expected: FAIL because Home still duplicates the full process rail and the signal modifiers are absent.

- [ ] **Step 2: Replace the duplicate Home process rail with a concise synopsis**

Remove the `ProcessRail` import and `methodStages` import from `src/pages/index.astro`. In the connected-loop section, replace the rail with:

```astro
<div class="method-synopsis">
  <p>Business goals guide audience research. Research sharpens positioning. Positioning organizes content. Publishing creates evidence. Evidence informs what changes next.</p>
  <a class="text-link text-link--strong" href="/system/">Examine every input and output</a>
</div>
```

The complete seven-stage ordered process remains only on `/system/`.

- [ ] **Step 3: Apply purposeful section modifiers without changing content order**

Keep each route's existing semantic section order. Make only these modifier substitutions:

- Home: operating gap `section--white`; connected-loop synopsis `section--paper`; outcome shifts `section--white`; engagement `section--ink`; fit `section--paper`; comparison `section--white`; evidence `section--review`; decision loop `section--signal`; FAQ `section--paper`.
- System: stages `section--white`; decision loop `section--signal`; responsibilities `section--paper section--split`; boundaries `section--ink`.
- Services: engagement rows `section--white`.
- Fit: fit thesis `section--white`; readiness `section--paper`; assessment `section--white`.
- Results: measurement `section--white`; decision format `section--signal`; evidence `section--review`; limitations `section--ink`.
- About: belief `section--white`; principles `section--paper`; origin `section--white`; roles `section--ink`.
- Apply: process `section--white`; preview `section--paper`; collection boundary `section--review`.

Remove every `section--teal` class. Keep `section--ink` only where a dark field carries a boundary or engagement meaning.

- [ ] **Step 4: Complete section, signal, and responsive CSS**

Use the following required foundations and tune only spacing during browser review:

```css
.section {
  width: min(100%, var(--container));
  margin-inline: auto;
  padding: clamp(4rem, 9vw, 9rem) clamp(1.25rem, 4.5vw, 4rem);
  border-top: 1px solid var(--ink);
}

.section--paper { background: var(--paper); }
.section--white { background: var(--white); }
.section--ink { background: var(--ink); color: var(--white); }
.section--signal { background: var(--cobalt); color: var(--white); }
.section--review { background: var(--white); }

.section--ink .section-introduction,
.section--ink .lede,
.section--signal .section-introduction,
.section--signal .diagram-equivalent,
.section--signal .decision-loop__list p {
  color: var(--dark-secondary);
}

.section-heading {
  display: grid;
  grid-template-columns: minmax(8rem, 0.55fr) minmax(0, 1.45fr);
  gap: clamp(2rem, 7vw, 7rem);
  margin-bottom: clamp(3rem, 7vw, 7rem);
}

.section-heading .eyebrow { color: var(--cobalt); }
.section--signal .section-heading .eyebrow,
.section--ink .section-heading .eyebrow { color: var(--white); }
.section-heading h2,
.section-heading .section-introduction { grid-column: 2; }
.section-heading h2 { font-size: clamp(2.25rem, 5vw, 4.5rem); }

.method-synopsis {
  display: grid;
  grid-template-columns: minmax(0, 1.5fr) auto;
  gap: 2rem;
  align-items: end;
}

.method-synopsis > p {
  max-width: 42ch;
  font-family: var(--display);
  font-size: clamp(1.8rem, 4vw, 3.25rem);
  font-weight: 500;
  line-height: 1.03;
}

@media (max-width: 63.999rem) {
  .section-heading,
  .method-synopsis,
  .service-card,
  .title-card__caption {
    grid-template-columns: 1fr;
  }

  .section-heading h2,
  .section-heading .section-introduction {
    grid-column: 1;
  }

  .failure-grid {
    grid-template-columns: 1fr;
  }

  .failure-mode,
  .failure-mode:nth-child(even) {
    grid-column: 1;
    margin-top: 0;
  }
}

@media (max-width: 37.499rem) {
  .page-intro--home { padding: 1rem; }
  .title-card { min-height: 38rem; padding: 1.25rem; }
  .title-card h1 { font-size: clamp(2.8rem, 14vw, 4.2rem); }
  .title-card__marker { right: 1.75rem; }
  .section { padding: 4rem 1.25rem; }
  .section-heading { gap: 1.5rem; margin-bottom: 3rem; }
  .service-card { gap: 1.25rem; }
}
```

Retain the existing 37.5rem, 64rem, and 72rem breakpoints where header/menu behavior depends on them. Remove old grid rules that would override the new one-column narrow behavior or recreate compact service-card grids.

- [ ] **Step 5: Run all static checks and inspect all routes at three widths**

Run: `npm run check && npm test && npm run validate:content && npm run build && npm run validate:build`

Expected: PASS.

Inspect every route at 320px, 768px, and 1440px. Expected: distinct pacing, readable measure, no repeated title card, no rounded card field, no old palette, no clipped labels, and no horizontal overflow.

- [ ] **Step 6: Commit route pacing**

```bash
git add src/pages/index.astro src/pages/system.astro src/pages/services.astro src/pages/fit.astro src/pages/results.astro src/pages/about.astro src/pages/apply.astro src/styles/global.css tests/browser-contracts.test.mjs
git commit -m "style: art-direct all seven site routes"
```

## Task 6: Expand browser verification for typography and scroll behavior

**Files:**
- Modify: `scripts/verify-browser.mjs`
- Modify: `tests/browser-contracts.test.mjs`

- [ ] **Step 1: Write the failing browser-harness source contract**

Extend the existing harness-coverage test with:

```js
for (const contract of [
  /document\.fonts\.ready/,
  /IBM Plex Sans Condensed/,
  /dataset\.scrollMode/,
  /mouse\.wheel/,
  /emulateMedia/,
  /#main-content/,
  /PageDown/,
  /goBack/,
]) assert.match(runner, contract);
```

Run: `node --test --test-name-pattern="browser runner" tests/browser-contracts.test.mjs`

Expected: FAIL because the current harness does not inspect fonts or the Lenis lifecycle.

- [ ] **Step 2: Add visual-foundation checks inside the existing route/viewport loop**

After `page.goto`, await `page.evaluate(() => document.fonts.ready)`. On Home at 1440px, collect and assert:

```js
const visualState = await page.evaluate(() => {
  const root = getComputedStyle(document.documentElement);
  const h1 = getComputedStyle(document.querySelector('h1'));
  const body = getComputedStyle(document.body);
  return {
    paper: root.getPropertyValue('--paper').trim(),
    ink: root.getPropertyValue('--ink').trim(),
    cobalt: root.getPropertyValue('--cobalt').trim(),
    h1Family: h1.fontFamily,
    bodyFamily: body.fontFamily,
    titleCards: document.querySelectorAll('.title-card').length,
    scrollMode: document.documentElement.dataset.scrollMode,
  };
});
```

Require `#f7f7f5`, `#0b0b0b`, `#184ae8`, Plex family names, one Home title card, zero title cards on inner routes, and `scrollMode === 'lenis'` in the ordinary context.

- [ ] **Step 3: Add a restrained wheel-behavior smoke test**

On Home at 1440px:

```js
await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
await page.mouse.move(720, 450);
await page.mouse.wheel(0, 900);
await page.waitForTimeout(180);
const wheelState = await page.evaluate(() => ({
  y: window.scrollY,
  mode: document.documentElement.dataset.scrollMode,
  lenisClass: document.documentElement.classList.contains('lenis'),
}));
if (wheelState.mode !== 'lenis' || !wheelState.lenisClass || wheelState.y <= 0) {
  errors.push(`Lenis wheel smoke failed: ${JSON.stringify(wheelState)}.`);
}
```

This verifies activation and movement without asserting frame timing, which would be flaky in headless CI.

- [ ] **Step 4: Expand keyboard, anchor, and history checks**

Keep the existing skip-link focus assertion and add:

```js
await page.locator('body').press('Home');
await page.keyboard.press('PageDown');
if ((await page.evaluate(() => window.scrollY)) <= 0) errors.push('PageDown did not scroll the document.');
await page.keyboard.press('Home');

await page.goto(`${baseUrl}/#main-content`, { waitUntil: 'networkidle' });
if ((await page.locator('#main-content').count()) !== 1) errors.push('Direct main-content fragment did not resolve.');

await page.goto(`${baseUrl}/system/`, { waitUntil: 'networkidle' });
await page.goBack({ waitUntil: 'networkidle' });
if (new URL(page.url()).pathname !== '/') errors.push('Back navigation did not return to Home.');
```

During the existing skip-link test, also require `location.hash === '#main-content'` after activation.

- [ ] **Step 5: Expand reduced-motion checks to initial and live preference changes**

In the reduced context, require no `html.lenis` class and `data-scroll-mode="native"`. Then use:

```js
await page.emulateMedia({ reducedMotion: 'reduce' });
await page.waitForTimeout(50);
const reducedLive = await page.evaluate(() => ({
  mode: document.documentElement.dataset.scrollMode,
  lenis: document.documentElement.classList.contains('lenis'),
}));
if (reducedLive.mode !== 'native' || reducedLive.lenis) errors.push('Live reduced-motion change did not destroy Lenis.');

await page.emulateMedia({ reducedMotion: 'no-preference' });
await page.waitForTimeout(50);
const restoredLive = await page.evaluate(() => document.documentElement.dataset.scrollMode);
if (restoredLive !== 'lenis') errors.push('Lenis did not restart after motion preference was restored.');
```

Run the live-change sequence in a normal context, not the context permanently configured with reduced motion.

- [ ] **Step 6: Run source tests and complete browser verification**

Run: `node --test tests/browser-contracts.test.mjs`

Expected: PASS.

Run: `npm run build && npm run verify:browser`

Expected: PASS for 35 route/viewport checks, 14 Axe scans, local fonts, one Home title card, zero third-party requests, keyboard/anchor/history behavior, Lenis normal mode, live reduced-motion switching, and no-JS content/navigation.

- [ ] **Step 7: Commit browser coverage**

```bash
git add scripts/verify-browser.mjs tests/browser-contracts.test.mjs
git commit -m "test: verify redesigned scroll experience"
```

## Task 7: Run the acceptance matrix and record evidence

**Files:**
- Create: `docs/verification/2026-07-18-visual-redesign-and-smooth-scroll-verification.md`
- Modify: `docs/verification/screenshots/home-desktop-1440.png`
- Modify: `docs/verification/screenshots/home-mobile-320.png`
- Modify: `docs/verification/screenshots/system-tablet-768.png`
- Modify: `docs/verification/screenshots/results-evidence-1024.png`
- Modify: `docs/verification/screenshots/apply-preview-375.png`
- Modify: `README.md`

- [ ] **Step 1: Run the complete deterministic verification chain**

Run each command separately and record its exact terminal result:

```bash
npm run check
npm test
npm run validate:content
npm run build
npm run validate:build
npm run verify:browser
npm audit --omit=dev
```

Expected: every command exits 0; build validation reports no more than 25KB compressed JavaScript, no more than 60KB compressed CSS, seven routes, and no remote asset. The audit reports zero known production-dependency vulnerabilities.

- [ ] **Step 2: Confirm the intentional production gate still fails closed**

Run: `npm run validate:production`

Expected: non-zero with the existing open launch blockers. Record this as an expected private-prototype boundary, not an implementation failure.

- [ ] **Step 3: Capture and visually inspect representative screenshots**

Start the built preview at `127.0.0.1:4321` and replace all five existing screenshot files at their named widths:

- Home at 1440×900;
- Home at 320×568;
- System at 768×1024;
- Results evidence section at 1024×768;
- Apply at 375×812.

Inspect the images directly. Reject the implementation if any screenshot shows the old cream/serif/terracotta palette, decorative card grids, clipped headings, accidental huge whitespace, fake UI chrome, title-card repetition on inner routes, horizontal overflow, or focus/annotation collisions.

- [ ] **Step 4: Perform manual interaction checks**

In local Chrome and available Safari/WebKit:

1. Use mouse wheel or trackpad on a long route; movement is smooth but not delayed or theatrical.
2. Use PageDown, PageUp, Home, End, Space, Shift+Space, and arrow keys.
3. Activate the skip link; focus moves immediately to main content.
4. Open and close the mobile navigation and FAQs by keyboard.
5. Enable Reduce Motion before load and during the session; scrolling becomes native immediately.
6. Use a touch/mobile emulation pass; touch movement remains native because `syncTouch` is false.
7. Navigate during wheel inertia and use Back/Forward; no residual motion or broken fragment remains.
8. Disable JavaScript; all content, navigation, skip link, and FAQ disclosures remain usable.

- [ ] **Step 5: Write the verification record with measured evidence**

The new verification document must include:

- commit under test;
- Node/npm versions;
- each command and exit status;
- actual compressed JS/CSS/transfer metrics from `validate:build`;
- browser route/viewport and Axe counts;
- font file count and confirmation of zero third-party requests;
- normal, initial reduced-motion, live preference change, no-JS, keyboard, anchor, history, and touch results;
- screenshot paths;
- the expected production-validator failure and open blocker boundary;
- any Safari limitation actually observed, clearly labeled rather than inferred.

- [ ] **Step 6: Update README authority and next gate**

Add the 2026-07-18 visual specification, this implementation plan, and the new verification record ahead of the older implementation record. State that the redesigned Lenis-enhanced site remains a local private prototype and that public launch, forms, evidence, identity, and deployment remain blocked.

- [ ] **Step 7: Commit only acceptance artifacts**

```bash
git add README.md docs/verification/2026-07-18-visual-redesign-and-smooth-scroll-verification.md docs/verification/screenshots/home-desktop-1440.png docs/verification/screenshots/home-mobile-320.png docs/verification/screenshots/system-tablet-768.png docs/verification/screenshots/results-evidence-1024.png docs/verification/screenshots/apply-preview-375.png
git commit -m "docs: record redesigned prototype verification"
```

## Task 8: Final ledger and owner handoff

**Files:** No additional files unless a verification defect requires a narrowly scoped fix.

- [ ] **Step 1: Verify the exact diff and repository ledger**

Run:

```bash
git diff HEAD~7 --check
git status --short
git log -8 --oneline
```

Expected: no whitespace error; only the pre-existing untracked `.superpowers/` directory remains; commits are separated into font foundation, scroll enhancement, shell, components, route pacing, browser verification, and evidence.

- [ ] **Step 2: Re-run the full acceptance command after the final commit**

Run: `npm run verify`

Expected: exit 0 with all source, build, content, budget, browser, accessibility, network, no-JS, and motion checks passing.

- [ ] **Step 3: Inspect the production bundle for prohibited design and network residue**

Run:

```bash
rg -n -i "#f6f2ea|#fffdfc|#122033|#236b6a|#ddebe7|#a84f16|#f4e1d2|fonts.googleapis.com" dist src/styles src/components src/pages src/layouts src/scripts
rg -n -i "https?://" dist src/styles src/components src/pages src/layouts src/scripts
```

Expected: no rejected color or remote runtime asset in `src` or `dist`; canonical metadata under `https://private-review.invalid/` is the only allowed HTTPS occurrence in generated HTML.

- [ ] **Step 4: Hand off the private prototype without expanding scope**

Report:

- the final implementation commit;
- verification result and measured JS/CSS budgets;
- local review command and URL;
- the five screenshot links;
- any observed browser limitation;
- confirmation that `.superpowers/` was not staged;
- confirmation that launch, deployment, data collection, evidence activation, and forms remain outside this gate.

Do not publish, deploy, push, or mark any launch blocker closed.
