# Launch Blockers

## How to use this register

A private, local review prototype may proceed while these items are open. A public production launch may not proceed while any **actual blocker** is open. Conditional blockers apply only if the associated feature or asset is added. Optional improvements do not block launch when the documented fallback is used.

Closing a blocker requires the named evidence, an owner, and a dated approval recorded in this file or a linked release record. A polished page is not closure evidence.

## Actual public-launch blockers

### LB-01 — Public identity and accountable contact

- **Open condition:** No approved public company name, responsible legal entity, domain, business contact route, footer identity, or inquiry owner is supplied.
- **Prototype default:** Use a controlled `[LB-01: approved public company name]` marker and text-only identity; do not invent addresses, emails, registrations, or social profiles.
- **Closure evidence:** approved public and legal names; domain ownership; monitored contact route; responsible inquiry owner; required footer disclosures; approval date.

### LB-02 — Current service scope and availability

- **Open condition:** The Project Bible proposes multiple engagement models but does not prove which are currently available, deliverable, or contractually supported.
- **Prototype default:** Present the five service families as provisional paths and omit prices, timelines, capacity, guarantees, and exact deliverable counts.
- **Closure evidence:** approved saleable offers; inclusions, exclusions, delivery ownership, capacity, prerequisites, commercial terms, and alignment with proposal/contract language.

### LB-03 — Results-page publication decision

- **Open condition:** No quantitative case evidence or permissions have passed the claims register, while the provisional architecture includes a Results page.
- **Prototype default:** Use the internal evidence-reserved state defined in the design specification.
- **Closure evidence:** either (a) approved evidence packages for every published result, or (b) explicit approval to launch the Results page as a claim-free measurement framework, or (c) explicit approval to omit the route and update navigation, sitemap, and links.

### LB-04 — Geography, privacy obligations, and required notices

- **Open condition:** Operating geography, target jurisdictions, legal entity, data-controller role, retention rules, and applicable privacy/marketing requirements are unknown.
- **Prototype default:** collect nothing and load no third parties.
- **Closure evidence:** documented jurisdictions; counsel or accountable business approval of privacy requirements; approved privacy notice and any required terms/disclosures; retention and deletion policy; data-subject request route.

### LB-05 — Production inquiry flow and data processor

- **Open condition:** No approved production form endpoint, email/CRM destination, scheduler policy, processor, field list, response SLA, or failure owner exists.
- **Prototype default:** Apply is a static, non-submitting preview; no personal data enters the site.
- **Closure evidence:** data-flow diagram; minimal approved fields; processor/vendor assessment and agreement where required; server-side validation rules; spam/rate-limit controls; retention/deletion behavior; response owner and service expectation; success and failure copy approval.

### LB-06 — Final factual, claims, and content approval

- **Open condition:** Company story, About content, service wording, evidence, contact details, legal statements, and all structured metadata have not received final factual review.
- **Prototype default:** use conservative method-led copy and structured blocker/claim markers; omit unverified biography and proof.
- **Closure evidence:** page-by-page copy approval; claims-register decisions updated; permissions retained; metadata and structured-data facts reviewed; all internal markers removed from the production output.

### LB-07 — Production hosting and security controls

- **Open condition:** No production host, domain configuration, release owner, security-header policy, deployment rollback path, or access-control record exists.
- **Prototype default:** local-only files; no deployment.
- **Closure evidence:** HTTPS; domain and hosting MFA; least-privilege access; secure headers verified on the live origin; no frontend secrets; dependency and vendor inventory; backup/rollback process; same-origin form policy or tightly scoped alternative; explicit frame/embed policy; vulnerability and secret scans appropriate to the selected stack.

### LB-08 — Release verification

- **Open condition:** The private prototype passes its local automated and visible checks, but a production candidate does not exist. Safari and assistive-technology review, live-origin security headers, final production metadata, any future form success/failure paths, and accountable acceptance remain unverified.
- **Prototype default:** Retain the dated private-prototype verification record without describing it as production or launch acceptance.
- **Closure evidence:** the complete verification matrix in the design specification passes on the production candidate; material failures are fixed or explicitly accepted by an accountable owner.

## Conditional blockers

### CB-01 — Logos, photography, video, testimonials, or client identifiers

This blocks launch only if such an asset is used. Required evidence: ownership or license, subject/client permission, approved crop/context, alt-text decision, and any testimonial or endorsement disclosure. The non-blocking fallback is a text-only identity with no client-identifying assets.

### CB-02 — Analytics, pixels, session recording, chat, maps, schedulers, or external media

This blocks launch only if a third party is added. Required evidence: necessity, vendor inventory, data-flow and privacy review, consent determination, accessibility/performance check, CSP update, retention settings, and processor terms. The non-blocking fallback is no vendor and no tracking.

### CB-03 — Cross-origin embeds or framed content

This blocks launch only if an embed is added. Required evidence: exact allowed origins, intentional iframe `sandbox` and `allow` values, restrictive CSP, no wildcard `postMessage` target or sender checks, fallback content, and a vendor security review. The non-blocking fallback is no embed.

## Optional improvements that do not block launch

| Optional item | Claim-safe, launch-safe fallback |
|---|---|
| Quantitative case studies | Publish the approved measurement framework or omit Results from navigation under LB-03 option (b) or (c). |
| Founder biography or portrait | Use approved company/methodology copy with a text-only identity; do not imply credentials or personal history. |
| Custom logo or brand system | Use the provisional typographic system after public name approval. |
| Public pricing | Use “engagement is scoped after fit and strategy review” without invented ranges. |
| Scheduler embed | Use the approved inquiry flow and arrange scheduling after review. |
| Analytics | Launch without nonessential tracking; use server logs only if approved and privacy-compliant. |
| CMS or blog | Keep version-controlled local content and the seven-page site. |
| Additional languages | Publish English only and preserve localization-ready content structure. |
| Custom web fonts, animation, video, or photography | Use system fonts, CSS-only static diagrams, and restrained surfaces. |
| CRM or revenue attribution | Use an approved manual handoff; do not claim technical integration. |

## Private-prototype readiness

The open launch blockers do not prevent the next approved private-prototype gate because its baseline is local, static, non-submitting, English-only, text-led, and free of external services. They do prevent calling that prototype launch-ready or publishing it as a production site.
