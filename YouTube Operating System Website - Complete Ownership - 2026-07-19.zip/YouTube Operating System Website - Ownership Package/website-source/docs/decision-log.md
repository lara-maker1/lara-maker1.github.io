# Decision Log

## Status definitions

- **Approved:** controls the current design and may change only through a recorded decision.
- **Provisional default:** controls private-prototype and planning work until reviewed; it must not be presented as an externally verified fact.
- **Deferred:** intentionally excluded from the current gate and reconsidered only when its trigger occurs.

## Decisions

### D-001 — Use a system-led website

- **Status:** Approved
- **Decision:** Present the company as the team that builds and operates a coordinated YouTube function inside a client business. The central story connects business goals, audience research, positioning, content architecture, production, publishing, analytics, and business decisions.
- **Rationale:** This distinguishes the offer from isolated editing or output-volume production and matches both supplied inputs.
- **Consequence:** Every page must reinforce the operating system as a service method and connect content work to business context.
- **Review trigger:** A material change to the commercial offer.

### D-002 — “YouTube Operating System” means methodology, not existing software

- **Status:** Approved
- **Decision:** Use the term only for the repeatable service method, roles, decisions, and learning loop. Do not imply a SaaS platform, dashboard, portal, AI product, automated integration, or client account exists.
- **Rationale:** The Project Bible mixes the current service idea with future software hypotheses.
- **Consequence:** Diagrams must look like process maps or editorial decision systems, not application screenshots.
- **Review trigger:** Verified software reaches production and a separate product-positioning gate is approved.

### D-003 — Publish English first

- **Status:** Approved
- **Decision:** The private prototype and first production version contain English only. Content organization, stable keys, and layout behavior should support later localization without publishing additional languages now.
- **Rationale:** English-first narrows copy review and avoids premature translation operations.
- **Consequence:** English renders at root URLs; source content is separated from templates and labeled with `en` internally.
- **Review trigger:** A funded, approved language rollout with translation ownership and QA.

### D-004 — Use a static-first, content-driven architecture

- **Status:** Approved
- **Decision:** Generate semantic static pages from local content files. Use no CMS, authentication, database, or client-side application shell initially. Ship JavaScript only for a demonstrated accessible interaction.
- **Rationale:** Seven mostly editorial pages do not require runtime application infrastructure.
- **Consequence:** Core navigation, reading, and CTAs must work without client JavaScript.
- **Review trigger:** Approved requirements introduce frequently updated multi-author content or authenticated functionality.

### D-005 — Use a text-based provisional identity

- **Status:** Provisional default
- **Decision:** Use `[LB-01: approved public company name]` in controlled prototype annotations and a neutral text wordmark treatment. Do not invent a logo, founder portrait, client logo, brand history, or trademark claim.
- **Rationale:** No approved identity or brand assets were supplied.
- **Consequence:** The visual system must be credible without photography or custom logo artwork.
- **Review trigger:** Approved identity and rights-cleared assets are supplied.

### D-006 — Collect no data in the private prototype

- **Status:** Approved
- **Decision:** The private prototype has no operational form, analytics, cookies, chat, map, scheduler, pixels, external font calls, or third-party embeds. The Apply page previews qualification questions as static content and explains that submission is unavailable in the prototype.
- **Rationale:** A review artifact does not need to collect personal data or create vendor exposure.
- **Consequence:** Production form architecture is specified but not implemented in the private prototype.
- **Review trigger:** Production data flow, privacy requirements, processor, and response owner are approved.

### D-007 — Require no additional discovery to build the private prototype

- **Status:** Approved
- **Decision:** Missing company name, founder biography, brand assets, cases, contact details, pricing, geography, and final tool choice do not pause private-prototype planning or build work. Use conservative defaults, structured launch-blocker markers, or omission.
- **Rationale:** The user explicitly approved proceeding without more questions.
- **Consequence:** The implementation-plan session must not reopen discovery unless a choice would materially change scope or create a public/legal commitment.
- **Review trigger:** Public-launch preparation or user-requested strategy change.

### D-008 — Use a seven-page information architecture

- **Status:** Provisional default
- **Decision:** Home, The System, Services, Who It Is For, Results, About, and Apply.
- **Rationale:** The architecture separates the category explanation, offer, qualification, evidence, and conversion path while keeping the site focused.
- **Consequence:** The Home page summarizes the full argument; interior pages add depth rather than repeat identical sections.
- **Review trigger:** Written-spec review or evidence availability makes a route misleading or redundant.

### D-009 — Use one primary CTA

- **Status:** Approved
- **Decision:** The primary CTA label is “Request a strategy conversation.” It routes to Apply. Secondary links may explain the system or fit but must not compete visually.
- **Rationale:** A single high-consideration next step matches the B2B audience and service.
- **Consequence:** No checkout, instant booking, newsletter detour, chat prompt, or multiple conversion funnels.
- **Review trigger:** The commercial intake path changes.

### D-010 — Use a serious editorial B2B visual system

- **Status:** Provisional default
- **Decision:** Warm off-white surfaces, deep ink typography, muted teal system relationships, and one restrained amber signal accent. Use typographic hierarchy, process rails, annotated stages, and decision loops.
- **Rationale:** The visual language should feel like a thoughtful operating model, not a creator agency or AI software launch.
- **Consequence:** Avoid YouTube red, neon gradients, generic production stock, vanity counters, floating social icons, fake dashboards, and decorative motion.
- **Review trigger:** Approved brand system or written-spec feedback.

### D-011 — Keep the Results experience claim-safe

- **Status:** Approved
- **Decision:** In the private prototype, show an explicitly internal evidence-reserved state. In production, show verified cases only after claims approval; otherwise publish the measurement framework and evidence standard without empty case cards.
- **Rationale:** The supplied numerical outcomes are not substantiated for public use.
- **Consequence:** Results cannot be a disguised testimonial or invented metrics page.
- **Review trigger:** Evidence packages and client permissions are approved.

### D-012 — Use Astro for the static private prototype

- **Status:** Approved
- **Decision:** Use Astro 7.1.1 configured for static output because it supports component reuse, content separation, zero-JavaScript visitor output, and later localization without requiring an application runtime. TypeScript is pinned to the newest release compatible with the selected Astro checking toolchain.
- **Rationale:** Plain HTML duplicates seven-page structure; a client-rendered framework is unnecessary; Astro best matches the current balance of maintainability and minimal runtime behavior.
- **Consequence:** The private prototype builds exactly seven static HTML routes with local CSS and no visitor JavaScript. A future replacement requires equivalent accessibility, claims, privacy, security, and performance acceptance criteria.
- **Review trigger:** Production hosting constraints, an approved multi-author publishing requirement, or maintainer preference supported by a migration plan.

### D-013 — Keep site content local and reviewable

- **Status:** Provisional default
- **Decision:** Store copy and structured items in version-controlled English content files with stable IDs. Keep page composition, reusable data, and claim status separate enough that wording can be audited without editing layout code.
- **Rationale:** Claims and placeholder governance are central, while a CMS is unnecessary initially.
- **Consequence:** Every proof item carries a claims-register ID in source content until publication approval.
- **Review trigger:** A CMS or multi-author workflow is approved.

### D-014 — Treat embeds and tracking as opt-in production changes

- **Status:** Approved
- **Decision:** The baseline production architecture includes neither embeds nor nonessential tracking. Any future vendor requires an inventory entry, privacy review, security policy update, performance assessment, exact origin restriction, and approval.
- **Rationale:** Third-party code expands data, security, accessibility, and performance risk.
- **Consequence:** No wildcard `postMessage` handling, permissive frame origins, or casual script additions.
- **Review trigger:** A specific vendor or measurement requirement is proposed.
