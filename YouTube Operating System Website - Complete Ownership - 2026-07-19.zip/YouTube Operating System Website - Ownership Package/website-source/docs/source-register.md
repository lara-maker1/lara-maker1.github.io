# Source Register

## Purpose and classification rule

This register records the two supplied primary inputs and prevents source language from becoming an unsupported public claim. “Confirmed from source material” means the statement appears in a supplied file; it does not mean the real-world claim has been independently verified.

Each extracted statement is classified as one of:

- **Confirmed from source material** — directly present in a supplied input and safe to use only within the stated limitation.
- **Supported but requiring evidence** — described in a supplied input but dependent on records, analytics, client permission, or other corroboration.
- **Provisional strategy** — a proposed audience, offer, message, architecture, or operating choice approved for prototype use.
- **Future hypothesis** — a possible future operating model or product capability, not a current-state representation.
- **Prohibited from public use until verified** — likely to mislead if published without evidence or approval.

## S-001 — Conversation transcript

- **Supplied file:** [`S-001-conversation-transcript.txt`](../../confidential-original-inputs/S-001-conversation-transcript.txt)
- **SHA-256:** `c11cb344852df8a81df056472974b6e92d168d37dd93061adf93ef26ace9bdaf`
- **Language:** primarily machine-translated English from a mixed conversational recording.
- **Received for this project:** 2026-07-17.
- **Source type:** founder/participant conversation; anecdotal first-party input.

### What it supports

- **Confirmed from source material:** the intended niche is YouTube for business rather than creator-only production.
- **Confirmed from source material:** the described approach includes competitor/channel research, audience-comment analysis, positioning, production coordination, packaging, and channel learning.
- **Confirmed from source material:** the speaker rejects an instant-results expectation and describes organic YouTube growth as requiring sustained investment.
- **Supported but requiring evidence:** experience operating 11 localized channels, reaching a 100,000-subscriber milestone, and a possible one-million-subscriber localized channel.
- **Supported but requiring evidence:** any client income, authority, pricing power, lead-quality, or niche-leadership outcome attributed to the work.
- **Provisional strategy:** serve established businesses whose buyers need education and trust before purchasing.

### Limitations

- The transcript contains interruptions, irrelevant side conversations, ambiguous speaker changes, mistranslations, and incomplete sentences.
- It provides no dates, channel URLs, client identities, analytics exports, contracts, financial records, screenshots, or permission records.
- “Million of subscribers” is ambiguous and cannot establish which channel, date, language, ownership, or operator responsibility is being described.
- The 10–30× income statement is presented as a proposed guarantee or generalized case claim without a defined baseline, timeframe, attribution method, sample, or evidence.
- Tool and team references do not establish present capacity, contractual authority, or a repeatable operating model.
- No public quantitative claim may rely on this transcript alone.

## S-002 — Project Bible

- **Supplied file:** [`S-002-project-bible.txt`](../../confidential-original-inputs/S-002-project-bible.txt)
- **SHA-256:** `6d18d6d6b5473552c93596b0c0536e14f8c57df9323c6e7c92dd02bcd3425f5a`
- **Title in source:** `PROJECT BIBLE — Система масштабируемого YouTube-продюсирования для бизнеса`.
- **Language:** Russian with English product and operations terminology.
- **Received for this project:** 2026-07-17.
- **Source type:** internal strategy and future-product concept document.

### What it supports

- **Confirmed from source material:** the strategic intent is a system-led service that connects business context, audience research, positioning, content architecture, production, publication, analytics, and decisions.
- **Confirmed from source material:** the desired tone is intellectual, clear, confident, and unlike a creator production studio.
- **Provisional strategy:** the audience, anti-audience, service families, methodology stages, measurement categories, and seven-page public-site architecture.
- **Provisional strategy:** static-first, claim-safe website messaging can focus on the operating method without presenting an application.
- **Future hypothesis:** managing approximately 120 channels, pod-based scaling, automated workflows, AI assistance, centralized operations, and a software platform.
- **Prohibited from public use until verified:** integrations, dashboards, portals, automation, AI modules, capacity systems, attribution systems, and platform capabilities as current features.

### Limitations

- The document intentionally spans a service company, internal operating system, client portal, AI/automation layer, and future SaaS product. Most of that scope is outside this website project.
- It contains planned entities, modules, workflows, metrics, and integrations, not evidence that these have been built or are currently delivered.
- It includes no external citations, customer permissions, implementation evidence, live URLs, product screenshots, analytics exports, or dated case records.
- The 120-channel figure is an architectural ambition, not a current operating result or public capacity claim.
- Service packaging, pricing, team composition, geography, data practices, and legal availability remain unconfirmed.
- The website may explain the methodology but must not inherit the Bible’s platform scope.

## Controlling interpretation

The supplied session brief narrows both sources to a standalone authority website. When the transcript, Project Bible, and design specification differ, apply these rules:

1. The site presents “YouTube Operating System” as a methodology.
2. Current service claims require current operational truth; performance claims require evidence and permission.
3. Future platform language stays internal and outside the website.
4. A conservative omission is preferable to an impressive but unsupported claim.
5. Every quantitative or client-specific statement must pass `docs/claims-register.md` before publication.
