import Lenis from 'lenis';
import 'lenis/dist/lenis.css';
import { mountNavigationMenu } from './navigation-menu';

const root = document.documentElement;
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const skipLink = document.querySelector<HTMLAnchorElement>('.skip-link');
const main = document.querySelector<HTMLElement>('#main-content');

let lenis: Lenis | null = null;
let listenersBound = false;
let unmountNavigationMenu: (() => void) | null = null;

function start(): void {
  if (reducedMotion.matches) {
    root.dataset.scrollMode = 'native';
    return;
  }

  if (lenis) {
    root.dataset.scrollMode = 'lenis';
    return;
  }

  lenis = new Lenis({
    autoRaf: true,
    anchors: true,
    smoothWheel: true,
    syncTouch: false,
    lerp: 0.12,
    wheelMultiplier: 0.9,
    stopInertiaOnNavigate: true,
  });
  root.dataset.scrollMode = 'lenis';
}

function stop(): void {
  lenis?.destroy();
  lenis = null;
  root.dataset.scrollMode = 'native';
}

function handleMotionChange(): void {
  if (reducedMotion.matches) stop();
  else start();
}

function handleSkipLink(event: MouseEvent): void {
  if (!main) return;
  event.preventDefault();
  if (lenis) lenis.scrollTo(main, { immediate: true, force: true });
  else main.scrollIntoView({ behavior: 'auto', block: 'start' });
  main.focus({ preventScroll: true });
  if (window.location.hash !== '#main-content') {
    window.history.pushState(null, '', '#main-content');
  }
}

function bind(): void {
  if (listenersBound) return;
  reducedMotion.addEventListener('change', handleMotionChange);
  skipLink?.addEventListener('click', handleSkipLink);
  listenersBound = true;
}

function unbind(): void {
  if (!listenersBound) return;
  reducedMotion.removeEventListener('change', handleMotionChange);
  skipLink?.removeEventListener('click', handleSkipLink);
  listenersBound = false;
}

function mount(): void {
  bind();
  start();
  unmountNavigationMenu ??= mountNavigationMenu();
}

function unmount(): void {
  stop();
  unbind();
  unmountNavigationMenu?.();
  unmountNavigationMenu = null;
}

window.addEventListener('pagehide', unmount);
window.addEventListener('pageshow', (event: PageTransitionEvent) => {
  if (event.persisted) mount();
});
mount();
