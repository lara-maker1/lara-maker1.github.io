const FINE_POINTER_QUERY = '(hover: hover) and (pointer: fine)';
const REDUCED_MOTION_QUERY = '(prefers-reduced-motion: reduce)';
const LEAVE_GRACE_MS = 180;
const CLOSE_DURATION_MS = 620;

type MenuState = 'closed' | 'opening' | 'open' | 'closing';

export function mountNavigationMenu(): () => void {
  const details = document.querySelector<HTMLDetailsElement>('.nav-disclosure');
  const summary = details?.querySelector<HTMLElement>(':scope > summary');
  if (!details || !summary) return () => {};

  const finePointer = window.matchMedia(FINE_POINTER_QUERY);
  const reducedMotion = window.matchMedia(REDUCED_MOTION_QUERY);
  let pointerInside = false;
  let closeTimer: number | undefined;
  let finalizer: number | undefined;
  let focusTimer: number | undefined;
  let openingFrame: number | undefined;

  const state = (): MenuState => (details.dataset.menuState as MenuState | undefined) ?? 'closed';
  const setState = (next: MenuState): void => {
    details.dataset.menuState = next;
  };

  const clearCloseTimer = (): void => {
    if (closeTimer === undefined) return;
    window.clearTimeout(closeTimer);
    closeTimer = undefined;
  };

  const clearFinalizer = (): void => {
    if (finalizer === undefined) return;
    window.clearTimeout(finalizer);
    finalizer = undefined;
  };

  const clearFocusTimer = (): void => {
    if (focusTimer === undefined) return;
    window.clearTimeout(focusTimer);
    focusTimer = undefined;
  };

  const clearOpeningFrame = (): void => {
    if (openingFrame === undefined) return;
    window.cancelAnimationFrame(openingFrame);
    openingFrame = undefined;
  };

  const finishClosed = (): void => {
    clearFinalizer();
    details.open = false;
    setState('closed');
  };

  const openMenu = (): void => {
    clearCloseTimer();
    clearFinalizer();
    const current = state();

    if (details.open && (current === 'open' || current === 'opening')) return;
    clearOpeningFrame();
    details.open = true;

    if (reducedMotion.matches) {
      setState('open');
      return;
    }

    if (current === 'closing') {
      setState('open');
      return;
    }

    setState('opening');
    openingFrame = window.requestAnimationFrame(() => {
      openingFrame = window.requestAnimationFrame(() => {
        openingFrame = undefined;
        if (details.open && state() === 'opening') setState('open');
      });
    });
  };

  const closeMenu = (immediate = false): void => {
    clearCloseTimer();
    clearFinalizer();
    clearOpeningFrame();

    if (!details.open) {
      setState('closed');
      return;
    }

    if (immediate || reducedMotion.matches) {
      finishClosed();
      return;
    }

    setState('closing');
    finalizer = window.setTimeout(finishClosed, CLOSE_DURATION_MS);
  };

  const scheduleClose = (): void => {
    clearCloseTimer();
    closeTimer = window.setTimeout(() => {
      closeTimer = undefined;
      if (!pointerInside && !details.matches(':focus-within')) closeMenu();
    }, LEAVE_GRACE_MS);
  };

  const handlePointerEnter = (event: PointerEvent): void => {
    pointerInside = true;
    clearCloseTimer();
    if (finePointer.matches && event.pointerType !== 'touch') openMenu();
  };

  const handlePointerLeave = (event: PointerEvent): void => {
    pointerInside = false;
    if (finePointer.matches && event.pointerType !== 'touch') scheduleClose();
  };

  const handleSummaryClick = (event: MouseEvent): void => {
    event.preventDefault();
    if (details.open && state() !== 'closing') closeMenu();
    else openMenu();
  };

  const handleKeydown = (event: KeyboardEvent): void => {
    if (event.key === 'Escape' && details.open) {
      event.preventDefault();
      summary.focus({ preventScroll: true });
      closeMenu();
    }
  };

  const handleFocusIn = (): void => {
    clearFocusTimer();
    clearCloseTimer();
    if (state() === 'closing') openMenu();
  };

  const handleFocusOut = (): void => {
    clearFocusTimer();
    focusTimer = window.setTimeout(() => {
      focusTimer = undefined;
      if (finePointer.matches && !pointerInside && !details.matches(':focus-within')) scheduleClose();
    }, 0);
  };

  const handleFinePointerChange = (): void => {
    clearCloseTimer();
    if (!finePointer.matches) pointerInside = false;
  };

  const handleReducedMotionChange = (): void => {
    if (!reducedMotion.matches) return;
    clearOpeningFrame();
    if (state() === 'closing') finishClosed();
    else if (details.open) setState('open');
  };

  details.dataset.menuEnhanced = '';
  details.open = false;
  setState('closed');
  details.addEventListener('pointerenter', handlePointerEnter);
  details.addEventListener('pointerleave', handlePointerLeave);
  details.addEventListener('keydown', handleKeydown);
  details.addEventListener('focusin', handleFocusIn);
  details.addEventListener('focusout', handleFocusOut);
  summary.addEventListener('click', handleSummaryClick);
  finePointer.addEventListener('change', handleFinePointerChange);
  reducedMotion.addEventListener('change', handleReducedMotionChange);

  return () => {
    clearCloseTimer();
    clearFinalizer();
    clearFocusTimer();
    clearOpeningFrame();
    details.removeEventListener('pointerenter', handlePointerEnter);
    details.removeEventListener('pointerleave', handlePointerLeave);
    details.removeEventListener('keydown', handleKeydown);
    details.removeEventListener('focusin', handleFocusIn);
    details.removeEventListener('focusout', handleFocusOut);
    summary.removeEventListener('click', handleSummaryClick);
    finePointer.removeEventListener('change', handleFinePointerChange);
    reducedMotion.removeEventListener('change', handleReducedMotionChange);
    details.open = false;
    setState('closed');
    delete details.dataset.menuEnhanced;
  };
}
