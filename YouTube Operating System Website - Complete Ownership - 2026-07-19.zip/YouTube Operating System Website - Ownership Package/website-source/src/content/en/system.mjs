export const methodStages = [
  {
    id: 'stage-business-context',
    number: '01',
    label: 'Business context',
    input: 'Business priorities, offer context, commercial constraints, and current market questions.',
    question: 'What must YouTube help the business explain or learn?',
    output: 'Priorities, offer context, constraints, and decision criteria.',
    dependency: 'Gives audience research a business question rather than a generic search brief.',
  },
  {
    id: 'stage-audience-evidence',
    number: '02',
    label: 'Audience evidence',
    input: 'Buyer questions, search and comment language, sales conversations, objections, and market patterns.',
    question: 'What does the intended buyer ask, misunderstand, compare, or fear?',
    output: 'Evidence-backed questions and language patterns.',
    dependency: 'Gives positioning the language and tensions it needs to resolve.',
  },
  {
    id: 'stage-positioning',
    number: '03',
    label: 'Positioning',
    input: 'Business priorities, audience evidence, credible expertise, and editorial trade-offs.',
    question: 'What useful role should the channel occupy?',
    output: 'Audience promise, point of view, and editorial boundaries.',
    dependency: 'Gives content architecture a coherent promise and set of choices.',
  },
  {
    id: 'stage-content-architecture',
    number: '04',
    label: 'Content architecture',
    input: 'Positioning, audience questions, business relevance, and available source knowledge.',
    question: 'How do individual topics form a coherent library?',
    output: 'Pillars, clusters, narratives, formats, and intended viewer shifts.',
    dependency: 'Gives production an approved idea with a defined role in the library.',
  },
  {
    id: 'stage-production',
    number: '05',
    label: 'Production',
    input: 'Approved topic, source material, spokesperson access, format, and decision owners.',
    question: 'What turns an approved idea into a publishable asset?',
    output: 'Explicit owners, inputs, review states, and quality checks.',
    dependency: 'Gives publishing an asset whose purpose and intended viewer are known.',
  },
  {
    id: 'stage-publishing',
    number: '06',
    label: 'Publishing',
    input: 'Approved asset, packaging hypothesis, audience promise, and intended next action.',
    question: 'Is the asset packaged and released for the intended viewer and purpose?',
    output: 'Published content with a documented hypothesis and call to action.',
    dependency: 'Creates observable evidence for the learning and decision stage.',
  },
  {
    id: 'stage-learning-decisions',
    number: '07',
    label: 'Learning and decisions',
    input: 'Attention, content behavior, qualified-demand signals, operating evidence, and context.',
    question: 'What happened, why might it have happened, and what changes next?',
    output: 'Observations, hypotheses, and assigned decisions.',
    dependency: 'Feeds the next business, audience, positioning, architecture, and production choices.',
  },
];

export const decisionSteps = [
  {
    id: 'decision-observation',
    label: 'Observation',
    text: 'State what happened without turning the observation into a conclusion.',
  },
  {
    id: 'decision-interpretation',
    label: 'Interpretation',
    text: 'Explain what the available evidence may suggest, including uncertainty and alternatives.',
  },
  {
    id: 'decision-next',
    label: 'Next decision',
    text: 'Assign the content, positioning, production, or measurement change to test next.',
  },
];

export const clientInputs = [
  'Business priorities, offer context, constraints, and decision criteria.',
  'Subject-matter expertise, source material, examples, and customer context.',
  'Spokesperson access, a named review owner, and timely decisions.',
  'Honest operating context about the current channel, team, and expectations.',
];

export const operatorResponsibilities = [
  'Synthesize audience and market evidence around the business question.',
  'Facilitate positioning, content architecture, and editorial decisions.',
  'Coordinate agreed production inputs, owners, review states, and quality checks.',
  'Connect publishing evidence to a recurring learning and decision cadence.',
];

export const systemBoundaries = [
  'It is not a software product, account area, or product interface.',
  'It does not promise technical connections to other business systems.',
  'It does not replace human judgment with unattended workflows or machine-generated decisions.',
  'It does not replace a customer relationship system or guarantee attribution.',
  'The exact tasks coordinated by the operator depend on the approved engagement scope.',
];
