export const failureModes = [
  {
    id: 'failure-unclear-position',
    title: 'An unclear position',
    problem: 'The channel has activity but no precise role in the market or reason for the intended viewer to return.',
    consequence: 'Topics compete with one another instead of building a recognizable body of thought.',
    response: 'Define the audience promise, point of view, and editorial boundaries before scaling output.',
  },
  {
    id: 'failure-topics-without-evidence',
    title: 'Topics without evidence',
    problem: 'Ideas come from internal preference, trends, or a publishing quota rather than buyer questions and market patterns.',
    consequence: 'The team produces content without knowing what misunderstanding or decision it should address.',
    response: 'Ground topic choices in audience language, business relevance, and an explicit viewer shift.',
  },
  {
    id: 'failure-production-without-ownership',
    title: 'Production without ownership',
    problem: 'Inputs, reviews, and approvals move between people without named decisions or reliable hand-offs.',
    consequence: 'Work stalls, quality becomes subjective, and the cost of every release rises.',
    response: 'Set owners, inputs, review states, and quality checks around each production decision.',
  },
  {
    id: 'failure-analytics-without-decisions',
    title: 'Analytics without decisions',
    problem: 'Reporting ends with numbers rather than a careful explanation of what they may mean.',
    consequence: 'The next topic, format, package, or positioning choice is made from habit instead of learning.',
    response: 'Separate observation from interpretation and assign the next decision to test.',
  },
];

export const outcomeShifts = [
  {
    id: 'shift-ideas-thesis',
    from: 'Scattered ideas',
    to: 'A content thesis',
    text: 'Topics gain a shared audience promise and a reason to exist together.',
  },
  {
    id: 'shift-videos-library',
    from: 'Isolated videos',
    to: 'A connected library',
    text: 'Individual releases answer related questions and build a more useful path through the subject.',
  },
  {
    id: 'shift-assumptions-evidence',
    from: 'Internal assumptions',
    to: 'Audience evidence',
    text: 'Content decisions begin with what intended buyers ask, compare, misunderstand, and need explained.',
  },
  {
    id: 'shift-reporting-decisions',
    from: 'Reporting',
    to: 'Next decisions',
    text: 'Observed behavior becomes a cautious interpretation and an assigned change to examine.',
  },
];

export const comparisonDimensions = [
  {
    id: 'comparison-starting-point',
    dimension: 'Starting point',
    fragmented: 'A requested video or publishing quota',
    method: 'Business context, audience evidence, and positioning',
  },
  {
    id: 'comparison-unit',
    dimension: 'Unit of work',
    fragmented: 'An individual deliverable',
    method: 'A connected content and learning system',
  },
  {
    id: 'comparison-topic-selection',
    dimension: 'Topic selection',
    fragmented: 'Inspiration, trends, or internal preference',
    method: 'Audience questions, market patterns, and business relevance',
  },
  {
    id: 'comparison-production',
    dimension: 'Production',
    fragmented: 'Hand-offs between isolated specialists',
    method: 'Defined decisions, roles, inputs, and review points',
  },
  {
    id: 'comparison-measurement',
    dimension: 'Measurement',
    fragmented: 'Views and subscribers in isolation',
    method: 'Attention, audience behavior, qualified-demand signals, and business learning',
  },
  {
    id: 'comparison-after-publishing',
    dimension: 'After publishing',
    fragmented: 'Delivery is complete',
    method: 'Evidence informs the next content and positioning decision',
  },
];

export const homeFit = {
  strong: [
    'An established offer that benefits from buyer education.',
    'Credible expertise and a spokesperson who can participate.',
    'A leadership team willing to make decisions and learn over time.',
  ],
  poor: [
    'Immediate leads, guaranteed payback, or virality as the requirement.',
    'Publishing volume or low-cost editing as the primary buying criterion.',
    'An expectation that the operator invent expertise or provide a software product.',
  ],
};

export const evidenceItems = [
  {
    id: 'evidence-reserved-primary',
    claimIds: ['C-001', 'C-002', 'C-003', 'C-004', 'C-005', 'C-017'],
    publicationState: 'non-public',
    blockerId: 'LB-03',
    reviewSummary: 'Verified evidence and permissions have not cleared the claims register.',
  },
];

export const faqs = [
  {
    id: 'faq-production-service',
    question: 'Is this a video production service?',
    answer:
      'Production may be part of an engagement, but the offer is broader than isolated production. The method connects business context, research, positioning, content architecture, production decisions, publishing, and learning.',
  },
  {
    id: 'faq-speed',
    question: 'How quickly should we expect results?',
    answer:
      'YouTube is treated as a compounding, iterative channel. The useful pace depends on the offer, market, starting point, expertise, participation, production, and what the evidence reveals; the method is not designed for instant-result expectations.',
  },
  {
    id: 'faq-guarantees',
    question: 'Do you guarantee views, leads, or revenue?',
    answer:
      'No. The method is designed to support clearer education, stronger buyer understanding, and better-informed content decisions. Outcomes depend on factors no responsible operator can guarantee.',
  },
  {
    id: 'faq-participation',
    question: 'How involved does our team need to be?',
    answer:
      'Your team supplies business priorities, subject-matter expertise, source material, spokesperson access, and timely review decisions. The operating model makes that participation explicit instead of hiding it inside production delays.',
  },
  {
    id: 'faq-internal-team',
    question: 'Can you work with an internal production team?',
    answer:
      'Potentially, depending on fit and scope. The method can help define research, positioning, architecture, roles, review standards, and learning rhythms while selected execution remains internal.',
  },
  {
    id: 'faq-software',
    question: 'Is the YouTube Operating System software?',
    answer:
      'No. It is the name of a coordinated service methodology: the questions, roles, decisions, inputs, outputs, and learning cadence used to operate the YouTube function.',
  },
];
