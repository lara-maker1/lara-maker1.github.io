export const fitThesis =
  'The strongest fit is an established, expertise-led business whose buyers need education, comparison, reputation, and trust before they make a high-consideration decision.';

export const strongFitSignals = [
  { id: 'fit-working-offer', text: 'A real, sellable offer with enough economic room for careful education and production.' },
  { id: 'fit-identifiable-expertise', text: 'A founder, practitioner, expert, or credible spokesperson who can teach from real knowledge.' },
  { id: 'fit-audience-questions', text: 'Customer questions, objections, examples, and source material already exist inside the business.' },
  { id: 'fit-leadership-commitment', text: 'Leadership will connect channel choices to business priorities and make decisions when trade-offs appear.' },
  { id: 'fit-recording-access', text: 'The team can sustain expert access, recording participation, review ownership, and reasonable response times.' },
  { id: 'fit-compounding-expectation', text: 'YouTube is understood as a compounding, iterative channel rather than an instant lead source.' },
];

export const readinessInputs = [
  { id: 'readiness-priorities', text: 'Current business priorities and the decisions YouTube should help clarify.' },
  { id: 'readiness-audience', text: 'What the intended audience asks, misunderstands, compares, and needs explained.' },
  { id: 'readiness-offers', text: 'The offer, buying path, useful examples, and existing buyer education.' },
  { id: 'readiness-sources', text: 'Source material, expertise, customer language, and points of view the business can stand behind.' },
  { id: 'readiness-spokesperson', text: 'A credible spokesperson with enough access to make content specific.' },
  { id: 'readiness-owner', text: 'A named review owner and a decision cadence the team can keep.' },
];

export const poorFitSignals = [
  { id: 'poor-instant-leads', text: 'Immediate leads or a guaranteed payback date are required.' },
  { id: 'poor-virality', text: 'Virality, subscriber totals, or publishing volume are the primary outcome.' },
  { id: 'poor-output-procurement', text: 'The work is being purchased only as low-cost editing or a fixed output quota.' },
  { id: 'poor-unavailable-expertise', text: 'The operator is expected to invent expertise, evidence, examples, or opinions for an unavailable team.' },
  { id: 'poor-undefined-offer', text: 'There is no defined offer or credible point of view for content to serve.' },
  { id: 'poor-no-review-owner', text: 'Inputs and approvals are repeatedly delayed without an accountable review owner.' },
  { id: 'poor-product-expectation', text: 'The requirement is an internal YouTube software product rather than a service method.' },
];

export const selfAssessment = [
  { id: 'assess-business-question', question: 'Can we name the business question YouTube should help us explain or learn?' },
  { id: 'assess-expertise', question: 'Can a credible expert supply source material, examples, and a clear point of view?' },
  { id: 'assess-audience', question: 'Do we know which buyer questions and misunderstandings deserve patient explanation?' },
  { id: 'assess-participation', question: 'Can we provide recording access, a review owner, and timely decisions?' },
  { id: 'assess-expectations', question: 'Are we prepared to judge a compounding channel through learning as well as attention?' },
  { id: 'assess-tradeoffs', question: 'Will leadership make positioning and content trade-offs instead of asking for every possible topic?' },
];
