export const operatingBelief =
  'Businesses need a durable YouTube function, not another cycle of urgent topics, ambiguous hand-offs, and reports that never change the next decision.';

export const principles = [
  {
    id: 'principle-business-first',
    title: 'Business before content',
    text: 'Start with what the business must explain, clarify, or learn—not with a publishing quota.',
  },
  {
    id: 'principle-evidence-first',
    title: 'Evidence before topic volume',
    text: 'Use audience questions, market language, and business relevance to choose what deserves attention.',
  },
  {
    id: 'principle-ownership',
    title: 'Defined decisions and ownership',
    text: 'Name the input, owner, review state, and decision instead of hiding responsibility inside a hand-off.',
  },
  {
    id: 'principle-human-judgment',
    title: 'Human judgment over uncontrolled automation',
    text: 'Expertise, editorial judgment, and accountable review remain central to the work.',
  },
  {
    id: 'principle-learning',
    title: 'Learning after publication',
    text: 'Treat publication as the start of an evidence cycle, not the end of delivery.',
  },
];

export const methodOrigin =
  'The method comes from the practical need to organize research, content choices, production responsibilities, localization considerations, publishing, and channel learning around one coherent set of business decisions.';

export const roleFunctions = [
  { id: 'role-business-owner', title: 'Business decision owner', text: 'Keeps the channel connected to priorities, constraints, and accountable trade-offs.' },
  { id: 'role-subject-expert', title: 'Subject-matter expert', text: 'Supplies the knowledge, examples, and point of view the operator cannot responsibly invent.' },
  { id: 'role-operating-lead', title: 'Operating lead', text: 'Coordinates evidence, decisions, production states, publishing hypotheses, and the learning cadence.' },
  { id: 'role-production-functions', title: 'Production functions', text: 'Turn approved ideas into publishable work within the roles and standards agreed for the engagement.' },
];

export const rolesQualification =
  'These are functions an engagement may require. They do not represent a published employee list, team size, biography, or credential claim.';
