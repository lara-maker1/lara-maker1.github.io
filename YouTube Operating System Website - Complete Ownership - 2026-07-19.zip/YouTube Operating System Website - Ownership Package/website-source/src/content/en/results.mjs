export const measurementLayers = [
  {
    id: 'measurement-attention',
    title: 'Attention',
    signals: ['impressions', 'qualified reach', 'returning viewers'],
    caution: 'Attention shows whether the intended audience had an opportunity to notice and return. It does not establish business impact on its own.',
    decisionUse: 'Examine packaging, topic relevance, audience definition, and whether the channel is earning another viewing decision.',
  },
  {
    id: 'measurement-content-behavior',
    title: 'Content behavior',
    signals: ['click-through behavior', 'watch behavior', 'recurring questions', 'library use'],
    caution: 'Behavior can reveal where interest strengthens or falls away, but the pattern needs context before a cause is assigned.',
    decisionUse: 'Refine the opening promise, structure, depth, connected topics, and the question the content is meant to resolve.',
  },
  {
    id: 'measurement-qualified-demand',
    title: 'Qualified-demand signals',
    signals: ['relevant inquiries', 'sales-conversation quality', 'content-assisted buyer education'],
    caution: 'A signal is not the same as full attribution. Offer quality, market conditions, sales process, timing, and other channels also matter.',
    decisionUse: 'Identify which buyer questions, objections, and educational assets deserve deeper treatment or stronger sales reuse.',
  },
  {
    id: 'measurement-operating-quality',
    title: 'Operating quality',
    signals: ['cycle time', 'approval friction', 'learning cadence', 'reuse of insights'],
    caution: 'A faster process is useful only when it preserves judgment, source quality, and a clear reason for the work.',
    decisionUse: 'Clarify ownership, inputs, review standards, and the hand-offs that prevent the team from learning consistently.',
  },
];

export const evidencePrinciple =
  'Evidence becomes publishable only when the exact wording, source, timeframe, role, and permission have passed review. Until then, this prototype explains the measurement method rather than presenting proof.';

export const noGuarantee =
  'Outcomes depend on the offer, market, expertise, participation, production, timing, sales context, and other factors. The operating method cannot guarantee performance.';
