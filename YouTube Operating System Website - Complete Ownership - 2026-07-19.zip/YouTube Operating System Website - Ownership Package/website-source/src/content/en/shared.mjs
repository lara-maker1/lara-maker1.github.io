export const site = {
  identity: {
    id: 'site-identity',
    publicName: null,
    reviewLabel: 'YouTube Operating System',
    blockerId: 'LB-01',
  },
  proposition: 'We build and operate the YouTube function inside your business.',
  explanation:
    'Research, positioning, content architecture, production, publishing, and learning—connected to the decisions your business needs to make.',
  cta: {
    id: 'primary-cta',
    label: 'Request a strategy conversation',
    href: '/apply/',
  },
  reviewMode: true,
};

export const navigation = [
  { id: 'home', label: 'Home', href: '/' },
  { id: 'system', label: 'The System', href: '/system/' },
  { id: 'services', label: 'Services', href: '/services/' },
  { id: 'fit', label: 'Who It Is For', href: '/fit/' },
  { id: 'results', label: 'Results', href: '/results/' },
  { id: 'about', label: 'About', href: '/about/' },
  { id: 'apply', label: 'Apply', href: '/apply/' },
];

export const pages = [
  {
    id: 'page-home',
    route: '/',
    navLabel: 'Home',
    title: 'YouTube systems for business | Private review',
    description:
      'A coordinated YouTube methodology connecting business context, audience evidence, production, publishing, and better decisions.',
    eyebrow: 'A YouTube function for established businesses.',
    heading: 'We build the YouTube function inside your business.',
    summary: site.explanation,
  },
  {
    id: 'page-system',
    route: '/system/',
    navLabel: 'The System',
    title: 'The YouTube Operating System method | Private review',
    description:
      'See how seven connected service stages turn business context and audience evidence into content, learning, and next decisions.',
    eyebrow: 'The operating method',
    heading: 'A connected method for running YouTube as a business function.',
    summary:
      'The YouTube Operating System is a coordinated service process. It defines the questions, inputs, owners, outputs, and learning rhythm around the work—it is not software.',
  },
  {
    id: 'page-services',
    route: '/services/',
    navLabel: 'Services',
    title: 'YouTube strategy and operations services | Private review',
    description:
      'Explore provisional diagnostic, strategy, launch, operating, and internal-team enablement paths for an established business.',
    eyebrow: 'Ways to engage',
    heading: 'Start with the operating constraint that matters now.',
    summary:
      'An engagement may diagnose, design, reset, operate, or help install the method inside your team. Availability and scope are confirmed only after fit and service review.',
  },
  {
    id: 'page-fit',
    route: '/fit/',
    navLabel: 'Who It Is For',
    title: 'Who the YouTube operating method fits | Private review',
    description:
      'Assess whether your offer, expertise, team participation, buyer questions, and expectations fit a compounding YouTube channel.',
    eyebrow: 'Fit before output',
    heading: 'The method fits businesses prepared to teach, participate, and learn.',
    summary:
      'YouTube is strategically useful when buyers need explanation, comparison, reputation, and trust—and when the business can supply the expertise and decisions behind the channel.',
  },
  {
    id: 'page-results',
    route: '/results/',
    navLabel: 'Results',
    title: 'How YouTube work is measured | Private review',
    description:
      'A claim-safe framework for judging attention, content behavior, qualified-demand signals, operating quality, and the decisions that follow.',
    eyebrow: 'Measurement without theatre',
    heading: 'Views matter. They are not enough on their own.',
    summary:
      'Useful measurement connects audience behavior and operating evidence to a cautious interpretation and a clearly assigned next decision.',
  },
  {
    id: 'page-about',
    route: '/about/',
    navLabel: 'About',
    title: 'About the YouTube operating method | Private review',
    description:
      'The company-method narrative and operating principles behind a research-led, decision-connected approach to YouTube.',
    eyebrow: 'The operating belief',
    heading: 'A durable YouTube function is built through decisions, not recurring content chaos.',
    summary:
      'The method organizes business priorities, audience evidence, content choices, production responsibilities, and post-publication learning into one working cadence.',
  },
  {
    id: 'page-apply',
    route: '/apply/',
    navLabel: 'Apply',
    title: 'Request a strategy conversation | Private review',
    description:
      'Preview the fit-review process and the business, YouTube, constraint, participation, and timing context a future inquiry would cover.',
    eyebrow: 'Fit review first',
    heading: 'Request a strategy conversation.',
    summary:
      'The first step is a fit review—not an instant sales call or a guaranteed engagement. If there is a useful match, a conversation can define the next decision and a clearly scoped path.',
  },
];

export function getPage(route) {
  const page = pages.find((item) => item.route === route);
  if (!page) throw new Error(`Missing page content for route: ${route}`);
  return page;
}

export const launchNotes = {
  identity: {
    id: 'review-identity',
    blockerId: 'LB-01',
    label: 'Review note — not public copy',
    text: 'Public company identity, accountable contact, and footer disclosures remain unapproved.',
  },
  evidence: {
    id: 'review-evidence',
    blockerId: 'LB-03',
    label: 'Review note — not public copy',
    text: 'The production Results treatment requires verified evidence, an approved claim-free framework, or an approved route omission.',
  },
  inquiry: {
    id: 'review-inquiry',
    blockerId: 'LB-05',
    label: 'Review note — not public copy',
    text: 'The production inquiry flow, data processor, response owner, retention policy, and security controls remain unapproved.',
  },
  about: {
    id: 'review-about',
    blockerId: 'LB-06',
    label: 'Review note — not public copy',
    text: 'Company story, founder details, factual claims, and final page copy still require accountable approval.',
  },
};
