export const applyProcess = [
  { id: 'apply-request', number: '01', title: 'Request', text: 'Share the business and operating context needed for an initial fit review.' },
  { id: 'apply-fit-review', number: '02', title: 'Fit review', text: 'The offer, expertise, expectations, participation, and current constraint are considered together.' },
  { id: 'apply-conversation', number: '03', title: 'Strategy conversation', text: 'If there is a useful match, the conversation examines the most important question and the realities around it.' },
  { id: 'apply-next-step', number: '04', title: 'Clearly scoped next step', text: 'Any next step is defined around fit, an approved service path, responsibilities, exclusions, and commercial review.' },
];

export const questionPreview = [
  { id: 'question-company-role', label: 'Company and role', purpose: 'Who is considering the work, and who would own the decision?' },
  { id: 'question-website', label: 'Website, if relevant', purpose: 'Where can the current offer and buyer education be understood?' },
  { id: 'question-offer', label: 'Offer and business model', purpose: 'What does the business sell, and why does the buying decision require trust or explanation?' },
  { id: 'question-youtube-state', label: 'Current YouTube state', purpose: 'What exists today, and how is research, production, publishing, and learning currently handled?' },
  { id: 'question-objective', label: 'Primary objective', purpose: 'What should the channel help the business explain, clarify, or learn?' },
  { id: 'question-constraint', label: 'Main operating constraint', purpose: 'What most limits the channel now: evidence, position, architecture, production, ownership, or learning?' },
  { id: 'question-participation', label: 'Team participation', purpose: 'Which experts, spokespeople, reviewers, and decision owners can take part?' },
  { id: 'question-timing', label: 'Timing context', purpose: 'What business context affects when the decision needs to be made, without implying a promised delivery date?' },
];

export const noCollectionNotice = 'This private prototype does not submit or store information.';
