const exclusion = 'Performance is not guaranteed; availability and final scope require fit and service approval.';

export const services = [
  {
    id: 'service-diagnostic',
    title: 'Diagnostic session',
    bestWhen: 'The team knows YouTube is underperforming as a business function but the controlling constraint is still unclear.',
    scopeCategories: ['business and channel context', 'constraint diagnosis', 'priority decision'],
    participation: 'A decision-maker and the people closest to the offer, audience, and current channel contribute context.',
    intendedDecision: 'Identify the most important operating constraint and the next decision worth making.',
    exclusion,
  },
  {
    id: 'service-strategy',
    title: 'Strategy intensive',
    bestWhen: 'The business has expertise and an offer but needs a coherent audience, position, content architecture, and operating model.',
    scopeCategories: ['audience evidence', 'positioning', 'content architecture', 'operating model'],
    participation: 'Leadership and subject-matter experts provide source knowledge, challenge assumptions, and approve the core choices.',
    intendedDecision: 'Define what the channel should teach, for whom, from what point of view, and through what decision cadence.',
    exclusion,
  },
  {
    id: 'service-launch-reset',
    title: 'Channel launch or reset',
    bestWhen: 'An approved direction needs to become a coordinated production and publishing foundation—or an existing channel needs a disciplined reset.',
    scopeCategories: ['operating foundation', 'production roles', 'review standards', 'publishing hypotheses'],
    participation: 'The team supplies expertise, recording access, approvals, and the owners needed to make the operating model real.',
    intendedDecision: 'Translate strategy into a repeatable path from approved idea to published learning.',
    exclusion,
  },
  {
    id: 'service-ongoing-operation',
    title: 'Ongoing YouTube operation',
    bestWhen: 'The business wants the research, planning, production, publishing, and learning cadence coordinated as one function.',
    scopeCategories: ['research cadence', 'content planning', 'production coordination', 'publishing support', 'learning reviews'],
    participation: 'The client keeps business context, expert access, review ownership, and timely decisions inside the loop.',
    intendedDecision: 'Maintain a coherent channel while turning evidence into the next content and positioning choice.',
    exclusion,
  },
  {
    id: 'service-team-enablement',
    title: 'Internal-team enablement',
    bestWhen: 'Execution will remain inside the client team, but roles, standards, reviews, and learning rhythms need to be installed or strengthened.',
    scopeCategories: ['role design', 'working standards', 'review rhythm', 'decision templates', 'team coaching'],
    participation: 'The internal owners attend working sessions, use the agreed method, and bring real decisions back for review.',
    intendedDecision: 'Give the internal team a clearer operating method without implying that every execution task is outsourced.',
    exclusion,
  },
];
