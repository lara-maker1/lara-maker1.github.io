import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import { createServer } from 'node:net';
import { resolve } from 'node:path';

import { chromium } from 'playwright-core';

const require = createRequire(import.meta.url);
const axePath = require.resolve('axe-core/axe.min.js');
const EXPECTED_PREVIEW_TITLE = 'YouTube systems for business | Private review';
const routes = ['/', '/system/', '/services/', '/fit/', '/results/', '/about/', '/apply/'];
const viewports = [
  { width: 320, height: 568 },
  { width: 375, height: 812 },
  { width: 768, height: 1024 },
  { width: 1024, height: 768 },
  { width: 1440, height: 900 },
];
const axeTags = ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'];
const seriousImpacts = new Set(['serious', 'critical']);

function wait(milliseconds) {
  return new Promise((resolvePromise) => setTimeout(resolvePromise, milliseconds));
}

async function allocateLoopbackPort() {
  const reservation = createServer();
  await new Promise((resolveReady, rejectReady) => {
    reservation.once('error', rejectReady);
    reservation.listen(0, '127.0.0.1', resolveReady);
  });

  const address = reservation.address();
  if (!address || typeof address === 'string') {
    reservation.close();
    throw new Error('Unable to allocate a numeric loopback port for browser verification.');
  }

  const { port } = address;
  await new Promise((resolveClose, rejectClose) => {
    reservation.close((error) => {
      if (error) rejectClose(error);
      else resolveClose();
    });
  });
  return port;
}

async function waitForPreview(server, output, baseUrl) {
  let identityMismatch = false;
  for (let attempt = 0; attempt < 80; attempt += 1) {
    if (server.exitCode !== null) {
      throw new Error(`Astro preview exited before readiness.\n${output.value}`);
    }
    try {
      const response = await fetch(baseUrl);
      if (response.ok) {
        const html = await response.text();
        if (html.includes(`<title>${EXPECTED_PREVIEW_TITLE}</title>`)) return;
        identityMismatch = true;
      }
    } catch {
      // The preview process is still starting.
    }
    await wait(125);
  }
  const identityNote = identityMismatch
    ? `\nThe allocated port returned HTML without the expected title: ${EXPECTED_PREVIEW_TITLE}`
    : '';
  throw new Error(`Timed out waiting for Astro preview.${identityNote}\n${output.value}`);
}

async function launchChrome() {
  try {
    return await chromium.launch({ channel: 'chrome', headless: true });
  } catch (channelError) {
    const executablePath = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
    if (!existsSync(executablePath)) throw channelError;
    return chromium.launch({ executablePath, headless: true });
  }
}

function durationInSeconds(value) {
  return value
    .split(',')
    .map((part) => part.trim())
    .reduce((maximum, part) => {
      if (part.endsWith('ms')) return Math.max(maximum, Number.parseFloat(part) / 1000);
      if (part.endsWith('s')) return Math.max(maximum, Number.parseFloat(part));
      return maximum;
    }, 0);
}

async function waitForMenuState(page, expectedOpen, expectedState, timeout = 1600) {
  try {
    await page.waitForFunction(
      ({ open, state }) => {
        const details = document.querySelector('.nav-disclosure');
        return details instanceof HTMLDetailsElement &&
          details.open === open &&
          details.dataset.menuState === state;
      },
      { open: expectedOpen, state: expectedState },
      { timeout },
    );
    return true;
  } catch {
    return false;
  }
}

async function run() {
  const port = await allocateLoopbackPort();
  const baseUrl = `http://127.0.0.1:${port}`;
  const baseOrigin = new URL(baseUrl).origin;
  const output = { value: '' };
  const server = spawn('npm', ['run', 'preview', '--', '--port', String(port)], {
    cwd: resolve(import.meta.dirname, '..'),
    env: { ...process.env, ASTRO_TELEMETRY_DISABLED: '1' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  server.stdout.on('data', (chunk) => { output.value += chunk.toString(); });
  server.stderr.on('data', (chunk) => { output.value += chunk.toString(); });

  let browser;
  const errors = [];
  let viewportChecks = 0;
  let axeChecks = 0;

  try {
    await waitForPreview(server, output, baseUrl);
    browser = await launchChrome();
    const context = await browser.newContext();
    const page = await context.newPage();

    page.on('console', (message) => {
      if (message.type() === 'error') {
        const location = message.location().url || 'unknown location';
        errors.push(`Console error at ${location}: ${message.text()}`);
      }
    });
    page.on('pageerror', (error) => errors.push(`Page error: ${error.message}`));
    page.on('requestfailed', (request) => {
      errors.push(`Failed request: ${request.url()} (${request.failure()?.errorText ?? 'unknown error'})`);
    });
    page.on('request', (request) => {
      const url = new URL(request.url());
      if (url.origin !== baseOrigin) errors.push(`Third-party request: ${request.url()}`);
      if (request.method() !== 'GET') errors.push(`Unexpected non-GET request: ${request.method()} ${request.url()}`);
    });

    for (const viewport of viewports) {
      await page.setViewportSize(viewport);
      for (const route of routes) {
        const response = await page.goto(`${baseUrl}${route}`, { waitUntil: 'networkidle' });
        await page.evaluate(() => document.fonts.ready);
        viewportChecks += 1;
        if (!response?.ok()) errors.push(`${route} returned ${response?.status() ?? 'no response'}.`);

        const state = await page.evaluate(() => ({
          h1Count: document.querySelectorAll('h1').length,
          headerCount: document.querySelectorAll('header.site-header').length,
          navCount: document.querySelectorAll('nav').length,
          mainCount: document.querySelectorAll('main#main-content').length,
          footerCount: document.querySelectorAll('footer.site-footer').length,
          currentCount: document.querySelectorAll('a[aria-current="page"]').length,
          scrollWidth: document.documentElement.scrollWidth,
          innerWidth: window.innerWidth,
          unlabeledBlockerCount: [...document.querySelectorAll('body *')]
            .filter((element) => element.children.length === 0 && /LB-\d{2}/.test(element.textContent ?? ''))
            .filter((element) => {
              const note = element.closest('aside');
              return !note || !/Review note — not public copy/i.test(note.textContent ?? '');
            }).length,
          externalResources: performance
            .getEntriesByType('resource')
            .map((entry) => entry.name)
            .filter((url) => new URL(url).origin !== window.location.origin),
        }));

        if (state.h1Count !== 1) errors.push(`${route} at ${viewport.width}px has ${state.h1Count} H1 elements.`);
        if (state.headerCount !== 1 || state.navCount < 1 || state.mainCount !== 1 || state.footerCount !== 1) {
          errors.push(`${route} at ${viewport.width}px is missing a required landmark.`);
        }
        if (state.currentCount < 1) errors.push(`${route} at ${viewport.width}px has no aria-current link.`);
        if (state.scrollWidth > state.innerWidth + 1) {
          errors.push(`${route} overflows horizontally at ${viewport.width}px: ${state.scrollWidth}px > ${state.innerWidth}px.`);
        }
        if (state.unlabeledBlockerCount > 0) {
          errors.push(`${route} contains ${state.unlabeledBlockerCount} structurally unlabeled launch-blocker reference(s).`);
        }
        if (state.externalResources.length) {
          errors.push(`${route} loaded third-party resources: ${state.externalResources.join(', ')}`);
        }

        if (viewport.width === 1440) {
          const visualState = await page.evaluate(() => {
            const root = getComputedStyle(document.documentElement);
            const h1 = getComputedStyle(document.querySelector('h1'));
            const body = getComputedStyle(document.body);
            return {
              paper: root.getPropertyValue('--paper').trim(),
              ink: root.getPropertyValue('--ink').trim(),
              cobalt: root.getPropertyValue('--cobalt').trim(),
              h1Family: h1.fontFamily,
              bodyFamily: body.fontFamily,
              titleCards: document.querySelectorAll('.title-card').length,
              scrollMode: document.documentElement.dataset.scrollMode,
              compactMenuDisplay: getComputedStyle(document.querySelector('.nav-disclosure')).display,
              desktopNavDisplay: getComputedStyle(document.querySelector('.desktop-nav')).display,
            };
          });

          if (route === '/') {
            if (visualState.paper !== '#f7f7f5' || visualState.ink !== '#0b0b0b' || visualState.cobalt !== '#184ae8') {
              errors.push(`Home visual tokens are incorrect: ${JSON.stringify(visualState)}.`);
            }
            if (!visualState.h1Family.includes('IBM Plex Sans Condensed')) {
              errors.push(`Home H1 does not use IBM Plex Sans Condensed: ${visualState.h1Family}.`);
            }
            if (!visualState.bodyFamily.includes('IBM Plex Sans')) {
              errors.push(`Home body does not use IBM Plex Sans: ${visualState.bodyFamily}.`);
            }
            if (visualState.compactMenuDisplay !== 'none' || visualState.desktopNavDisplay === 'none') {
              errors.push(`Desktop navigation visibility is incorrect: ${JSON.stringify(visualState)}.`);
            }
          }

          const expectedTitleCards = route === '/' ? 1 : 0;
          if (visualState.titleCards !== expectedTitleCards) {
            errors.push(`${route} has ${visualState.titleCards} title cards; expected ${expectedTitleCards}.`);
          }
          if (visualState.scrollMode !== 'lenis') {
            errors.push(`${route} ordinary scroll mode is ${visualState.scrollMode ?? 'unset'} instead of lenis.`);
          }
        }

        if (route === '/' && viewport.width === 1440) {
          await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
          await page.mouse.move(720, 450);
          await page.mouse.wheel(0, 900);
          await page.waitForTimeout(180);
          const wheelState = await page.evaluate(() => ({
            y: window.scrollY,
            mode: document.documentElement.dataset.scrollMode,
            lenisClass: document.documentElement.classList.contains('lenis'),
          }));
          if (wheelState.mode !== 'lenis' || !wheelState.lenisClass || wheelState.y <= 0) {
            errors.push(`Lenis wheel smoke failed: ${JSON.stringify(wheelState)}.`);
          }
        }

        if (route === '/apply/') {
          const applyControls = await page.locator('main#main-content').locator('form, input, select, textarea, button[type="submit"], a[href^="mailto:"]').count();
          if (applyControls !== 0) errors.push(`Apply exposes ${applyControls} operational form or contact controls.`);
        }

        if (viewport.width === 375 || viewport.width === 1440) {
          await page.addScriptTag({ path: axePath });
          const axeResult = await page.evaluate(async (tags) => globalThis.axe.run(document, {
            runOnly: { type: 'tag', values: tags },
          }), axeTags);
          axeChecks += 1;
          const seriousViolations = axeResult.violations.filter((violation) => seriousImpacts.has(violation.impact));
          for (const violation of seriousViolations) {
            errors.push(`${route} at ${viewport.width}px Axe ${violation.impact}: ${violation.id} (${violation.nodes.length} node(s)).`);
          }
        }
      }
    }

    await page.setViewportSize({ width: 1024, height: 768 });
    await page.goto(baseUrl, { waitUntil: 'networkidle' });

    const hoverMenu = page.locator('.nav-disclosure[data-menu-state]');
    const hoverSummary = page.locator('.nav-disclosure > summary');
    const hoverReveal = page.locator('.nav-disclosure__reveal');
    const hoverResponsiveLink = page.locator('.nav-disclosure nav a[href="/system/"]');
    const summaryBox = await hoverSummary.boundingBox();

    if (!summaryBox) {
      errors.push('Compact Menu trigger has no pointer geometry at 1024px.');
    } else {
      await page.mouse.move(summaryBox.x + summaryBox.width / 2, summaryBox.y + summaryBox.height / 2);
      await page.waitForTimeout(80);
      const menuEarlyHeight = await hoverReveal.evaluate((element) => element.getBoundingClientRect().height);
      await page.waitForTimeout(360);
      const menuMidHeight = await hoverReveal.evaluate((element) => element.getBoundingClientRect().height);
      await page.waitForTimeout(720);
      const menuFinalHeight = await hoverReveal.evaluate((element) => element.getBoundingClientRect().height);
      const openState = await hoverMenu.evaluate((element) => ({
        open: element.open,
        state: element.dataset.menuState,
      }));

      if (!openState.open || openState.state !== 'open') {
        errors.push(`Compact hover did not open: ${JSON.stringify(openState)}.`);
      }
      if (!(menuMidHeight > menuEarlyHeight && menuFinalHeight > menuMidHeight && menuFinalHeight > 300)) {
        errors.push(
          `Compact reveal was not progressively increasing to its full height: ` +
          `${menuEarlyHeight}, ${menuMidHeight}, ${menuFinalHeight}.`,
        );
      }

      const panelWidth = await hoverReveal.evaluate((element) => element.getBoundingClientRect().width);
      if (Math.abs(panelWidth - 204) > 2) {
        errors.push(`Compact panel width is ${panelWidth}px instead of approximately 204px.`);
      }

      const linkStyleBeforeHover = await hoverResponsiveLink.evaluate((element) => {
        const style = getComputedStyle(element);
        return { background: style.backgroundColor, color: style.color, boxShadow: style.boxShadow };
      });
      if (linkStyleBeforeHover.boxShadow.includes('24, 74, 232')) {
        errors.push(`Non-current compact row has a cobalt edge before hover: ${JSON.stringify(linkStyleBeforeHover)}.`);
      }

      await hoverResponsiveLink.hover();
      await page.waitForTimeout(360);
      const linkStyle = await hoverResponsiveLink.evaluate((element) => {
        const style = getComputedStyle(element);
        return { background: style.backgroundColor, color: style.color, boxShadow: style.boxShadow };
      });
      if (
        linkStyle.background !== 'rgb(11, 11, 11)' ||
        linkStyle.color !== 'rgb(255, 255, 255)' ||
        !linkStyle.boxShadow.includes('24, 74, 232')
      ) {
        errors.push(`Compact row response is incorrect: ${JSON.stringify(linkStyle)}.`);
      }

      await page.mouse.move(4, 740);
      await page.waitForTimeout(100);
      if (!(await hoverMenu.evaluate((element) => element.open))) {
        errors.push('Compact menu ignored the pointer-leave grace window.');
      }
      await page.waitForTimeout(850);
      const closedState = await hoverMenu.evaluate((element) => ({
        open: element.open,
        state: element.dataset.menuState,
      }));
      if (closedState.open || closedState.state !== 'closed') {
        errors.push(`Compact menu did not finish closing after pointer leave: ${JSON.stringify(closedState)}.`);
      }

      await page.mouse.move(summaryBox.x + summaryBox.width / 2, summaryBox.y + summaryBox.height / 2);
      await page.waitForTimeout(1100);
      await page.mouse.move(4, 740);
      await page.waitForTimeout(260);
      const closingState = await hoverMenu.evaluate((element) => ({
        open: element.open,
        state: element.dataset.menuState,
      }));
      if (!closingState.open || closingState.state !== 'closing') {
        errors.push(`Compact menu did not enter its reversible closing state: ${JSON.stringify(closingState)}.`);
      }
      await page.mouse.move(summaryBox.x + summaryBox.width / 2, summaryBox.y + summaryBox.height / 2);
      await page.waitForTimeout(100);
      const reentryState = await hoverMenu.evaluate((element) => ({
        open: element.open,
        state: element.dataset.menuState,
      }));
      if (!reentryState.open || reentryState.state !== 'open') {
        errors.push(`Compact menu did not reverse cleanly on re-entry: ${JSON.stringify(reentryState)}.`);
      }

      await hoverResponsiveLink.focus();
      await page.mouse.move(4, 740);
      await page.waitForTimeout(950);
      const focusProtectedState = await hoverMenu.evaluate((element) => ({
        open: element.open,
        state: element.dataset.menuState,
        focusWithin: element.matches(':focus-within'),
        activeHref: document.activeElement?.getAttribute('href'),
      }));
      if (
        !focusProtectedState.open ||
        focusProtectedState.state !== 'open' ||
        !focusProtectedState.focusWithin ||
        focusProtectedState.activeHref !== '/system/'
      ) {
        errors.push(`Focus within did not protect the compact menu: ${JSON.stringify(focusProtectedState)}.`);
      }

      await page.locator('.wordmark').focus();
      if (!(await waitForMenuState(page, false, 'closed'))) {
        errors.push('Compact menu did not close after both pointer and focus left the disclosure.');
      }
    }

    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
    await page.locator('body').press('Home');
    await page.keyboard.press('Tab');
    const firstFocus = await page.evaluate(() => ({
      text: document.activeElement?.textContent?.trim(),
      href: document.activeElement?.getAttribute('href'),
    }));
    if (firstFocus.href !== '#main-content') errors.push(`First keyboard focus is not the skip link: ${firstFocus.text ?? 'unknown'}.`);
    await page.keyboard.press('Enter');
    const skipState = await page.evaluate(() => ({
      activeId: document.activeElement?.id,
      hash: location.hash,
    }));
    if (skipState.activeId !== 'main-content') errors.push('Skip link did not move focus to main content.');
    if (skipState.hash !== '#main-content') errors.push(`Skip link left the fragment as ${skipState.hash || 'empty'}.`);

    await page.locator('body').press('Home');
    await page.keyboard.press('PageDown');
    if ((await page.evaluate(() => window.scrollY)) <= 0) errors.push('PageDown did not scroll the document.');
    await page.keyboard.press('Home');

    const menu = page.locator('.nav-disclosure > summary');
    await menu.focus();
    const menuFocus = await menu.evaluate((element) => {
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return { outline: style.outlineStyle, outlineWidth: Number.parseFloat(style.outlineWidth), height: rect.height };
    });
    if (menuFocus.outline === 'none' || menuFocus.outlineWidth < 3) errors.push('Mobile navigation control lacks a visible focus outline.');
    if (menuFocus.height < 44) errors.push(`Mobile navigation control is only ${menuFocus.height}px high.`);
    await page.keyboard.press('Enter');
    if (!(await page.locator('.nav-disclosure').evaluate((element) => element.open))) errors.push('Mobile navigation did not open from Enter.');
    if (!(await waitForMenuState(page, true, 'open', 600))) {
      errors.push('Mobile navigation did not reach its open state after Enter.');
    }
    await page.keyboard.press('Tab');
    const enterLinkFocus = await page.evaluate(() => {
      const active = document.activeElement;
      return {
        inMenu: active instanceof HTMLAnchorElement && Boolean(active.closest('.nav-disclosure')),
        href: active?.getAttribute('href'),
        height: active?.getBoundingClientRect().height ?? 0,
      };
    });
    if (!enterLinkFocus.inMenu || enterLinkFocus.href !== '/' || enterLinkFocus.height < 44) {
      errors.push(`Enter did not expose and focus the first compact-menu link: ${JSON.stringify(enterLinkFocus)}.`);
    }
    await page.keyboard.press('Escape');
    if (!(await waitForMenuState(page, false, 'closed'))) {
      errors.push('Escape did not finish closing the compact menu within its bounded transition window.');
    }
    const escapedMenu = await page.locator('.nav-disclosure').evaluate((element) => ({
      open: element.open,
      state: element.dataset.menuState,
      summaryFocused: document.activeElement === element.querySelector(':scope > summary'),
    }));
    if (escapedMenu.open || escapedMenu.state !== 'closed' || !escapedMenu.summaryFocused) {
      errors.push(`Escape did not close the compact menu and restore trigger focus: ${JSON.stringify(escapedMenu)}.`);
    }
    await page.keyboard.press('Space');
    if (!(await waitForMenuState(page, true, 'open', 600))) {
      errors.push('Mobile navigation did not reopen from Space after Escape.');
    }
    await page.keyboard.press('Tab');
    const mobileLinkVisible = await page.evaluate(() => {
      const active = document.activeElement;
      return active instanceof HTMLAnchorElement && active.getBoundingClientRect().height >= 44;
    });
    if (!mobileLinkVisible) errors.push('The first mobile navigation link is not keyboard-visible with a practical target height.');

    const button = page.locator('.page-intro .button').first();
    await button.focus();
    const buttonFocus = await button.evaluate((element) => {
      const style = getComputedStyle(element);
      return { outline: style.outlineStyle, outlineWidth: Number.parseFloat(style.outlineWidth) };
    });
    if (buttonFocus.outline === 'none' || buttonFocus.outlineWidth < 3) errors.push('Primary CTA lacks a visible focus outline.');

    await page.goto(`${baseUrl}/#main-content`, { waitUntil: 'networkidle' });
    if ((await page.locator('#main-content').count()) !== 1) errors.push('Direct main-content fragment did not resolve.');

    await page.goto(`${baseUrl}/system/`, { waitUntil: 'networkidle' });
    await page.goBack({ waitUntil: 'networkidle' });
    if (new URL(page.url()).pathname !== '/') errors.push('Back navigation did not return to Home.');

    const coarseContext = await browser.newContext({
      hasTouch: true,
      isMobile: true,
      viewport: { width: 375, height: 812 },
    });
    const coarsePage = await coarseContext.newPage();
    await coarsePage.goto(baseUrl, { waitUntil: 'networkidle' });
    const coarseMenu = coarsePage.locator('.nav-disclosure');
    const coarseSummary = coarsePage.locator('.nav-disclosure > summary');

    await coarseMenu.dispatchEvent('pointerenter', { pointerType: 'touch' });
    const coarsePointerState = await coarseMenu.evaluate((element) => ({
      open: element.open,
      state: element.dataset.menuState,
      finePointer: matchMedia('(hover: hover) and (pointer: fine)').matches,
    }));
    if (coarsePointerState.open || coarsePointerState.state !== 'closed' || coarsePointerState.finePointer) {
      errors.push(`Coarse-pointer entry incorrectly assumed hover behavior: ${JSON.stringify(coarsePointerState)}.`);
    }

    await coarseSummary.tap();
    if (!(await waitForMenuState(coarsePage, true, 'open', 600))) {
      errors.push('Touch tap did not open the compact menu.');
    }
    await coarseSummary.tap();
    const coarseClosingState = await coarseMenu.evaluate((element) => ({
      open: element.open,
      state: element.dataset.menuState,
    }));
    if (!coarseClosingState.open || coarseClosingState.state !== 'closing') {
      errors.push(`Second touch tap did not begin the controlled close: ${JSON.stringify(coarseClosingState)}.`);
    }
    if (!(await waitForMenuState(coarsePage, false, 'closed'))) {
      errors.push('Touch-toggled compact menu did not finish closing within its bounded transition window.');
    }
    await coarseContext.close();

    const noScriptContext = await browser.newContext({
      javaScriptEnabled: false,
      viewport: { width: 375, height: 812 },
    });
    const noScriptPage = await noScriptContext.newPage();
    for (const route of routes) {
      const response = await noScriptPage.goto(`${baseUrl}${route}`, { waitUntil: 'load' });
      if (!response?.ok()) errors.push(`${route} failed with JavaScript disabled.`);
      const coreState = await noScriptPage.evaluate(() => ({
        h1: document.querySelector('h1')?.textContent?.trim() ?? '',
        mainTextLength: document.querySelector('main')?.textContent?.trim().length ?? 0,
        routeLinks: document.querySelectorAll('a[href^="/"]').length,
      }));
      if (!coreState.h1 || coreState.mainTextLength < 200 || coreState.routeLinks < 7) {
        errors.push(`${route} loses core content or navigation with JavaScript disabled.`);
      }
    }
    await noScriptPage.goto(baseUrl, { waitUntil: 'load' });
    await noScriptPage.locator('.nav-disclosure > summary').click();
    if (!(await noScriptPage.locator('.nav-disclosure').evaluate((element) => element.open))) {
      errors.push('Native compact navigation disclosure does not work with JavaScript disabled.');
    }
    await noScriptPage.locator('.nav-disclosure nav a[href="/system/"]').click();
    if (!noScriptPage.url().endsWith('/system/')) {
      errors.push('Core compact navigation failed with JavaScript disabled.');
    }
    await noScriptPage.goto(baseUrl, { waitUntil: 'load' });
    await noScriptPage.locator('.faq-list summary').first().click();
    if (!(await noScriptPage.locator('.faq-list details').first().evaluate((element) => element.open))) {
      errors.push('Native FAQ disclosure does not work with JavaScript disabled.');
    }
    await noScriptContext.close();

    const reducedContext = await browser.newContext({
      reducedMotion: 'reduce',
      viewport: { width: 1024, height: 768 },
    });
    const reducedPage = await reducedContext.newPage();
    await reducedPage.goto(baseUrl, { waitUntil: 'networkidle' });
    const reducedSummary = reducedPage.locator('.nav-disclosure > summary');
    await reducedSummary.focus();
    await reducedPage.keyboard.press('Enter');
    const reducedMenuOpenState = await reducedPage.locator('.nav-disclosure').evaluate((element) => ({
      open: element.open,
      state: element.dataset.menuState,
      revealHeight: element.querySelector('.nav-disclosure__reveal')?.getBoundingClientRect().height ?? 0,
    }));
    if (
      !reducedMenuOpenState.open ||
      reducedMenuOpenState.state !== 'open' ||
      reducedMenuOpenState.revealHeight <= 300
    ) {
      errors.push(`Reduced motion did not open the compact menu immediately: ${JSON.stringify(reducedMenuOpenState)}.`);
    }
    const reducedState = await reducedPage.evaluate(() => ({
      scrollBehavior: getComputedStyle(document.documentElement).scrollBehavior,
      transitionDuration: getComputedStyle(document.querySelector('.faq-list__marker')).transitionDuration,
      menuTransitionDuration: getComputedStyle(document.querySelector('.nav-disclosure__reveal')).transitionDuration,
      menuTransitionDelay: getComputedStyle(document.querySelector('.nav-disclosure__reveal')).transitionDelay,
      mode: document.documentElement.dataset.scrollMode,
      lenis: document.documentElement.classList.contains('lenis'),
    }));
    if (reducedState.scrollBehavior !== 'auto') errors.push(`Reduced motion leaves scroll behavior as ${reducedState.scrollBehavior}.`);
    if (durationInSeconds(reducedState.transitionDuration) > 0.001) {
      errors.push(`Reduced motion leaves a ${reducedState.transitionDuration} FAQ transition.`);
    }
    if (
      durationInSeconds(reducedState.menuTransitionDuration) > 0.001 ||
      durationInSeconds(reducedState.menuTransitionDelay) > 0.001
    ) {
      errors.push(
        `Reduced motion leaves compact-menu timing at ` +
        `${reducedState.menuTransitionDuration} with ${reducedState.menuTransitionDelay} delay.`,
      );
    }
    if (reducedState.mode !== 'native' || reducedState.lenis) {
      errors.push(`Initial reduced-motion context did not use native scrolling: ${JSON.stringify(reducedState)}.`);
    }
    await reducedPage.keyboard.press('Escape');
    const reducedMenuClosedState = await reducedPage.locator('.nav-disclosure').evaluate((element) => ({
      open: element.open,
      state: element.dataset.menuState,
      summaryFocused: document.activeElement === element.querySelector(':scope > summary'),
    }));
    if (
      reducedMenuClosedState.open ||
      reducedMenuClosedState.state !== 'closed' ||
      !reducedMenuClosedState.summaryFocused
    ) {
      errors.push(`Reduced motion did not close the compact menu immediately: ${JSON.stringify(reducedMenuClosedState)}.`);
    }
    await reducedContext.close();

    await page.emulateMedia({ reducedMotion: 'no-preference' });
    await page.waitForTimeout(50);
    const liveSummary = page.locator('.nav-disclosure > summary');
    await liveSummary.focus();
    await page.keyboard.press('Space');
    if (!(await waitForMenuState(page, true, 'open', 600))) {
      errors.push('Live motion-preference probe could not open the compact menu.');
    }
    await page.keyboard.press('Escape');
    const liveClosingState = await page.locator('.nav-disclosure').evaluate((element) => ({
      open: element.open,
      state: element.dataset.menuState,
    }));
    if (!liveClosingState.open || liveClosingState.state !== 'closing') {
      errors.push(`Live motion-preference probe did not enter closing: ${JSON.stringify(liveClosingState)}.`);
    }

    await page.emulateMedia({ reducedMotion: 'reduce' });
    if (!(await waitForMenuState(page, false, 'closed', 250))) {
      errors.push('Live reduced-motion change did not immediately finalize the compact-menu close.');
    }
    const reducedLive = await page.evaluate(() => ({
      mode: document.documentElement.dataset.scrollMode,
      lenis: document.documentElement.classList.contains('lenis'),
      menuOpen: document.querySelector('.nav-disclosure')?.open,
      menuState: document.querySelector('.nav-disclosure')?.dataset.menuState,
    }));
    if (
      reducedLive.mode !== 'native' ||
      reducedLive.lenis ||
      reducedLive.menuOpen ||
      reducedLive.menuState !== 'closed'
    ) {
      errors.push(`Live reduced-motion change did not finalize navigation and destroy Lenis: ${JSON.stringify(reducedLive)}.`);
    }

    await page.emulateMedia({ reducedMotion: 'no-preference' });
    await page.waitForTimeout(50);
    const restoredLive = await page.evaluate(() => document.documentElement.dataset.scrollMode);
    if (restoredLive !== 'lenis') errors.push('Lenis did not restart after motion preference was restored.');

    await context.close();
  } finally {
    if (browser) await browser.close();
    if (server.exitCode === null) server.kill('SIGTERM');
  }

  if (errors.length) {
    console.error(`Automated browser verification failed with ${errors.length} error(s):`);
    for (const error of errors) console.error(`- ${error}`);
    process.exitCode = 1;
    return;
  }

  console.log(
    `Automated browser verification passed on ${baseOrigin}: ${routes.length}/7 routes, ` +
      `${viewportChecks} route/viewport checks, ` +
      `${axeChecks} Axe scans, local IBM Plex fonts, one Home title card and zero inner title cards, Lenis wheel movement, ` +
      `premium compact-menu fine-pointer hover/re-entry/focus retention, coarse-pointer tap toggle, ` +
      `keyboard/anchor/history behavior, initial/live reduced motion, ` +
      `JavaScript-disabled navigation/content, desktop navigation visibility, ` +
      `and zero third-party requests.`,
  );
}

await run();
