import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

export function findOpenLaunchBlockers(markdown) {
  return [...markdown.matchAll(/^###\s+(LB-\d{2})\b(?![^\n]*\[CLOSED\])/gim)].map((match) => match[1]);
}

export function validateProduction({
  launchFile = resolve('docs/launch-blockers.md'),
  distDirectory = resolve('dist'),
} = {}) {
  const errors = [];
  const register = readFileSync(launchFile, 'utf8');
  const openBlockers = findOpenLaunchBlockers(register);
  for (const blocker of openBlockers) errors.push(`${blocker} remains open.`);

  if (existsSync(distDirectory)) {
    const rendered = [
      'index.html', 'system/index.html', 'services/index.html', 'fit/index.html',
      'results/index.html', 'about/index.html', 'apply/index.html',
    ]
      .map((file) => readFileSync(resolve(distDirectory, file), 'utf8'))
      .join('\n');
    if (/\[LB-\d{2}:/i.test(rendered)) errors.push('A structured blocker marker reached generated output.');
    if (/Review note — not public copy/i.test(rendered)) errors.push('Private internal review annotations remain in generated output.');
  }

  return { errors, openBlockers };
}

function run() {
  const { errors, openBlockers } = validateProduction();
  if (errors.length) {
    console.error(`Production validation intentionally failed: ${openBlockers.length} actual launch blocker(s) remain open.`);
    for (const error of errors) console.error(`- ${error}`);
    process.exitCode = 1;
    return;
  }
  console.log('Production validation passed.');
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) run();
