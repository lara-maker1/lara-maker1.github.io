import { pathToFileURL } from 'node:url';

import * as about from '../src/content/en/about.mjs';
import * as apply from '../src/content/en/apply.mjs';
import * as fit from '../src/content/en/fit.mjs';
import * as home from '../src/content/en/home.mjs';
import * as results from '../src/content/en/results.mjs';
import * as servicesModule from '../src/content/en/services.mjs';
import * as shared from '../src/content/en/shared.mjs';
import * as system from '../src/content/en/system.mjs';

const prohibitedPatterns = [
  { label: 'withheld localized-channel count', pattern: /\b11\s+(?:localized\s+)?channels?\b/i },
  { label: 'withheld subscriber milestone', pattern: /\b100,?000\s+subscribers?\b/i },
  { label: 'withheld million-subscriber claim', pattern: /\b(?:one|1)\s+million\s+subscribers?\b/i },
  { label: 'withheld multiplier claim', pattern: /\b10\s*[–-]\s*30\s*[×x]\b/i },
  { label: 'future channel-capacity claim', pattern: /\b120\s+channels?\b/i },
  { label: 'unsupported guarantee', pattern: /\bwe\s+guarantee\b|\bguaranteed\s+(?:views|leads|revenue|results?)\b/i },
  { label: 'unsupported comparative claim', pattern: /\bnumber\s+one\b|\bsystem\s+of\s+domination\b|\bworld[- ]class\b/i },
  {
    label: 'positive future-product capability',
    pattern: /\b(?:we|our\s+service|the\s+service|clients?|customers?)\s+(?:now\s+)?(?:receive|use|includes?|provides?|features?|offers?|operates?|supports?|integrates?|automates?|runs?)\b.{0,100}\b(?:portal|dashboard|platform|automation|AI|CRM|API|integration)\b/i,
  },
  { label: 'proprietary future-product claim', pattern: /\b(?:our|a)\s+proprietary\s+(?:AI\s+)?(?:platform|dashboard|engine)\b/i },
];

export function findProhibitedClaims(value) {
  const text = String(value);
  return prohibitedPatterns
    .filter(({ pattern }) => pattern.test(text))
    .map(({ label }) => label);
}

function collectIds(value, ids = []) {
  if (Array.isArray(value)) {
    for (const item of value) collectIds(item, ids);
    return ids;
  }
  if (!value || typeof value !== 'object') return ids;
  if (typeof value.id === 'string') ids.push(value.id);
  for (const item of Object.values(value)) collectIds(item, ids);
  return ids;
}

export function validateContent() {
  const errors = [];
  const content = { about, apply, fit, home, results, servicesModule, shared, system };
  const ids = collectIds(content);
  const duplicates = [...new Set(ids.filter((id, index) => ids.indexOf(id) !== index))];

  if (duplicates.length) errors.push(`Duplicate stable IDs: ${duplicates.join(', ')}`);
  for (const id of ids) {
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id)) errors.push(`Unstable ID: ${id}`);
  }

  if (shared.navigation.length !== 7 || shared.pages.length !== 7) {
    errors.push('Shared content must expose exactly seven navigation items and seven pages.');
  }
  if (system.methodStages.length !== 7) errors.push('The operating method must expose seven stages.');
  if (servicesModule.services.length !== 5) errors.push('Services must expose five provisional paths.');
  if (results.measurementLayers.length !== 4) errors.push('Results must expose four measurement layers.');
  for (const evidence of home.evidenceItems) {
    if (evidence.publicationState !== 'non-public') {
      errors.push(`${evidence.id} must default to non-public.`);
    }
    if (!evidence.claimIds?.every((id) => /^C-\d{3}$/.test(id))) {
      errors.push(`${evidence.id} must carry valid claims-register IDs.`);
    }
  }

  const visitorContent = JSON.stringify({
    about,
    apply,
    fit,
    home: { ...home, evidenceItems: undefined },
    results,
    services: servicesModule.services,
    site: shared.site,
    navigation: shared.navigation,
    pages: shared.pages,
    system,
  });
  for (const finding of findProhibitedClaims(visitorContent)) {
    errors.push(`Prohibited visitor claim: ${finding}`);
  }

  return { errors, idCount: ids.length };
}

function run() {
  const { errors, idCount } = validateContent();
  if (errors.length) {
    console.error(`Content validation failed with ${errors.length} error(s):`);
    for (const error of errors) console.error(`- ${error}`);
    process.exitCode = 1;
    return;
  }
  console.log(`Content validation passed: ${idCount} stable IDs, 7 pages, 5 services, 7 stages, 4 measurement layers.`);
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) run();
