import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { extname, join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { gzipSync } from 'node:zlib';

import { findProhibitedClaims } from './validate-content.mjs';

const expectedRoutes = [
  { route: '/', file: 'index.html' },
  { route: '/system/', file: 'system/index.html' },
  { route: '/services/', file: 'services/index.html' },
  { route: '/fit/', file: 'fit/index.html' },
  { route: '/results/', file: 'results/index.html' },
  { route: '/about/', file: 'about/index.html' },
  { route: '/apply/', file: 'apply/index.html' },
];

function allFiles(directory) {
  if (!existsSync(directory)) return [];
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const path = join(directory, entry.name);
    return entry.isDirectory() ? allFiles(path) : [path];
  });
}

function count(html, pattern) {
  return [...html.matchAll(pattern)].length;
}

function hasApprovedScriptAttributes(attributes) {
  const parsed = [...attributes.matchAll(/([a-z][a-z0-9:-]*)[ \t\n\f\r]*=[ \t\n\f\r]*"([^"]*)"/gi)];
  if (parsed.length !== 2) return false;

  const leading = attributes.slice(0, parsed[0].index);
  const between = attributes.slice(parsed[0].index + parsed[0][0].length, parsed[1].index);
  const trailing = attributes.slice(parsed[1].index + parsed[1][0].length);
  if (!/^[ \t\n\f\r]*$/.test(leading) || !/^[ \t\n\f\r]+$/.test(between) || !/^[ \t\n\f\r]*$/.test(trailing)) return false;

  const values = new Map(parsed.map(([, name, value]) => [name.toLowerCase(), value]));
  return values.size === 2
    && values.get('type')?.toLowerCase() === 'module'
    && /^\/_astro\/[a-z0-9._-]+\.js$/i.test(values.get('src') ?? '');
}

function inspectScripts(html, route) {
  const errors = [];
  const openings = [...html.matchAll(/<script\b([^>]*)>/gi)];

  for (const match of openings) {
    if (!hasApprovedScriptAttributes(match[1])) {
      errors.push(`${route}: unsafe script; only an empty local generated module entry is allowed.`);
    }
  }

  const closingTag = /<\/script[ \t\n\f\r]*>/gi;
  for (const match of openings) {
    const bodyStart = match.index + match[0].length;
    closingTag.lastIndex = bodyStart;
    const close = closingTag.exec(html);
    const body = close ? html.slice(bodyStart, close.index).trim() : '';
    if (!close || body) {
      errors.push(`${route}: unsafe script; only an empty local generated module entry is allowed.`);
    }
  }
  return errors;
}

export function inspectHtml(html, route) {
  const errors = [];
  errors.push(...inspectScripts(html, route));
  if (count(html, /<h1\b/gi) !== 1) errors.push(`${route}: expected exactly one H1.`);
  for (const landmark of ['header', 'nav', 'main', 'footer']) {
    if (!new RegExp(`<${landmark}\\b`, 'i').test(html)) errors.push(`${route}: missing ${landmark} landmark.`);
  }
  if (!/<title>[^<]+<\/title>/i.test(html)) errors.push(`${route}: missing title.`);
  if (!/<meta\s+name="description"\s+content="[^"]+"/i.test(html)) errors.push(`${route}: missing description.`);
  if (!/<meta\s+name="robots"\s+content="noindex, nofollow, noarchive"/i.test(html)) errors.push(`${route}: missing private noindex metadata.`);
  if (!/<link\s+rel="canonical"\s+href="https:\/\/private-review\.invalid\//i.test(html)) errors.push(`${route}: missing review-safe canonical.`);
  if (/<(form|input|select|textarea)\b/i.test(html)) errors.push(`${route}: operational form controls are not allowed.`);
  if (/\[LB-\d{2}:/i.test(html)) errors.push(`${route}: structured blocker marker reached rendered output.`);
  if (/LB-\d{2}/i.test(html) && !/Review note — not public copy/i.test(html)) {
    errors.push(`${route}: unlabeled blocker reference reached rendered output.`);
  }

  const requestTags = [...html.matchAll(/<(?:a|img|script|iframe|source|video|audio|form|link)\b[^>]*>/gi)].map(([tag]) => tag);
  for (const tag of requestTags) {
    const url = tag.match(/(?:src|href|action)="([^"]+)"/i)?.[1];
    if (!url || !/^https?:\/\//i.test(url)) continue;
    const allowedCanonical = /<link\b/i.test(tag) && /rel="canonical"/i.test(tag) && /^https:\/\/private-review\.invalid\//i.test(url);
    if (!allowedCanonical) errors.push(`${route}: external request-bearing URL is not allowed: ${url}`);
  }

  for (const image of html.matchAll(/<img\b[^>]*>/gi)) {
    if (!/\bwidth="\d+"/i.test(image[0]) || !/\bheight="\d+"/i.test(image[0])) {
      errors.push(`${route}: image lacks explicit width and height.`);
    }
  }

  for (const finding of findProhibitedClaims(html.replace(/<[^>]+>/g, ' '))) {
    errors.push(`${route}: prohibited rendered claim: ${finding}`);
  }
  return errors;
}

export function validateBuildDirectory(directory = resolve('dist')) {
  const errors = [];
  const htmlByRoute = new Map();

  for (const expected of expectedRoutes) {
    const path = join(directory, expected.file);
    if (!existsSync(path)) {
      errors.push(`${expected.route}: missing approved route output ${expected.file}.`);
      continue;
    }
    const html = readFileSync(path, 'utf8');
    htmlByRoute.set(expected.route, html);
    errors.push(...inspectHtml(html, expected.route));
  }

  const files = allFiles(directory);
  const htmlFiles = files.filter((file) => extname(file) === '.html');
  if (htmlFiles.length !== 7) errors.push(`Expected exactly 7 HTML outputs; found ${htmlFiles.length}.`);
  if (!existsSync(join(directory, 'robots.txt'))) errors.push('Missing private robots.txt output.');

  const approvedRoutes = new Set(expectedRoutes.map(({ route }) => route));
  for (const [route, html] of htmlByRoute) {
    for (const match of html.matchAll(/<a\b[^>]+href="([^"]+)"/gi)) {
      const href = match[1];
      if (href.startsWith('#')) continue;
      if (/^(?:https?:|mailto:|tel:)/i.test(href)) {
        errors.push(`${route}: external or direct-contact anchor is not allowed: ${href}`);
        continue;
      }
      const normalized = href.split('#')[0];
      if (normalized.startsWith('/') && !approvedRoutes.has(normalized)) {
        errors.push(`${route}: unresolved internal route link: ${href}`);
      }
    }

    for (const match of html.matchAll(/<(?:img|script|source|link)\b[^>]+(?:src|href)="(\/[^"]+)"/gi)) {
      const asset = match[1].split('?')[0];
      if (approvedRoutes.has(asset)) continue;
      const assetPath = join(directory, asset.replace(/^\//, ''));
      if (!existsSync(assetPath) || !statSync(assetPath).isFile()) errors.push(`${route}: missing local asset: ${asset}`);
    }
  }

  const cssFiles = files.filter((file) => extname(file) === '.css');
  const jsFiles = files.filter((file) => extname(file) === '.js');
  const cssGzipBytes = cssFiles.reduce((sum, file) => sum + gzipSync(readFileSync(file)).byteLength, 0);
  const jsGzipBytes = jsFiles.reduce((sum, file) => sum + gzipSync(readFileSync(file)).byteLength, 0);
  if (cssGzipBytes > 60 * 1024) errors.push(`CSS hard budget exceeded: ${cssGzipBytes} compressed bytes.`);
  if (jsGzipBytes > 25 * 1024) errors.push(`JavaScript hard budget exceeded: ${jsGzipBytes} compressed bytes.`);
  if (jsFiles.length === 0) errors.push('Expected the approved smooth-scroll JavaScript asset; found none.');
  if (jsFiles.length > 3) errors.push(`Unexpected JavaScript chunk count: ${jsFiles.length}.`);

  const assetGzipBytes = cssGzipBytes + jsGzipBytes;
  let largestTransferBytes = 0;
  for (const html of htmlByRoute.values()) {
    largestTransferBytes = Math.max(largestTransferBytes, gzipSync(html).byteLength + assetGzipBytes);
  }
  if (largestTransferBytes > 1024 * 1024) errors.push(`Initial transfer hard budget exceeded: ${largestTransferBytes} compressed bytes.`);

  for (const cssFile of cssFiles) {
    const css = readFileSync(cssFile, 'utf8');
    if (/url\(\s*['"]?https?:\/\//i.test(css) || /@import\s+['"]https?:\/\//i.test(css)) {
      errors.push(`Remote CSS or font request found in ${cssFile}.`);
    }
  }

  const buildText = files
    .filter((file) => ['.html', '.css', '.js', '.json', '.txt'].includes(extname(file)))
    .map((file) => readFileSync(file, 'utf8'))
    .join('\n');
  if (/AKIA[0-9A-Z]{16}|BEGIN (?:RSA |EC )?PRIVATE KEY|\b(?:api[_-]?key|secret[_-]?key)\s*[:=]\s*['"][^'"]+/i.test(buildText)) {
    errors.push('Potential secret material found in generated output.');
  }

  return {
    errors,
    metrics: {
      routes: htmlByRoute.size,
      cssFiles: cssFiles.length,
      jsFiles: jsFiles.length,
      cssGzipBytes,
      jsGzipBytes,
      largestTransferBytes,
    },
  };
}

function run() {
  const { errors, metrics } = validateBuildDirectory();
  if (errors.length) {
    console.error(`Build validation failed with ${errors.length} error(s):`);
    for (const error of errors) console.error(`- ${error}`);
    process.exitCode = 1;
    return;
  }
  console.log(
    `Build validation passed: ${metrics.routes}/7 routes, ${metrics.jsFiles} JS files (${metrics.jsGzipBytes}B gzip), ` +
      `${metrics.cssFiles} CSS file(s) (${metrics.cssGzipBytes}B gzip), largest initial transfer ${metrics.largestTransferBytes}B gzip.`,
  );
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) run();
