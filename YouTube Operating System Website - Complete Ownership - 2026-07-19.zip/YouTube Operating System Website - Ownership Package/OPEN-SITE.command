#!/bin/zsh
cd "$(dirname "$0")"
node tools/preview-built-site.mjs

